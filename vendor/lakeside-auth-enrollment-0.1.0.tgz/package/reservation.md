# Enrollment reservation (migration 5)

`createEnrollmentReservationStore(pool, { allowedSourceIssuers })` is a
metadata store. It reserves stable
canonical account and enrollment operation IDs BEFORE `startEnrollment`
runs, after the source backend has verified fresh ownership elsewhere.

```js
import { createEnrollmentReservationStore } from './index.mjs';

const reservations = createEnrollmentReservationStore(pool, {
  allowedSourceIssuers: ['https://source.example.invalid'],
});
const reserved = await reservations.reserve({
  sourceIdentity: { issuer, subject },
  provenance: 'source-login-2026-09-10',
});
// { version: 1, sourceIssuer, sourceSubject, canonicalAccountId, enrollmentOperationId }
// Next: durably record and validate fresh source proof bound to these IDs.
// Only the authenticated proof-admission path may subsequently start enrollment.
```

## What this is not

Reserving IDs does not start, enroll, fence, claim, route, admit,
provision, enable, authenticate or prove anything. The
`enrollment_reservation` table is metadata only, not admission. There is
no login status and no permit in the frozen return value.

Initial fresh ownership authorization remains an external trusted caller
requirement and is explicitly not implemented by this metadata API. The
browser cannot choose the canonical account or operation: `reserve` takes
no caller account or operation ID, resolves the account only from the
existing immutable `lakeside_accounts.external_identity` row for the
exact issuer and subject, and rejects unknown input keys (including
`accountId`, `operationId` and `email`). Email, profile and username are
never used for identity. No account security version is stored: a
reservation is not a security grant, and freshness belongs to the future
proof object. No raw credential, lease, token or proof material is stored.

## Rules

- The source issuer must be in the exact allowlist. All strings are
  bounded, nonempty, have no leading or trailing whitespace and no control
  characters, with well-formed Unicode and no `String` coercion. Validators match full strings.
- The canonical account row is locked (`FOR UPDATE`) before the immutable
  mapping is rechecked. Same lock order as the enrollment paths: account
  first. The account must be active with `recovery_hold === false`;
  recovery hold and suspension always reject, including replays and reads.
- The operation UUID is minted once outside the transaction and used only
  for a new record. Inserts use `INSERT ... ON CONFLICT DO NOTHING` plus a
  safe read afterward; no unique violation is ever caught inside the
  transaction. Same account and same exact source retries return the exact
  same IDs, even when concurrent.
- One source enrollment per account: a different exact source tuple that
  maps to the same canonical account conflicts.
- Preexisting enrollment rows: replay of an existing reservation is allowed
  only when the exact operation, source and account match that enrollment.
  A missing reservation with a preexisting enrollment rejects rather than
  guessing or adopting an arbitrary historical operation. A conflicting
  operation always rejects. Exact replay is allowed in every enrollment
  state including `unified`, because redrive requires the same account and
  operation and the reservation itself changes nothing.
- This API neither consults nor changes admission control. Reserving while
  paused is allowed because it creates no enrollment and does not change
  the public route; `resolveLoginRoute` still reports `legacy` and
  `rollout_control` is untouched after a reserve.
- `loadReservation({ issuer, subject })` is an exact-source metadata read
  with the same allowlist, mapping, hold and enrollment compatibility checks, so it cannot bypass a
  hold. It returns the frozen primitive or `null` when missing.

## Operations

Run `migrate(pool)` with migration credentials after the registry schema
exists; migration 5 is additive and leaves checksums 1..4 unchanged. All
SQL is schema qualified. Pools must set connectionTimeoutMillis between
1 and 5000 and query_timeout between 100 and 15000 milliseconds. Both methods
use transactions with a 5-second lock timeout and 10-second statement timeout. The table carries unique account,
unique operation and unique source constraints plus an immutable
update/delete trigger that fails closed, with `PUBLIC` execute revoked on
the trigger function, consistent with the existing module migrations.

The deployment role bootstrap grants enrollment runtime SELECT and INSERT
only on this table. Other managed roles receive no access. Apply migration 5
before reapplying the grants. No production database is configured by this module. Do not
run these tests against a production database.

```sh
cd packages/auth-enrollment
LAKESIDE_ISOLATED_ENROLLMENT_TEST=true PGHOST=database node --test reservation.test.mjs
```
