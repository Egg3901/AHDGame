-- Stable enrollment identifiers before admission (metadata only).
-- Additive only. Existing migrations 1..4 are untouched.
--
-- A row reserves stable canonical account and enrollment operation IDs BEFORE
-- startEnrollment runs. It starts nothing, enrolls nothing, fences nothing,
-- claims nothing, changes no routing or control state, creates no account or
-- external identity mapping, provisions no target, enables no user, and is
-- not authentication or proof. Fresh source ownership authorization stays an
-- external trusted-caller requirement and is not implemented here.
--
-- Identity comes only from the immutable lakeside_accounts.external_identity
-- row for the exact issuer and subject. Email, profile and username never
-- participate. No account security version is stored: a reservation is not a
-- security grant, and freshness belongs to the future proof object.
--
-- One source enrollment per account: the account, the operation and the exact
-- source tuple are each unique. A different exact source tuple that maps to
-- the same canonical account conflicts instead of creating a second row.
-- No raw credential, lease, token or proof material is stored in this table.
CREATE TABLE lakeside_enrollment.enrollment_reservation (
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  source_issuer text NOT NULL CHECK (length(source_issuer) BETWEEN 1 AND 512 AND source_issuer !~ '[[:cntrl:]]'),
  source_subject text NOT NULL CHECK (length(source_subject) BETWEEN 1 AND 512 AND source_subject !~ '[[:cntrl:]]'),
  operation_id uuid NOT NULL PRIMARY KEY,
  created_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (account_id),
  UNIQUE (source_issuer, source_subject)
);

CREATE OR REPLACE FUNCTION lakeside_enrollment.reject_enrollment_reservation_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'enrollment reservation is immutable';
END;
$$;

CREATE TRIGGER enrollment_reservation_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.enrollment_reservation
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_enrollment_reservation_mutation();

-- Keep the trigger function closed by default, consistent with the existing
-- module migrations. The deployment role bootstrap grants runtime SELECT
-- and INSERT only; this module does not configure a production database.
REVOKE ALL ON FUNCTION lakeside_enrollment.reject_enrollment_reservation_mutation() FROM PUBLIC;
