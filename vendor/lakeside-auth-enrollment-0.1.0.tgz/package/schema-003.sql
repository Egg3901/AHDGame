-- Expected external credential write and authenticated receipt evidence.
-- Never store a credential digest or a raw lease token in these tables.
CREATE TABLE lakeside_enrollment.import_binding (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.enrollment(operation_id),
  account_id uuid NOT NULL UNIQUE REFERENCES lakeside_accounts.account(account_id),
  binding jsonb NOT NULL CHECK (jsonb_typeof(binding) = 'object'),
  bound_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE TABLE lakeside_enrollment.import_receipt (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.import_binding(operation_id),
  receipt_id uuid NOT NULL UNIQUE,
  evidence_fingerprint text NOT NULL CHECK (length(evidence_fingerprint) = 64),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);
CREATE TRIGGER import_binding_immutable BEFORE UPDATE OR DELETE
ON lakeside_enrollment.import_binding FOR EACH ROW
EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER import_receipt_immutable BEFORE UPDATE OR DELETE
ON lakeside_enrollment.import_receipt FOR EACH ROW
EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
