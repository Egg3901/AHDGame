# Source ownership proof reader

`createSourceOwnershipProofReader({ sourceIssuer, loadSourceProof, timeoutMs = 5000 })`
is a trusted-backend adapter. It loads one durable source ownership proof through a
deployer-injected loader that is already pinned to the configured source issuer.
A claim hash, timestamp, browser cookie, or password does not authenticate the
read. This module is not exported from the package index.

```js
import { createSourceOwnershipProofReader } from './source-proof-reader.mjs';

const reader = createSourceOwnershipProofReader({
  sourceIssuer: 'https://source.example.invalid/auth',
  loadSourceProof,
});

const loaded = await reader.loadProof({
  proofId,
  sourceAccountId,
  canonicalAccountId,
  enrollmentOperationId,
});
// { proof, sourceNowMs, expired: false }
```

`sourceIssuer` is an exact pinned HTTPS URL. The factory rejects HTTP, URNs,
credentials, query strings, fragments, and URL normalization aliases, including
default port 443, host case folding, and path resolution. There is no production
default issuer or loader.

`loadProof` requires those four exact input keys. Identifiers are captured as
immutable primitives before any await: `sourceAccountId` is 24 lowercase hex,
and `proofId`, `canonicalAccountId`, and `enrollmentOperationId` are lowercase
version-4 UUIDs. Unicode line separators and string coercion are rejected.
Invalid input never calls the loader.

The loader receives only `Object.freeze({ proofId })` and `{ signal }`. It must
not be given a browser cookie, password, or the remaining binding fields. The
configured loader is internally pinned to the configured source issuer.
Backend TLS and machine authentication are a future deployment requirement,
not something this adapter establishes.

Each call has a cooperative abort plus `Promise.race` bound of 10 to 10000 ms
(default 5000). An optional `parentAbortSignal` is a separate options argument.
Timeout, parent abort, and loader failure are `unavailable`. A late loader
result is ignored. Missing `null` from the loader is `missing`, not abort.

The raw loader result must be exactly `{ proof, sourceNowMs, expired }`. Proof
keys are exactly `{ proofId, version: 1, sourceIssuer, sourceAccountId,
canonicalAccountId, enrollmentOperationId, snapshotVersion: 1, snapshotDigest,
method: 'password', retainedMethods: ['password'], observedAtMs, expiresAtMs,
observationWindowMs: 30000 }`. `snapshotDigest` is 64 lowercase hex. Times are
positive safe integers. Expiry minus observation is exactly 270000 ms.
`sourceNowMs` must be at least `observedAtMs` and less than `expiresAtMs`, with
`expired` exactly `false`. If `expired` is `true` and the source clock is at or
after expiry, the error is `expired`. Any other clock or flag inconsistency is
`invalid`, including a source clock before observation. Exact configured issuer
and requested identifiers must match or the error is `binding`. Raw password or
hash fields are unknown keys and fail as `invalid`.

The accepted return is the same frozen wrapper `{ proof, sourceNowMs, expired: false }`
with a frozen proof and frozen `retainedMethods`. Primitives are copied
synchronously before another await. The source clock snapshot is the value
freshly read through the authenticated loader on that call. The central wall
clock is not the freshness authority. There is no clock-skew fudge.

`SourceOwnershipProofReadError` exposes only `missing`, `unavailable`,
`invalid`, `expired`, and `binding`. Messages never include an injected error,
cause, proof body, token, or endpoint. Hostile typed errors and throwing
getters are not propagated.

## What this is not

This adapter does not admit, fence, create an account, grant permissions, or
change migration state. It runs no SQL. A source `proofId` is a correlation
identifier, not a bearer credential. Possession of a loaded proof is not a
current-source-security check and not a one-use or unused guarantee. An
admission or fence consumer must recheck current source state and commit
one-use consumption itself.

The observation can become stale immediately after return. The consumer must
bound its own admission latency and revalidate. This adapter does not
authenticate transport. Deployment must pin and trust the loader for the
configured issuer, including backend TLS and machine authentication. Do not
treat a successful read as a generic "verified" claim; the return is exact
metadata from the trusted source loader.

No public proof endpoint, coordinator admission, source-fence writer, or
production cohort is enabled here.

```sh
cd packages/auth-enrollment
node --test source-proof-reader.test.mjs
```
