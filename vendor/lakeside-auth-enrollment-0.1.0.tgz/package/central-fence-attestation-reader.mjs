import { createHash } from 'node:crypto';
import { isPinnedSourceIssuer } from './source-issuer.mjs';

export class CentralFenceAttestationReadError extends Error {
  constructor() { super('Central fence attestation is unavailable'); this.name = 'CentralFenceAttestationReadError'; }
}

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u;
const HASH = /^[0-9a-f]{64}$/u;
const CONTROL = /[\u0000-\u0020\u007f]/u;

function safeText(value, max) {
  return typeof value === 'string' && value.length > 0 && value.length <= max
    && value === value.trim() && !CONTROL.test(value);
}

function httpsIssuer(value) {
  if (!safeText(value, 512)) return false;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' && !parsed.username && !parsed.password && !/[?#]/u.test(value);
  } catch { return false; }
}

function digest(value) {
  const canonical = Object.fromEntries(Object.keys(value).sort().map(key => [key, value[key]]));
  return createHash('sha256').update(JSON.stringify(canonical)).digest('hex');
}

function milliseconds(value) {
  if (typeof value !== 'string' || !/^[0-9]{1,16}(?:\.[0-9]{1,6})?$/u.test(value)) {
    throw new CentralFenceAttestationReadError();
  }
  const result = Number(value);
  if (!Number.isSafeInteger(result) || result <= 0) throw new CentralFenceAttestationReadError();
  return result;
}

/**
 * Reads permanent source-fence authority and committed target ownership in a
 * single read-only PostgreSQL snapshot. Lease expiry is returned as data so
 * an exact recovery can redrive after expiry. It never returns a lease token.
 */
export function createCentralFenceAttestationReader(pool, {
  sourceIssuer, targetIssuer, targetRealmId, queryTimeoutMs = 3000,
}) {
  if ((!isPinnedSourceIssuer(sourceIssuer) && !httpsIssuer(sourceIssuer))
      || !httpsIssuer(targetIssuer) || !safeText(targetRealmId, 255)) {
    throw new TypeError('Exact trusted issuers and target realm required');
  }
  if (!Number.isSafeInteger(queryTimeoutMs) || queryTimeoutMs < 100 || queryTimeoutMs > 5000) {
    throw new TypeError('Bounded query timeout required');
  }
  if (!pool || typeof pool.connect !== 'function'
      || !Number.isSafeInteger(pool.options?.connectionTimeoutMillis)
      || pool.options.connectionTimeoutMillis < 1 || pool.options.connectionTimeoutMillis > 5000) {
    throw new TypeError('Pool must have a bounded connection timeout');
  }

  const sql = `SELECT e.account_id::text, e.operation_id::text,
      floor(extract(epoch FROM e.lease_expires_at) * 1000)::bigint::text AS lease_expires_ms,
      f.fence_generation::text, f.fence_authority, f.fence_token_hash,
      floor(extract(epoch FROM f.fenced_at) * 1000)::bigint::text AS fenced_at_ms,
      source.subject AS source_account_id,
      target.issuer AS target_issuer, target.subject AS target_subject
    FROM lakeside_enrollment.enrollment e
    JOIN lakeside_enrollment.account_fence f
      ON f.account_id=e.account_id AND f.operation_id=e.operation_id
    JOIN lakeside_accounts.account a ON a.account_id=e.account_id
    JOIN lakeside_accounts.external_identity source
      ON source.account_id=e.account_id AND source.issuer=e.issuer AND source.subject=e.subject
    JOIN lakeside_accounts.provision_subject ps
      ON ps.account_id=e.account_id AND ps.issuer=$3 AND ps.realm_id=$4
    JOIN lakeside_accounts.provision_evidence pe
      ON pe.attempt_id=ps.first_attempt_id AND pe.state='COMMITTED'
    JOIN lakeside_accounts.external_identity target
      ON target.account_id=e.account_id AND target.issuer=ps.issuer AND target.subject=ps.user_id::text
    WHERE e.account_id=$1 AND e.operation_id=$2 AND e.issuer=$5
      AND e.state='enrolling' AND e.lease_expires_at IS NOT NULL
      AND a.status='active' AND a.recovery_hold=false`;

  return async function loadCentralFenceAttestation(input, { signal } = {}) {
    const binding = input && {
      canonicalAccountId: input.canonicalAccountId,
      enrollmentOperationId: input.enrollmentOperationId,
    };
    if (!binding || !UUID.test(binding.canonicalAccountId)
        || !UUID.test(binding.enrollmentOperationId) || signal?.aborted) {
      throw new CentralFenceAttestationReadError();
    }
    let client;
    let broken = false;
    const query = (text, values = []) => client.query({ text, values, query_timeout: queryTimeoutMs });
    try {
      client = await pool.connect();
      if (signal?.aborted) throw new CentralFenceAttestationReadError();
      await query('BEGIN READ ONLY ISOLATION LEVEL REPEATABLE READ');
      await query("SELECT set_config('statement_timeout',$1,true)", [String(queryTimeoutMs)]);
      const result = await query(sql, [binding.canonicalAccountId, binding.enrollmentOperationId,
        targetIssuer, targetRealmId, sourceIssuer]);
      await query('COMMIT');
      if (signal?.aborted || !Array.isArray(result.rows) || result.rows.length > 1) {
        throw new CentralFenceAttestationReadError();
      }
      if (result.rows.length === 0) return null;
      const row = result.rows[0];
      if (row.account_id !== binding.canonicalAccountId
          || row.operation_id !== binding.enrollmentOperationId
          || !/^[1-9][0-9]{0,18}$/u.test(row.fence_generation)
          || BigInt(row.fence_generation) > 9_223_372_036_854_775_807n
          || !safeText(row.fence_authority, 128) || !HASH.test(row.fence_token_hash)
          || !safeText(row.source_account_id, 512)
          || row.target_issuer !== targetIssuer || !safeText(row.target_subject, 512)) {
        throw new CentralFenceAttestationReadError();
      }
      const attestation = {
        version: 1,
        sourceIssuer,
        sourceAccountId: row.source_account_id,
        canonicalAccountId: row.account_id,
        enrollmentOperationId: row.operation_id,
        fenceGeneration: row.fence_generation,
        fenceAuthority: row.fence_authority,
        fenceTokenHash: row.fence_token_hash,
        fencedAtMs: milliseconds(row.fenced_at_ms),
        leaseExpiresAtMs: milliseconds(row.lease_expires_ms),
        targetIssuer,
        targetSubject: row.target_subject,
      };
      return Object.freeze({ ...attestation, attestationDigest: digest(attestation) });
    } catch (error) {
      if (error instanceof CentralFenceAttestationReadError && !client) throw error;
      broken = true;
      throw new CentralFenceAttestationReadError();
    } finally {
      if (client) client.release(broken);
    }
  };
}
