import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes, randomUUID } from 'node:crypto';
import pg from 'pg';
import {
  AdmissionPausedError,
  EnrollmentAccountSuspendedError,
  EnrollmentConflictError,
  EnrollmentFencedError,
  EnrollmentStateError,
  IdempotencyConflictError,
  LeaseExpiredError,
  LeaseHeldError,
  LegacyIdentityNotAllowedError,
  ProofAdmissionExpiredError,
  ProofAdmissionRequiredError,
  createCohortEnrollment,
  createIdempotencyKey,
  createOperationId,
  migrate,
} from './index.mjs';
import { createAccountRegistry, migrate as migrateRegistry } from '../account-registry/index.mjs';
import { createCentralFenceAttestationReader } from './central-fence-attestation-reader.mjs';

if (process.env.LAKESIDE_ISOLATED_ENROLLMENT_TEST !== 'true' || process.env.PGHOST !== 'database') {
  throw new Error('Run through the isolated compat Compose enrollment-tests service with PGHOST=database');
}

const database = `enrollment_test_${randomUUID().replaceAll('-', '')}`;
const admin = new pg.Pool({ max: 1 });
let pool;
let enrollment;
let registry;
let readonlyPool;
let readonlyEnrollment;
let readonlyRole;
let readonlyRoleCreated = false;
const options = {
  allowedIssuers: ['urn:lakeside:legacy:ahd:production', 'urn:lakeside:legacy:other', 'https://legacy.example.invalid'],
  allowedApplications: [],
};
const issuer = options.allowedIssuers[0];
const idempotency = () => createIdempotencyKey();
const subject = suffix => `legacy-enrollment-${suffix}`;
const identity = value => ({ issuer, subject: value });
const operationInput = (value, suffix = value) => ({
  operationId: createOperationId(),
  idempotencyKey: idempotency(),
  legacyIdentity: identity(value),
  provenance: `test:${suffix}`,
});

test.before(async () => {
  await admin.query(`CREATE DATABASE ${database}`);
  pool = new pg.Pool({ database, max: 24, connectionTimeoutMillis: 5000 });
  await migrateRegistry(pool);
  await pool.query('ALTER TABLE lakeside_accounts.account ADD COLUMN IF NOT EXISTS recovery_hold boolean NOT NULL DEFAULT false');
  registry = createAccountRegistry(pool, options);
  enrollment = createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [identity(subject('one')), identity(subject('pause')), identity(subject('lease')), identity(subject('hold')), identity(subject('audit')), identity(subject('conflict')), identity(subject('idempotency')), identity(subject('rollback')), identity(subject('post-hold')), identity(subject('lifecycle')), identity(subject('unmapped')), identity(subject('alias-a')), identity(subject('fence')), identity(subject('fence-audit')), identity(subject('fence-complete')), identity(subject('fence-race')), identity(subject('central-attestation'))],
    leaseSeconds: 1,
  });
});

test.after(async () => {
  await pool?.end();
  await readonlyPool?.end();
  await admin.query(`DROP DATABASE IF EXISTS ${database}`);
  if (readonlyRoleCreated) await admin.query(`DROP ROLE IF EXISTS ${readonlyRole}`);
  await admin.end();
});

async function setupReadonlyRoutePool() {
  readonlyRole = `enrollment_route_ro_${randomUUID().replaceAll('-', '')}`;
  const password = randomBytes(24).toString('base64url');
  await admin.query(`CREATE ROLE ${readonlyRole} LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT NOREPLICATION NOBYPASSRLS PASSWORD '${password}'`);
  readonlyRoleCreated = true;
  await admin.query(`GRANT CONNECT ON DATABASE ${database} TO ${readonlyRole}`);
  for (const schema of ['lakeside_accounts', 'lakeside_enrollment']) {
    await pool.query(`GRANT USAGE ON SCHEMA ${schema} TO ${readonlyRole}`);
  }
  await grantReadonlyRouteTables();
  readonlyPool = new pg.Pool({
    user: readonlyRole,
    password,
    database,
    max: 4,
    options: '-c default_transaction_read_only=on',
    connectionTimeoutMillis: 5000,
    query_timeout: 10000,
  });
  readonlyEnrollment = createCohortEnrollment(readonlyPool, {
    allowedLegacyIdentities: [identity(subject('readonly-cohort'))],
  });
}

async function grantReadonlyRouteTables() {
  for (const table of [
    'lakeside_accounts.account',
    'lakeside_accounts.external_identity',
    'lakeside_enrollment.enrollment',
    'lakeside_enrollment.account_fence',
  ]) {
    await pool.query(`GRANT SELECT ON TABLE ${table} TO ${readonlyRole}`);
  }
}

async function createLegacyAccount(value) {
  return registry.resolveOrCreateVerifiedIdentity(identity(value), 'test:legacy');
}

async function fenceFor(claim, provenance = 'test:fence') {
  return enrollment.fenceEnrollment({
    operationId: claim.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance,
  });
}

async function verifyCentralFenceAttestation() {
  const sourceSubject = subject('central-attestation');
  const centralSourceIssuer = 'https://legacy.example.invalid';
  const sourceIdentity = { issuer: centralSourceIssuer, subject: sourceSubject };
  const account = await registry.resolveOrCreateVerifiedIdentity(sourceIdentity, 'test:central-source');
  const attestationEnrollment = createCohortEnrollment(pool, { allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [sourceIdentity], leaseSeconds: 1 });
  const admitted = await attestationEnrollment.startEnrollment({ operationId: createOperationId(),
    idempotencyKey: idempotency(), legacyIdentity: sourceIdentity, provenance: 'test:attestation-start' });
  const claim = await attestationEnrollment.claimEnrollment({ operationId: admitted.operationId,
    idempotencyKey: idempotency(), authorityId: 'attestation-reader', provenance: 'test:attestation-claim' });
  await attestationEnrollment.fenceEnrollment({ operationId: claim.operationId,
    idempotencyKey: idempotency(), authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken, leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:attestation-fence' });

  const targetIssuer = 'https://accounts.example.invalid/realms/lakeside';
  const targetRealmId = 'lakeside';
  const targetSubject = randomUUID();
  const attemptId = randomUUID();
  const receiptId = randomUUID();
  const leaseTokenHash = 'a'.repeat(64);
  const leaseExpiresAtMs = Date.now() + 60_000;
  await pool.query(`INSERT INTO lakeside_accounts.provision_operation
    (account_id, operation_id, issuer, realm_id, username, provenance)
    VALUES ($1,$2,$3,$4,$5,$6)`, [account.account_id, admitted.operationId, targetIssuer,
    targetRealmId, `lakeside:${account.account_id}`, 'test:attestation-provision']);
  await pool.query(`INSERT INTO lakeside_accounts.provision_attempt
    (attempt_id, operation_id, account_id, attempt_generation, account_security_version, binding)
    VALUES ($1,$2,$3,1,1,$4)`, [attemptId, admitted.operationId, account.account_id, {
    version: 1, accountId: account.account_id, operationId: admitted.operationId,
    issuer: targetIssuer, realmId: targetRealmId, username: `lakeside:${account.account_id}`,
    attemptId, attemptGeneration: 1, leaseTokenHash, leaseExpiresAtMs,
  }]);
  await pool.query(`INSERT INTO lakeside_accounts.provision_subject
    (account_id,user_id,issuer,realm_id,first_attempt_id) VALUES($1,$2,$3,$4,$5)`,
  [account.account_id, targetSubject, targetIssuer, targetRealmId, attemptId]);
  await pool.query(`INSERT INTO lakeside_accounts.external_identity(issuer,subject,account_id,provenance)
    VALUES($1,$2,$3,$4)`, [targetIssuer, targetSubject, account.account_id, 'test:target']);

  const reader = createCentralFenceAttestationReader(pool, {
    sourceIssuer: centralSourceIssuer, targetIssuer, targetRealmId,
  });
  assert.equal(await reader({ canonicalAccountId: account.account_id,
    enrollmentOperationId: admitted.operationId }), null);
  await pool.query(`INSERT INTO lakeside_accounts.provision_evidence
    (attempt_id,receipt_id,state,evidence_fingerprint) VALUES($1,$2,'COMMITTED',$3)`,
  [attemptId, receiptId, 'b'.repeat(64)]);
  await pool.query(`UPDATE lakeside_enrollment.enrollment
    SET lease_expires_at=clock_timestamp() - interval '1 second' WHERE operation_id=$1`,
  [admitted.operationId]);
  const result = await reader({ canonicalAccountId: account.account_id,
    enrollmentOperationId: admitted.operationId });
  assert.equal(result.sourceAccountId, sourceSubject);
  assert.equal(result.targetSubject, targetSubject);
  assert.equal(result.canonicalAccountId, account.account_id);
  assert.ok(result.fencedAtMs <= Date.now());
  assert.ok(result.leaseExpiresAtMs < Date.now());
}

test('enrollment migration fails closed without registry recovery_hold and fresh rollout is paused', async () => {
  await pool.query('ALTER TABLE lakeside_accounts.account DROP COLUMN recovery_hold');
  await assert.rejects(migrate(pool), /migration 3.*recovery_hold/iu);
  await pool.query('ALTER TABLE lakeside_accounts.account ADD COLUMN recovery_hold boolean NOT NULL DEFAULT false');
  await migrate(pool);
  await setupReadonlyRoutePool();
  assert.equal((await enrollment.getRolloutState()).admissionsPaused, true);
  const resumed = await enrollment.resumeAdmissions({ operationId: createOperationId(), idempotencyKey: idempotency(), provenance: 'test:initial-resume' });
  assert.equal(resumed.admissionsPaused, false);
});

test('central fence attestation requires committed target evidence and survives lease expiry', verifyCentralFenceAttestation);

test('migration 2 backfills an existing unified operation into the immutable fence', async () => {
  const before = await pool.query('SELECT checksum FROM lakeside_enrollment.migration WHERE version=1');
  assert.equal(before.rows.length, 1);
  const owner = await createLegacyAccount(subject('upgrade'));
  const operationId = createOperationId();
  await pool.query(
    `INSERT INTO lakeside_enrollment.enrollment(operation_id, issuer, subject, account_id, state, unified_at)
     VALUES ($1, $2, $3, $4, 'unified', clock_timestamp())`,
    [operationId, issuer, subject('upgrade'), owner.account_id],
  );
  await pool.query('DROP TABLE lakeside_enrollment.account_fence');
  await pool.query('DELETE FROM lakeside_enrollment.migration WHERE version=2');
  await migrate(pool);
  await grantReadonlyRouteTables();
  const after = await pool.query('SELECT checksum FROM lakeside_enrollment.migration WHERE version=1');
  assert.deepEqual(after.rows, before.rows);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [operationId])).rows[0].count, '1');
  assert.equal((await enrollment.getLoginRoute(identity(subject('upgrade')))).status, 'unified');
});

test('production admission requires and durably binds a fresh source proof', async () => {
  const proofSubject = subject('proof-admit');
  const owner = await createLegacyAccount(proofSubject);
  const operationId = createOperationId();
  const proofId = createOperationId();
  await pool.query(
    `INSERT INTO lakeside_enrollment.enrollment_reservation(account_id, source_issuer, source_subject, operation_id)
     VALUES ($1, $2, $3, $4)`,
    [owner.account_id, issuer, proofSubject, operationId],
  );
  const proof = Object.freeze({
    proofId,
    sourceAccountId: '0123456789abcdef01234567',
    canonicalAccountId: owner.account_id,
    enrollmentOperationId: operationId,
    snapshotDigest: 'a'.repeat(64),
    observedAtMs: 1_000,
    expiresAtMs: 271_000,
  });
  const proofApi = createCohortEnrollment(pool, {
    allowedLegacyIdentities: [identity(proofSubject)],
    sourceProofReader: { loadProof: async requested => {
      assert.deepEqual(requested, {
        proofId,
        sourceAccountId: proof.sourceAccountId,
        canonicalAccountId: owner.account_id,
        enrollmentOperationId: operationId,
      });
      return Object.freeze({ proof, sourceNowMs: 2_000, expired: false });
    } },
    monotonicNow: () => 10,
  });
  const start = {
    operationId,
    idempotencyKey: idempotency(),
    legacyIdentity: identity(proofSubject),
    provenance: 'test:proof-required',
  };
  await assert.rejects(proofApi.startEnrollment(start), ProofAdmissionRequiredError);
  const reservation = Object.freeze({
    version: 1,
    sourceIssuer: issuer,
    sourceSubject: proofSubject,
    canonicalAccountId: owner.account_id,
    enrollmentOperationId: operationId,
  });
  const admitted = await proofApi.admitEnrollment({
    reservation,
    proofId,
    sourceAccountId: proof.sourceAccountId,
    idempotencyKey: start.idempotencyKey,
    provenance: start.provenance,
  });
  assert.equal(admitted.status, 'eligible');
  assert.deepEqual(await proofApi.admitEnrollment({
    reservation,
    proofId,
    sourceAccountId: proof.sourceAccountId,
    idempotencyKey: start.idempotencyKey,
    provenance: start.provenance,
  }), admitted);
  const { rows } = await pool.query(
    'SELECT proof_id::text, source_account_id, snapshot_digest FROM lakeside_enrollment.proof_admission WHERE operation_id=$1',
    [operationId],
  );
  assert.deepEqual(rows, [{ proof_id: proofId, source_account_id: proof.sourceAccountId, snapshot_digest: proof.snapshotDigest }]);
  await assert.rejects(
    pool.query('UPDATE lakeside_enrollment.proof_admission SET snapshot_digest=$1 WHERE operation_id=$2', ['b'.repeat(64), operationId]),
    /proof admission receipt is immutable/iu,
  );
});

test('proof expiry while waiting on coordinator locks rolls back admission', async () => {
  const proofSubject = subject('proof-delay');
  const owner = await createLegacyAccount(proofSubject);
  const operationId = createOperationId();
  const proofId = createOperationId();
  await pool.query(
    `INSERT INTO lakeside_enrollment.enrollment_reservation(account_id, source_issuer, source_subject, operation_id)
     VALUES ($1, $2, $3, $4)`,
    [owner.account_id, issuer, proofSubject, operationId],
  );
  const ticks = [0, 0, 1_000];
  const proofApi = createCohortEnrollment(pool, {
    allowedLegacyIdentities: [identity(proofSubject)],
    sourceProofReader: { loadProof: async () => ({
      proof: {
        proofId, snapshotDigest: 'c'.repeat(64), observedAtMs: 1_000, expiresAtMs: 2_000,
      },
      sourceNowMs: 1_000,
    }) },
    monotonicNow: () => ticks.shift(),
  });
  await assert.rejects(proofApi.admitEnrollment({
    reservation: {
      version: 1, sourceIssuer: issuer, sourceSubject: proofSubject,
      canonicalAccountId: owner.account_id, enrollmentOperationId: operationId,
    },
    proofId,
    sourceAccountId: 'fedcba987654321001234567',
    idempotencyKey: idempotency(),
    provenance: 'test:proof-delay',
  }), ProofAdmissionExpiredError);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [operationId])).rows[0].count, '0');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.proof_admission WHERE operation_id=$1', [operationId])).rows[0].count, '0');
});

test('same start operation is idempotent and concurrent distinct operations conflict', async () => {
  const owner = await createLegacyAccount(subject('one'));
  const input = operationInput(subject('one'));
  const results = await Promise.all(Array.from({ length: 12 }, () => enrollment.startEnrollment(input)));
  assert.equal(new Set(results.map(result => result.operationId)).size, 1);
  assert.equal(results[0].status, 'eligible');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.enrollment WHERE account_id=$1', [owner.account_id])).rows[0].count, '1');

  const competitors = await Promise.allSettled(Array.from({ length: 8 }, () => enrollment.startEnrollment(operationInput(subject('one')))));
  assert.equal(competitors.filter(result => result.status === 'fulfilled').length, 0);
  assert.ok(competitors.every(result => result.reason instanceof EnrollmentConflictError));
  const events = await pool.query("SELECT action FROM lakeside_enrollment.audit_event WHERE operation_id=$1 ORDER BY created_at", [input.operationId]);
  assert.deepEqual(events.rows.map(row => row.action), ['enrollment.eligible']);
});

test('exact issuer and subject allowlist is case-sensitive and email is irrelevant', async () => {
  await createLegacyAccount(subject('conflict'));
  const accepted = await enrollment.startEnrollment({
    ...operationInput(subject('conflict')),
    legacyIdentity: { issuer, subject: subject('conflict'), email: 'ignored@example.invalid' },
  });
  assert.equal(accepted.status, 'eligible');
  await assert.rejects(
    enrollment.startEnrollment({ ...operationInput(subject('conflict')), legacyIdentity: { issuer: issuer.toUpperCase(), subject: subject('conflict') } }),
    LegacyIdentityNotAllowedError,
  );
});

test('enrollment is account-wide across exact legacy aliases', async () => {
  const owner = await createLegacyAccount(subject('alias-a'));
  const now = Math.floor(Date.now() / 1000);
  await registry.linkVerifiedIdentity({
    primary: { accountId: owner.account_id, securityVersion: owner.security_version, issuer, subject: subject('alias-a'), authenticatedAt: now },
    secondary: { issuer, subject: subject('alias-b'), authenticatedAt: now },
  }, 'test:alias');
  const allAliases = createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [identity(subject('alias-a')), identity(subject('alias-b'))],
    leaseSeconds: 1,
  });
  const first = await allAliases.startEnrollment(operationInput(subject('alias-a')));
  await assert.rejects(allAliases.startEnrollment(operationInput(subject('alias-b'))), EnrollmentConflictError);
  const firstRoute = await enrollment.getLoginRoute(identity(subject('alias-a')));
  const secondRoute = await enrollment.getLoginRoute(identity(subject('alias-b')));
  assert.equal(firstRoute.status, 'enrolling');
  assert.equal(secondRoute.status, 'enrolling');
  assert.equal(firstRoute.accountId, secondRoute.accountId);
  assert.equal(firstRoute.operationId, secondRoute.operationId);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.enrollment WHERE account_id=$1', [owner.account_id])).rows[0].count, '1');
  assert.equal((await enrollment.getEnrollment(first.operationId)).accountId, owner.account_id);
});

test('an allowlisted identity still needs an authoritative registry mapping', async () => {
  await assert.rejects(enrollment.startEnrollment(operationInput(subject('unmapped'))), /authoritative external identity mapping/);
  assert.deepEqual(await enrollment.getLoginRoute({ issuer: 'urn:lakeside:unknown', subject: subject('unmapped') }), {
    issuer: 'urn:lakeside:unknown',
    subject: subject('unmapped'),
    accountId: null,
    operationId: null,
    enrollmentState: null,
    status: 'unmapped',
    blockedReason: null,
  });
});

test('pause blocks new admissions while admitted operations continue to unified', async () => {
  await createLegacyAccount(subject('pause'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('pause')));
  const paused = await enrollment.pauseAdmissions({ operationId: createOperationId(), idempotencyKey: idempotency(), provenance: 'test:pause' });
  assert.equal(paused.admissionsPaused, true);
  await assert.rejects(enrollment.startEnrollment(operationInput(subject('hold'))), AdmissionPausedError);

  const claimed = await enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', provenance: 'test:claim' });
  const completeInput = {
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claimed.lease.authorityId,
    leaseToken: claimed.lease.leaseToken,
    leaseGeneration: claimed.lease.leaseGeneration,
    provenance: 'test:complete',
  };
  await fenceFor(claimed, 'test:pause-fence');
  const unified = await enrollment.completeEnrollment(completeInput);
  assert.equal(unified.status, 'unified');
  assert.equal((await enrollment.getEnrollment(admitted.operationId)).status, 'unified');
  const pausedUnifiedRoute = await enrollment.getLoginRoute(identity(subject('pause')));
  assert.equal(pausedUnifiedRoute.status, 'unified');
  assert.equal(pausedUnifiedRoute.operationId, admitted.operationId);
  const resumed = await enrollment.resumeAdmissions({ operationId: createOperationId(), idempotencyKey: idempotency(), provenance: 'test:resume' });
  assert.equal(resumed.admissionsPaused, false);
  assert.equal((await enrollment.getRolloutState()).admissionsPaused, false);
});

test('suspended and recovery-held authoritative accounts cannot be admitted', async () => {
  const held = await createLegacyAccount(subject('hold'));
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [held.account_id]);
  await assert.rejects(enrollment.startEnrollment(operationInput(subject('hold'))), EnrollmentAccountSuspendedError);
  const heldRoute = await enrollment.getLoginRoute(identity(subject('hold')));
  assert.equal(heldRoute.status, 'blocked');
  assert.equal(heldRoute.blockedReason, 'recovery_hold');
  assert.equal(heldRoute.operationId, null);
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=false, status=\'suspended\' WHERE account_id=$1', [held.account_id]);
  await assert.rejects(enrollment.startEnrollment(operationInput(subject('hold'))), EnrollmentAccountSuspendedError);
  const suspendedRoute = await enrollment.getLoginRoute(identity(subject('hold')));
  assert.equal(suspendedRoute.status, 'blocked');
  assert.equal(suspendedRoute.blockedReason, 'suspended');
  assert.equal(suspendedRoute.operationId, null);

  const postHold = await createLegacyAccount(subject('post-hold'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('post-hold')));
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [postHold.account_id]);
  await assert.rejects(enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-hold', provenance: 'test:hold' }), EnrollmentAccountSuspendedError);
});

test('lease fencing prevents an expired authority from completing after reclaim', async () => {
  await createLegacyAccount(subject('lease'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('lease')));
  const firstInput = { operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', provenance: 'test:lease-a' };
  const first = await enrollment.claimEnrollment(firstInput);
  await new Promise(resolve => setTimeout(resolve, 1300));
  const second = await enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-b', provenance: 'test:lease-b' });
  assert.notEqual(first.lease.leaseGeneration, second.lease.leaseGeneration);
  await assert.rejects(enrollment.claimEnrollment(firstInput), LeaseExpiredError);
  await assert.rejects(enrollment.completeEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', leaseToken: first.lease.leaseToken, leaseGeneration: first.lease.leaseGeneration, provenance: 'test:late' }), LeaseExpiredError);
  await fenceFor(second, 'test:lease-fence');
  const unified = await enrollment.completeEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-b', leaseToken: second.lease.leaseToken, leaseGeneration: second.lease.leaseGeneration, provenance: 'test:good' });
  assert.equal(unified.status, 'unified');
});

test('active lease and invalid transitions are rejected, while retries return stored results', async () => {
  await createLegacyAccount(subject('lifecycle'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('lifecycle')));
  const claimInput = { operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', provenance: 'test:claim' };
  const claim = await enrollment.claimEnrollment(claimInput);
  assert.deepEqual(await enrollment.claimEnrollment(claimInput), claim);
  await assert.rejects(enrollment.claimEnrollment({ ...claimInput, idempotencyKey: idempotency() }), LeaseHeldError);
  await assert.rejects(enrollment.completeEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', leaseToken: randomBytes(32).toString('base64url'), leaseGeneration: claim.lease.leaseGeneration, provenance: 'test:wrong' }), LeaseExpiredError);
  await assert.rejects(enrollment.startEnrollment({ ...operationInput(subject('lifecycle')), operationId: admitted.operationId }), EnrollmentConflictError);
  const completeInput = { operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'authority-a', leaseToken: claim.lease.leaseToken, leaseGeneration: claim.lease.leaseGeneration, provenance: 'test:complete' };
  await fenceFor(claim, 'test:lifecycle-fence');
  const complete = await enrollment.completeEnrollment(completeInput);
  assert.deepEqual(await enrollment.completeEnrollment(completeInput), complete);
  await assert.rejects(enrollment.completeEnrollment({ ...completeInput, idempotencyKey: idempotency() }), EnrollmentConflictError);
  await assert.rejects(enrollment.claimEnrollment({ ...claimInput, idempotencyKey: idempotency() }), EnrollmentConflictError);
});

test('account fence disables legacy routing and rejects importer retries after lease expiry', async () => {
  await createLegacyAccount(subject('fence'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('fence')));
  const claimInput = { operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'fence-authority', provenance: 'test:fence-claim' };
  const claim = await enrollment.claimEnrollment(claimInput);
  const fenced = await fenceFor(claim, 'test:fence-switch');
  assert.equal(fenced.status, 'fenced');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.account_fence WHERE account_id=$1', [admitted.accountId])).rows[0].count, '1');

  const route = await enrollment.getLoginRoute(identity(subject('fence')));
  assert.equal(route.status, 'enrolling');
  assert.notEqual(route.status, 'legacy');
  await assert.rejects(enrollment.startEnrollment(operationInput(subject('fence'))), EnrollmentFencedError);
  await assert.rejects(enrollment.claimEnrollment(claimInput), EnrollmentFencedError);
  assert.equal((await enrollment.assertMigrationFence({
    operationId: admitted.operationId,
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
  })).accountId, admitted.accountId);

  await new Promise(resolve => setTimeout(resolve, 1300));
  await assert.rejects(enrollment.assertMigrationFence({
    operationId: admitted.operationId,
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
  }), LeaseExpiredError);
  await assert.rejects(enrollment.completeEnrollment({
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:fence-late-complete',
  }), LeaseExpiredError);
  assert.equal((await enrollment.getLoginRoute(identity(subject('fence')))).status, 'enrolling');
});

test('completion without a fence is rejected and concurrent fence attempts have one immutable account owner', async () => {
  await createLegacyAccount(subject('fence-race'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('fence-race')));
  const claim = await enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'race-authority', provenance: 'test:race-claim' });
  await assert.rejects(enrollment.completeEnrollment({
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:race-complete-without-fence',
  }), EnrollmentStateError);
  const attempts = await Promise.allSettled([
    fenceFor(claim, 'test:race-one'),
    fenceFor(claim, 'test:race-two'),
  ]);
  assert.equal(attempts.filter(result => result.status === 'fulfilled').length, 1);
  assert.equal(attempts.filter(result => result.status === 'rejected' && result.reason instanceof EnrollmentFencedError).length, 1);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [admitted.operationId])).rows[0].count, '1');
});

test('completed fence is immutable and importer guard cannot be reused after authority switch', async () => {
  await createLegacyAccount(subject('fence-complete'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('fence-complete')));
  const claim = await enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'complete-authority', provenance: 'test:complete-claim' });
  await fenceFor(claim, 'test:complete-fence');
  await enrollment.assertMigrationFence({
    operationId: admitted.operationId,
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
  });
  const completeInput = {
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:complete',
  };
  assert.equal((await enrollment.completeEnrollment(completeInput)).status, 'unified');
  assert.equal((await enrollment.getLoginRoute(identity(subject('fence-complete')))).status, 'unified');
  await assert.rejects(enrollment.assertMigrationFence({
    operationId: admitted.operationId,
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
  }), LeaseExpiredError);
  await assert.rejects(pool.query(
    'UPDATE lakeside_enrollment.account_fence SET fence_authority=$1 WHERE operation_id=$2',
    ['tampered', admitted.operationId],
  ), /account migration fence is immutable/iu);
});

test('simultaneous identical fence requests record one event and bind audit provenance', async () => {
  const legacy = identity(subject('fence-idempotent'));
  await createLegacyAccount(legacy.subject);
  const api = createCohortEnrollment(pool, { allowUnprovedAdmissions: true, allowedLegacyIdentities: [legacy], leaseSeconds: 5 });
  const admitted = await api.startEnrollment(operationInput(legacy.subject));
  const claim = await api.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'same-fence', provenance: 'test:fence-retry-claim' });
  const input = {
    operationId: admitted.operationId, idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId, leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration, provenance: 'test:fence-retry',
  };
  const results = await Promise.all(Array.from({ length: 8 }, () => api.fenceEnrollment(input)));
  for (const result of results) assert.deepEqual(result, results[0]);
  assert.ok(results[0].leaseExpiresAt);
  assert.equal((await pool.query("SELECT count(*) FROM lakeside_enrollment.audit_event WHERE operation_id=$1 AND action='enrollment.fenced'", [admitted.operationId])).rows[0].count, '1');
  await assert.rejects(api.fenceEnrollment({ ...input, provenance: 'changed-operator' }), IdempotencyConflictError);
  await assert.rejects(pool.query('DELETE FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [admitted.operationId]), /account migration fence is immutable/iu);
});

test('audit failure rolls back the irreversible fence and leaves the lease unchanged', async () => {
  await createLegacyAccount(subject('fence-audit'));
  const admitted = await enrollment.startEnrollment(operationInput(subject('fence-audit')));
  const claim = await enrollment.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'audit-fence-authority', provenance: 'test:fence-audit-claim' });
  await pool.query("ALTER TABLE lakeside_enrollment.audit_event ADD CONSTRAINT test_reject_fence CHECK (provenance <> 'test:reject-fence')");
  try {
    await assert.rejects(enrollment.fenceEnrollment({
      operationId: admitted.operationId,
      idempotencyKey: idempotency(),
      authorityId: claim.lease.authorityId,
      leaseToken: claim.lease.leaseToken,
      leaseGeneration: claim.lease.leaseGeneration,
      provenance: 'test:reject-fence',
    }));
  } finally {
    await pool.query('ALTER TABLE lakeside_enrollment.audit_event DROP CONSTRAINT test_reject_fence');
  }
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [admitted.operationId])).rows[0].count, '0');
  const current = await enrollment.getEnrollment(admitted.operationId);
  assert.equal(current.status, 'enrolling');
  assert.equal(current.lease.authorityId, claim.lease.authorityId);
  assert.equal(current.lease.leaseGeneration, claim.lease.leaseGeneration);
});

test('changed idempotency data and audit failure do not mutate state', async () => {
  await createLegacyAccount(subject('idempotency'));
  const input = operationInput(subject('idempotency'));
  const first = await enrollment.startEnrollment(input);
  await assert.rejects(enrollment.startEnrollment({ ...input, legacyIdentity: identity(subject('one')) }), IdempotencyConflictError);

  await pool.query("ALTER TABLE lakeside_enrollment.audit_event ADD CONSTRAINT test_reject_enrollment CHECK (provenance <> 'test:reject')");
  try {
    await createLegacyAccount(subject('rollback'));
    const rejected = operationInput(subject('rollback'));
    await assert.rejects(enrollment.startEnrollment({ ...rejected, provenance: 'test:reject' }));
    assert.equal(await enrollment.getEnrollment(rejected.operationId), null);
  } finally {
    await pool.query('ALTER TABLE lakeside_enrollment.audit_event DROP CONSTRAINT test_reject_enrollment');
  }
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [first.operationId])).rows[0].count, '1');
});

test('login routing propagates database failures instead of falling back', async () => {
  const brokenPool = new pg.Pool({ database, max: 1 });
  await brokenPool.end();
  const broken = createCohortEnrollment(brokenPool, { allowedLegacyIdentities: [identity(subject('one'))] });
  await assert.rejects(broken.getLoginRoute(identity(subject('one'))), /pool|ended/iu);
});

test('login routing is one read-only snapshot across aliases, holds, fences and unified state', async () => {
  const readOnlyState = await readonlyPool.query("SELECT current_setting('transaction_read_only') AS value");
  assert.equal(readOnlyState.rows[0].value, 'on');
  assert.equal((await readonlyPool.query(
    'SELECT has_table_privilege(current_user, $1, $2) AS can_update',
    ['lakeside_accounts.account', 'UPDATE'],
  )).rows[0].can_update, false);

  const source = subject(`readonly-cohort-${randomUUID()}`);
  const alias = `${source}-alias`;
  const owner = await createLegacyAccount(source);
  const now = Math.floor(Date.now() / 1000);
  await registry.linkVerifiedIdentity({
    primary: { accountId: owner.account_id, securityVersion: owner.security_version, issuer, subject: source, authenticatedAt: now },
    secondary: { issuer, subject: alias, authenticatedAt: now },
  }, 'test:readonly-alias');
  const routeApi = createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [identity(source)],
    leaseSeconds: 5,
  });

  assert.equal((await readonlyEnrollment.getLoginRoute(identity(source))).status, 'legacy');
  assert.equal((await readonlyEnrollment.getLoginRoute({ issuer: 'urn:lakeside:unknown', subject: source })).status, 'unmapped');

  const admitted = await routeApi.startEnrollment(operationInput(source, 'readonly-cohort'));
  const aliasRoute = await readonlyEnrollment.getLoginRoute({ issuer, subject: alias });
  assert.equal(aliasRoute.status, 'enrolling');
  assert.equal(aliasRoute.operationId, admitted.operationId);
  assert.equal(aliasRoute.accountId, owner.account_id);

  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [owner.account_id]);
  const held = await readonlyEnrollment.getLoginRoute(identity(source));
  assert.equal(held.status, 'blocked');
  assert.equal(held.blockedReason, 'recovery_hold');
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=false WHERE account_id=$1', [owner.account_id]);

  const suspendedSource = `readonly-suspended-${randomUUID()}`;
  const suspended = await createLegacyAccount(suspendedSource);
  await pool.query("UPDATE lakeside_accounts.account SET status='suspended' WHERE account_id=$1", [suspended.account_id]);
  const suspendedRoute = await readonlyEnrollment.getLoginRoute(identity(suspendedSource));
  assert.equal(suspendedRoute.status, 'blocked');
  assert.equal(suspendedRoute.blockedReason, 'suspended');
  await pool.query("UPDATE lakeside_accounts.account SET status='active' WHERE account_id=$1", [suspended.account_id]);

  const claim = await routeApi.claimEnrollment({ operationId: admitted.operationId, idempotencyKey: idempotency(), authorityId: 'readonly-route', provenance: 'test:readonly-claim' });
  await routeApi.fenceEnrollment({
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:readonly-fence',
  });
  const fenced = await readonlyEnrollment.getLoginRoute(identity(source));
  assert.equal(fenced.status, 'enrolling');
  assert.notEqual(fenced.status, 'legacy');

  const unified = await routeApi.completeEnrollment({
    operationId: admitted.operationId,
    idempotencyKey: idempotency(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:readonly-complete',
  });
  assert.equal(unified.status, 'unified');
  const unifiedRoute = await readonlyEnrollment.getLoginRoute({ issuer, subject: alias });
  assert.equal(unifiedRoute.status, 'unified');
  assert.equal(unifiedRoute.operationId, admitted.operationId);
});

const importIssuer = 'https://issuer.example.invalid/realms/enrollment';
async function importCase({ leaseSeconds = 30, reader, abortReader, activationReader, bind = true } = {}) {
  const source = subject(randomUUID());
  const destination = randomUUID();
  const owner = await createLegacyAccount(source);
  const linking = createAccountRegistry(pool, { ...options, allowedIssuers: [...options.allowedIssuers, importIssuer] });
  const now = Math.floor(Date.now() / 1000);
  await linking.linkVerifiedIdentity({
    primary: { accountId: owner.account_id, securityVersion: owner.security_version, issuer, subject: source, authenticatedAt: now },
    secondary: { issuer: importIssuer, subject: destination, authenticatedAt: now },
  }, 'test:synthetic-target-proof');
  let evidence;
  let activationEvidence;
  const api = createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [identity(source)], leaseSeconds, allowedImportIssuers: [importIssuer], importReceiptTimeoutMs: 100,
    loadCommittedImportReceipt: reader ?? (async () => evidence),
    loadActivationReceipt: activationReader ?? (async () => activationEvidence),
    ...(abortReader ? { abortImport: abortReader } : {}),
  });
  await api.resumeAdmissions({ operationId: createOperationId(), idempotencyKey: idempotency(), provenance: 'test:import-resume' });
  const started = await api.startEnrollment(operationInput(source));
  const claimed = await api.claimEnrollment({ operationId: started.operationId, idempotencyKey: idempotency(), authorityId: 'synthetic-importer', provenance: 'test:import-claim' });
  const lease = { operationId: started.operationId, authorityId: claimed.lease.authorityId, leaseToken: claimed.lease.leaseToken, leaseGeneration: claimed.lease.leaseGeneration };
  await api.fenceEnrollment({ ...lease, idempotencyKey: idempotency(), provenance: 'test:import-fence' });
  const input = { ...lease, targetIdentity: { issuer: importIssuer, subject: destination, realmId: 'synthetic-realm' }, digestFingerprint: 'a'.repeat(64), provenance: 'test:import-bind' };
  if (!bind) return { api, input, lease, owner, source, destination, operationId: started.operationId };
  const binding = await api.bindCredentialImport(input);
  evidence = { ...binding, receiptId: randomUUID(), state: 'COMMITTED' };
  return { api, binding, input, lease, owner, source, evidence,
    setEvidence: value => { evidence = value; },
    setActivationEvidence: value => { activationEvidence = value; },
    reconcile: provenance => api.reconcileCredentialImport({ operationId: started.operationId, provenance: provenance ?? 'test:reconcile' }) };
}

test('migration 4 preserves v1 binding and receipt bytes and permits exact live v1 replay', async () => {
  const live = await importCase();
  const committed = await importCase();
  await committed.reconcile();
  const originals = await pool.query('SELECT operation_id, binding FROM lakeside_enrollment.import_binding ORDER BY operation_id');
  const receipts = await pool.query('SELECT * FROM lakeside_enrollment.import_receipt ORDER BY operation_id');
  const checksums = await pool.query('SELECT version,checksum FROM lakeside_enrollment.migration WHERE version<4 ORDER BY version');
  // This random test database has no v2 attempts yet. Remove only migration-4
  // structures to exercise a real v3->v4 upgrade with historical v1 evidence.
  for (const table of ['import_live_attempt', 'import_attempt_receipt', 'import_attempt_abort', 'import_v1_abort', 'import_attempt', 'import_attempt_lease']) {
    await pool.query(`DROP TABLE lakeside_enrollment.${table}`);
  }
  await pool.query('DELETE FROM lakeside_enrollment.migration WHERE version=4');
  await migrate(pool);
  assert.deepEqual((await pool.query('SELECT operation_id, binding FROM lakeside_enrollment.import_binding ORDER BY operation_id')).rows, originals.rows);
  assert.deepEqual((await pool.query('SELECT * FROM lakeside_enrollment.import_receipt ORDER BY operation_id')).rows, receipts.rows);
  assert.deepEqual((await pool.query('SELECT version,checksum FROM lakeside_enrollment.migration WHERE version<4 ORDER BY version')).rows, checksums.rows);
  assert.deepEqual(await live.api.bindCredentialImport(live.input), live.binding);
  assert.equal((await committed.reconcile()).status, 'credentialed');
  const backfilled = await pool.query('SELECT binding FROM lakeside_enrollment.import_attempt WHERE attempt_id=$1', [live.binding.operationId]);
  assert.deepEqual(backfilled.rows[0].binding, live.binding);
});

test('issuing a v2 attempt irrevocably prevents a later v1 binding', async () => {
  const item = await importCase({ bind: false });
  const attempt = await item.api.issueImportAttemptLease({
    operationId: item.operationId,
    authorityId: 'v2-authority',
    provenance: 'test:v2-protocol-choice',
  });
  assert.equal(attempt.attemptGeneration, '1');
  await assert.rejects(item.api.completeEnrollment({ ...item.lease, idempotencyKey: idempotency(), provenance: 'test:unbound-completion-bypass' }), /authenticated receipt reconciliation/);
  await assert.rejects(item.api.bindCredentialImport(item.input), EnrollmentConflictError);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_binding WHERE operation_id=$1', [item.operationId])).rows[0].count, '0');
});

test('attempt generation arithmetic stays within PostgreSQL bigint range', async () => {
  const item = await importCase({ bind: false });
  await pool.query(
    `INSERT INTO lakeside_enrollment.import_attempt_lease(
       attempt_id, operation_id, account_id, attempt_generation,
       lease_token_hash, lease_expires_at
     ) VALUES ($1,$2,$3,$4,$5,clock_timestamp() - interval '1 second')`,
    [randomUUID(), item.operationId, item.owner.account_id, '9223372036854775807', 'f'.repeat(64)],
  );
  await assert.rejects(item.api.issueImportAttemptLease({
    operationId: item.operationId,
    authorityId: 'overflow-authority',
    provenance: 'test:generation-overflow',
  }), EnrollmentConflictError);
});

test('authenticated v1 abort preserves the original fence and permits a same-fence retry', async () => {
  const item = await importCase({
    abortReader: async binding => ({ ...binding, receiptId: randomUUID(), state: 'ABORTED' }),
  });
  const beforeFence = (await pool.query('SELECT * FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [item.binding.operationId])).rows[0];
  const beforeLease = (await pool.query('SELECT lease_generation, lease_token_hash FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [item.binding.operationId])).rows[0];
  await item.api.abortCredentialImport({ operationId: item.binding.operationId, provenance: 'test:import-abort' });
  assert.equal((await item.api.getEnrollment(item.binding.operationId)).status, 'enrolling');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '1');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_live_attempt WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '0');

  const afterFence = (await pool.query('SELECT * FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [item.binding.operationId])).rows[0];
  const afterLease = (await pool.query('SELECT lease_generation, lease_token_hash FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [item.binding.operationId])).rows[0];
  assert.deepEqual(afterFence, beforeFence);
  assert.deepEqual(afterLease, beforeLease);

  const retryLease = await item.api.issueImportAttemptLease({ operationId: item.binding.operationId, authorityId: 'retry-authority', provenance: 'test:retry-lease' });
  assert.equal(retryLease.attemptGeneration, '2');
  const retryBinding = await item.api.bindImportAttempt({
    operationId: item.binding.operationId,
    attemptId: retryLease.attemptId,
    attemptGeneration: retryLease.attemptGeneration,
    leaseToken: retryLease.leaseToken,
    targetIdentity: item.input.targetIdentity,
    digestFingerprint: item.input.digestFingerprint,
    provenance: 'test:retry-bind',
  });
  assert.equal(retryBinding.version, 2);
  assert.equal(retryBinding.fenceGeneration, item.binding.fenceGeneration);
  await assert.rejects(item.api.issueImportAttemptLease({ operationId: item.binding.operationId, authorityId: 'third-authority', provenance: 'test:retry-conflict' }), EnrollmentConflictError);
});

test('only an expired unbound attempt lease can be reclaimed, with a new generation', async () => {
  const item = await importCase({
    leaseSeconds: 1,
    abortReader: async binding => ({ ...binding, receiptId: randomUUID(), state: 'ABORTED' }),
  });
  await item.api.abortCredentialImport({ operationId: item.binding.operationId, provenance: 'test:unbound-v1-abort' });
  const first = await item.api.issueImportAttemptLease({ operationId: item.binding.operationId, authorityId: 'unbound-a', provenance: 'test:unbound-first' });
  await new Promise(resolve => setTimeout(resolve, 1100));
  const second = await item.api.issueImportAttemptLease({ operationId: item.binding.operationId, authorityId: 'unbound-b', provenance: 'test:unbound-reclaim' });
  assert.equal(first.attemptGeneration, '2');
  assert.equal(second.attemptGeneration, '3');
  assert.notEqual(first.attemptId, second.attemptId);
});

test('concurrent identical v2 binds converge and a recovery hold blocks abort evidence writes', async () => {
  let abortEvidence;
  let abortCalls = 0;
  const item = await importCase({
    abortReader: async binding => {
      abortCalls += 1;
      return abortEvidence ?? { ...binding, receiptId: randomUUID(), state: 'ABORTED' };
    },
  });
  await item.api.abortCredentialImport({ operationId: item.binding.operationId, provenance: 'test:v1-abort-before-v2' });
  const retryLease = await item.api.issueImportAttemptLease({ operationId: item.binding.operationId, authorityId: 'retry-authority', provenance: 'test:v2-lease' });
  const input = {
    operationId: item.binding.operationId, attemptId: retryLease.attemptId,
    attemptGeneration: retryLease.attemptGeneration, leaseToken: retryLease.leaseToken,
    targetIdentity: item.input.targetIdentity, digestFingerprint: item.input.digestFingerprint,
    provenance: 'test:v2-bind',
  };
  const bound = await Promise.all([item.api.bindImportAttempt(input), item.api.bindImportAttempt(input)]);
  assert.deepEqual(bound[1], bound[0]);
  abortCalls = 0;
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [item.owner.account_id]);
  abortEvidence = { ...bound[0], receiptId: randomUUID(), state: 'ABORTED' };
  await assert.rejects(item.api.abortCredentialImport({ operationId: item.binding.operationId, attemptId: retryLease.attemptId, provenance: 'test:v2-hold-abort' }), EnrollmentAccountSuspendedError);
  assert.equal(abortCalls, 0);
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_attempt_abort WHERE attempt_id=$1', [retryLease.attemptId])).rows[0].count, '0');
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=false WHERE account_id=$1', [item.owner.account_id]);
});

test('import binding is immutable, target-owned, idempotent and cannot use ordinary completion', async () => {
  const item = await importCase();
  assert.deepEqual(await item.api.bindCredentialImport(item.input), item.binding);
  await assert.rejects(item.api.bindCredentialImport({ ...item.input, digestFingerprint: 'b'.repeat(64) }), EnrollmentConflictError);
  await assert.rejects(item.api.bindCredentialImport({ ...item.input, targetIdentity: { ...item.input.targetIdentity, subject: randomUUID() } }), EnrollmentConflictError);
  await assert.rejects(item.api.completeEnrollment({ ...item.lease, idempotencyKey: idempotency(), provenance: 'test:bypass' }), /authenticated receipt reconciliation/);
  await assert.rejects(pool.query('DELETE FROM lakeside_enrollment.import_binding WHERE operation_id=$1', [item.binding.operationId]), /immutable/);
  assert.equal((await item.api.getLoginRoute(identity(item.source))).status, 'enrolling');
});

test('committed receipt holds an expired lease in credentialed state across concurrent retries', async () => {
  const item = await importCase({ leaseSeconds: 1 });
  await new Promise(resolve => setTimeout(resolve, 1100));
  await assert.rejects(item.api.assertMigrationFence(item.lease), LeaseExpiredError);
  const results = await Promise.all(Array.from({ length: 8 }, () => item.reconcile()));
  for (const result of results) assert.equal(result.status, 'credentialed');
  assert.equal((await item.api.getLoginRoute(identity(item.source))).status, 'blocked');
  assert.equal((await pool.query("SELECT count(*) FROM lakeside_enrollment.audit_event WHERE operation_id=$1 AND action='enrollment.import_reconciled'", [item.binding.operationId])).rows[0].count, '1');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.account_fence WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '1');
  await assert.rejects(pool.query('DELETE FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [item.binding.operationId]), /immutable/);
  item.setEvidence({ ...item.evidence, receiptId: randomUUID() });
  await assert.rejects(item.reconcile(), EnrollmentConflictError);
});

test('only exact authenticated activation evidence advances credentialed to unified', async () => {
  const item = await importCase();
  await item.reconcile();
  const binding = await item.api.bindTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-bind',
  });
  assert.equal(binding.importReceiptId, item.evidence.receiptId);
  assert.equal((await item.api.getLoginRoute(identity(item.source))).status, 'blocked');

  item.setActivationEvidence({ ...binding, receiptId: randomUUID(), state: 'MUTATING' });
  await assert.rejects(item.api.reconcileTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-mutating',
  }), EnrollmentConflictError);

  const receiptId = randomUUID();
  item.setActivationEvidence({ ...binding, receiptId, state: 'COMMITTED' });
  const completed = await item.api.reconcileTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-commit',
  });
  assert.equal(completed.status, 'unified');
  assert.equal((await item.api.getLoginRoute(identity(item.source))).status, 'unified');
  const replay = await item.api.reconcileTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-replay',
  });
  assert.equal(replay.status, 'unified');
  assert.equal((await pool.query(
    'SELECT count(*) FROM lakeside_enrollment.activation_receipt WHERE operation_id=$1',
    [item.binding.operationId],
  )).rows[0].count, '1');
});

test('activation timeout aborts its reader and preserves credentialed state', async () => {
  let signal;
  const item = await importCase({
    activationReader: async (_binding, options) => {
      signal = options.signal;
      return new Promise(() => {});
    },
  });
  await item.reconcile();
  await item.api.bindTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-timeout-bind',
  });
  const timed = createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: [identity(item.source)],
    activationReceiptTimeoutMs: 10,
    loadActivationReceipt: async (_binding, options) => {
      signal = options.signal;
      return new Promise(() => {});
    },
  });
  await assert.rejects(timed.reconcileTargetActivation({
    operationId: item.binding.operationId,
    provenance: 'test:activation-timeout',
  }), /unavailable/);
  assert.equal(signal.aborted, true);
  assert.equal((await item.api.getEnrollment(item.binding.operationId)).status, 'credentialed');
  assert.equal((await pool.query(
    'SELECT count(*) FROM lakeside_enrollment.activation_receipt WHERE operation_id=$1',
    [item.binding.operationId],
  )).rows[0].count, '0');
});

test('every receipt binding field must match and MUTATING or absent evidence never completes', async () => {
  const item = await importCase();
  for (const key of Object.keys(item.binding)) {
    item.setEvidence({ ...item.evidence, [key]: typeof item.binding[key] === 'number' ? item.binding[key] + 1 : `${item.binding[key]}-wrong` });
    await assert.rejects(item.reconcile(), EnrollmentConflictError);
  }
  item.setEvidence({ ...item.evidence, attemptId: randomUUID() });
  await assert.rejects(item.reconcile(), EnrollmentConflictError);
  for (const invalid of [null, {}, { ...item.evidence, state: 'MUTATING' }]) {
    item.setEvidence(invalid);
    await assert.rejects(item.reconcile(), EnrollmentConflictError);
  }
  assert.equal((await item.api.getEnrollment(item.binding.operationId)).status, 'enrolling');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '0');
});

test('provider outage and timeout preserve the fence and release database connections', async () => {
  let signal;
  const hanging = await importCase({ reader: async (_binding, options) => { signal = options.signal; return new Promise(() => {}); } });
  await assert.rejects(hanging.reconcile(), /unavailable/);
  assert.equal(signal.aborted, true);
  assert.equal((await hanging.api.getEnrollment(hanging.binding.operationId)).status, 'enrolling');
  const unavailable = await importCase({ reader: async () => { throw new Error('synthetic transport failure'); } });
  await assert.rejects(unavailable.reconcile(), /unavailable/);
  assert.equal(pool.waitingCount, 0);
});

test('a recovery hold or suspension blocks reconciliation and is never cleared', async () => {
  const item = await importCase();
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [item.owner.account_id]);
  await assert.rejects(item.reconcile(), EnrollmentAccountSuspendedError);
  assert.equal((await item.api.getLoginRoute(identity(item.source))).status, 'blocked');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '0');
  await pool.query("UPDATE lakeside_accounts.account SET recovery_hold=false,status='suspended' WHERE account_id=$1", [item.owner.account_id]);
  await assert.rejects(item.reconcile(), EnrollmentAccountSuspendedError);
});

test('receipt, state transition and outbox roll back together on audit failure', async () => {
  const item = await importCase();
  await pool.query("ALTER TABLE lakeside_enrollment.audit_event ADD CONSTRAINT reject_import_receipt CHECK (provenance <> 'test:reject-receipt')");
  try { await assert.rejects(item.reconcile('test:reject-receipt')); }
  finally { await pool.query('ALTER TABLE lakeside_enrollment.audit_event DROP CONSTRAINT reject_import_receipt'); }
  assert.equal((await item.api.getEnrollment(item.binding.operationId)).status, 'enrolling');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [item.binding.operationId])).rows[0].count, '0');
  assert.equal((await item.reconcile()).status, 'credentialed');
});
