const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
const HEX64 = /^[0-9a-f]{64}$/u;
const BINDING_KEYS = [
  'version', 'attemptId', 'attemptGeneration', 'accountId', 'operationId', 'issuer',
  'realmId', 'userId', 'legacyIssuer', 'legacySubject', 'digestFingerprint',
  'credentialAlgorithm', 'hashIterations', 'fenceGeneration', 'fenceTokenHash',
  'fenceExpiresAtMs', 'attemptLeaseTokenHash', 'attemptExpiresAtMs',
];

export class CredentialImportReceiptReadError extends Error {
  constructor() { super('Credential import receipt is unavailable'); this.name = 'CredentialImportReceiptReadError'; }
}
function exactKeys(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const keys = Object.keys(value).sort();
  return keys.length === BINDING_KEYS.length && BINDING_KEYS.every(key => keys.includes(key));
}
function exactHttps(value) {
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash && url.href === value;
  } catch { return false; }
}

export function createCredentialImportReceiptReader(pool, {
  issuer, realmId, schema = 'public', queryTimeoutMs = 3000,
} = {}) {
  if (!exactHttps(issuer) || typeof realmId !== 'string' || !realmId
      || !/^[a-z][a-z0-9_]{0,62}$/u.test(schema) || schema.startsWith('pg_')
      || !Number.isSafeInteger(queryTimeoutMs) || queryTimeoutMs < 100 || queryTimeoutMs > 5000
      || typeof pool?.connect !== 'function' || !Number.isSafeInteger(pool.options?.connectionTimeoutMillis)
      || pool.options.connectionTimeoutMillis < 1 || pool.options.connectionTimeoutMillis > 5000) {
    throw new TypeError('Invalid credential import receipt reader config');
  }
  const sql = `SELECT o.account_id, o.operation_id, o.realm_id, o.user_id,
      o.legacy_issuer, o.legacy_subject, o.digest_fingerprint,
      o.credential_algorithm, o.hash_iterations, o.fence_generation::text,
      o.fence_token_hash, o.fence_expires_ms::text,
      a.attempt_id, a.attempt_generation::text, a.lease_token_hash,
      a.lease_expires_ms::text, a.receipt_id, a.state
    FROM "${schema}".lakeside_enrollment_import_owner o
    JOIN "${schema}".lakeside_enrollment_import_attempt a
      ON a.account_id=o.account_id AND a.operation_id=o.operation_id
    WHERE a.attempt_id=$1 AND o.realm_id=$2 AND o.account_id=$3 AND o.operation_id=$4`;

  return async function load(binding, { signal } = {}) {
    const input = binding && Object.fromEntries(BINDING_KEYS.map(key => [key, binding[key]]));
    if (!exactKeys(binding) || binding.issuer !== issuer || binding.realmId !== realmId
        || !UUID.test(binding.attemptId) || !UUID.test(binding.accountId) || !UUID.test(binding.operationId)
        || signal?.aborted) throw new CredentialImportReceiptReadError();
    let client;
    let broken = false;
    const query = (text, values = []) => client.query({ text, values, query_timeout: queryTimeoutMs });
    try {
      client = await pool.connect();
      if (signal?.aborted) throw new Error();
      await query('BEGIN READ ONLY');
      await query("SELECT set_config('statement_timeout',$1,true)", [String(queryTimeoutMs)]);
      const result = await query(sql, [input.attemptId, realmId, input.accountId, input.operationId]);
      await query('COMMIT');
      if (signal?.aborted) throw new Error();
      if (result.rows.length === 0) return null;
      if (result.rows.length !== 1) throw new Error();
      const row = result.rows[0];
      if (row.state === 'MUTATING') return null;
      const receipt = {
        ...input,
        attemptGeneration: row.attempt_generation,
        accountId: row.account_id,
        operationId: row.operation_id,
        realmId: row.realm_id,
        userId: row.user_id,
        legacyIssuer: row.legacy_issuer,
        legacySubject: row.legacy_subject,
        digestFingerprint: row.digest_fingerprint,
        credentialAlgorithm: row.credential_algorithm,
        hashIterations: row.hash_iterations,
        fenceGeneration: row.fence_generation,
        fenceTokenHash: row.fence_token_hash,
        fenceExpiresAtMs: Number(row.fence_expires_ms),
        attemptId: row.attempt_id,
        attemptLeaseTokenHash: row.lease_token_hash,
        attemptExpiresAtMs: Number(row.lease_expires_ms),
        receiptId: row.receipt_id,
        state: row.state,
      };
      if (!['COMMITTED', 'ABORTED'].includes(receipt.state) || !UUID.test(receipt.receiptId)
          || !UUID.test(receipt.userId) || !HEX64.test(receipt.digestFingerprint)
          || !HEX64.test(receipt.fenceTokenHash) || !HEX64.test(receipt.attemptLeaseTokenHash)
          || !Number.isSafeInteger(receipt.fenceExpiresAtMs) || !Number.isSafeInteger(receipt.attemptExpiresAtMs)) {
        throw new Error();
      }
      for (const key of BINDING_KEYS) if (receipt[key] !== input[key]) throw new Error();
      return Object.freeze(receipt);
    } catch {
      broken = true;
      throw new CredentialImportReceiptReadError();
    } finally { if (client) client.release(broken); }
  };
}
