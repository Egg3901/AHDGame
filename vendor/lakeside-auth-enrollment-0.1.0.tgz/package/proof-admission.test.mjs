import test from 'node:test';
import assert from 'node:assert/strict';
import { createProofBackedAdmission, ProofAdmissionExpiredError } from './proof-admission.mjs';

const reservation = Object.freeze({
  version: 1,
  sourceIssuer: 'https://game.example.test',
  sourceSubject: 'legacy-user',
  canonicalAccountId: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa',
  enrollmentOperationId: 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb',
});
const input = Object.freeze({
  reservation,
  proofId: 'cccccccc-cccc-4ccc-8ccc-cccccccccccc',
  sourceAccountId: '0123456789abcdef01234567',
  idempotencyKey: 'dddddddddddddddddddddddddddddddd',
  provenance: 'test:proof-admission',
});

function observation(overrides = {}) {
  return {
    sourceNowMs: 1_000,
    proof: { expiresAtMs: 2_000 },
    ...overrides,
  };
}

test('loads the exact proof binding before admitting the reserved operation', async () => {
  const calls = [];
  const admission = createProofBackedAdmission({
    proofReader: { loadProof: async value => { calls.push(['proof', value]); return observation(); } },
    enrollment: { startEnrollment: async value => { calls.push(['enrollment', value]); return { status: 'eligible' }; } },
    monotonicNow: (() => { const values = [10, 20]; return () => values.shift(); })(),
  });
  assert.deepEqual(await admission.admit(input), { status: 'eligible' });
  assert.deepEqual(calls, [
    ['proof', {
      proofId: input.proofId,
      sourceAccountId: input.sourceAccountId,
      canonicalAccountId: reservation.canonicalAccountId,
      enrollmentOperationId: reservation.enrollmentOperationId,
    }],
    ['enrollment', {
      operationId: reservation.enrollmentOperationId,
      idempotencyKey: input.idempotencyKey,
      legacyIdentity: { issuer: reservation.sourceIssuer, subject: reservation.sourceSubject },
      provenance: input.provenance,
    }],
  ]);
});

test('does not admit when loader and processing time exhaust proof lifetime', async () => {
  let admitted = false;
  const admission = createProofBackedAdmission({
    proofReader: { loadProof: async () => observation() },
    enrollment: { startEnrollment: async () => { admitted = true; } },
    monotonicNow: (() => { const values = [10, 1_010]; return () => values.shift(); })(),
  });
  await assert.rejects(admission.admit(input), ProofAdmissionExpiredError);
  assert.equal(admitted, false);
});

test('fails closed on invalid reservation and proof binding input', async () => {
  const admission = createProofBackedAdmission({
    proofReader: { loadProof: async () => { throw new Error('must not load'); } },
    enrollment: { startEnrollment: async () => { throw new Error('must not admit'); } },
    monotonicNow: () => 1,
  });
  await assert.rejects(admission.admit({ ...input, reservation: { ...reservation, canonicalAccountId: 'chosen' } }), TypeError);
  await assert.rejects(admission.admit({ ...input, extra: true }), TypeError);
});

test('accepts the production monotonic clock default and rejects unknown configuration', () => {
  assert.doesNotThrow(() => createProofBackedAdmission({
    proofReader: { loadProof: async () => observation() },
    enrollment: { startEnrollment: async () => ({ status: 'eligible' }) },
  }));
  assert.throws(() => createProofBackedAdmission({
    proofReader: { loadProof: async () => observation() },
    enrollment: { startEnrollment: async () => ({ status: 'eligible' }) },
    transportToken: 'must-not-be-accepted',
  }), TypeError);
});
