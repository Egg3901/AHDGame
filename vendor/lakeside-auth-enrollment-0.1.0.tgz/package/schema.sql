CREATE TABLE lakeside_enrollment.rollout_control (
  control_id boolean PRIMARY KEY DEFAULT true CHECK (control_id),
  admissions_paused boolean NOT NULL DEFAULT true,
  revision bigint NOT NULL DEFAULT 0 CHECK (revision >= 0),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO lakeside_enrollment.rollout_control(control_id)
VALUES (true)
ON CONFLICT (control_id) DO NOTHING;

CREATE TABLE lakeside_enrollment.enrollment (
  operation_id uuid PRIMARY KEY,
  issuer text NOT NULL CHECK (length(issuer) BETWEEN 1 AND 512),
  subject text NOT NULL CHECK (length(subject) BETWEEN 1 AND 512),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  state text NOT NULL CHECK (state IN ('eligible', 'enrolling', 'credentialed', 'unified')),
  lease_generation bigint NOT NULL DEFAULT 0 CHECK (lease_generation >= 0),
  lease_authority text,
  lease_token text,
  lease_token_hash text,
  lease_expires_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  unified_at timestamptz,
  UNIQUE (issuer, subject),
  UNIQUE (account_id),
  CHECK (
    (state = 'enrolling'
      AND lease_authority IS NOT NULL
      AND lease_token IS NOT NULL
      AND lease_token_hash IS NOT NULL
      AND lease_expires_at IS NOT NULL)
    OR
    (state <> 'enrolling'
      AND lease_authority IS NULL
      AND lease_token IS NULL
      AND lease_token_hash IS NULL
      AND lease_expires_at IS NULL)
  )
);

CREATE TABLE lakeside_enrollment.request (
  request_id uuid PRIMARY KEY,
  operation_id uuid NOT NULL REFERENCES lakeside_enrollment.enrollment(operation_id),
  phase text NOT NULL CHECK (phase IN ('start', 'claim', 'complete')),
  idempotency_hash text NOT NULL CHECK (length(idempotency_hash) = 64),
  request_fingerprint text NOT NULL CHECK (length(request_fingerprint) = 64),
  result jsonb NOT NULL CHECK (jsonb_typeof(result) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (phase, idempotency_hash),
  UNIQUE (operation_id, phase, idempotency_hash)
);
CREATE INDEX enrollment_request_operation_idx ON lakeside_enrollment.request(operation_id, phase);

CREATE TABLE lakeside_enrollment.control_request (
  request_id uuid PRIMARY KEY,
  operation_id uuid NOT NULL UNIQUE,
  idempotency_hash text NOT NULL UNIQUE CHECK (length(idempotency_hash) = 64),
  request_fingerprint text NOT NULL CHECK (length(request_fingerprint) = 64),
  result jsonb NOT NULL CHECK (jsonb_typeof(result) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE lakeside_enrollment.audit_event (
  event_id uuid PRIMARY KEY,
  operation_id uuid REFERENCES lakeside_enrollment.enrollment(operation_id),
  account_id uuid REFERENCES lakeside_accounts.account(account_id),
  action text NOT NULL CHECK (length(action) BETWEEN 1 AND 128),
  provenance text NOT NULL CHECK (length(provenance) BETWEEN 1 AND 256),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb CHECK (jsonb_typeof(metadata) = 'object'),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX enrollment_audit_operation_idx ON lakeside_enrollment.audit_event(operation_id, created_at);
CREATE INDEX enrollment_audit_account_idx ON lakeside_enrollment.audit_event(account_id, created_at);

CREATE TABLE lakeside_enrollment.outbox (
  event_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.audit_event(event_id),
  available_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz
);
