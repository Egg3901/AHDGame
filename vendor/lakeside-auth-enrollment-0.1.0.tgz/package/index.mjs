import { createHash, randomBytes, randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createImportReconciliation } from './import-reconciliation.mjs';
import { createActivationReconciliation } from './activation-reconciliation.mjs';
import { createProofBackedAdmission, ProofAdmissionExpiredError } from './proof-admission.mjs';

export {
  createEnrollmentReservationStore,
  ReservationConflictError,
  ReservationSuspendedError,
  SourceIdentityNotMappedError,
  SourceIssuerNotAllowedError,
} from './reservation.mjs';
export { createProofBackedAdmission, ProofAdmissionExpiredError } from './proof-admission.mjs';
export { createCredentialImportDispatcher, CredentialImportDispatchError } from './import-dispatch.mjs';
export { createCredentialImportReceiptReader, CredentialImportReceiptReadError } from './import-receipt-reader.mjs';
export { createSourceOwnershipProofReader, SourceOwnershipProofReadError } from './source-proof-reader.mjs';
export { createCentralFenceAttestationReader, CentralFenceAttestationReadError } from './central-fence-attestation-reader.mjs';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu;
const OPAQUE_RE = /^[A-Za-z0-9_-]{32,256}$/u;
const IDENTITY_LIMIT = 512;

export class AuthEnrollmentError extends Error {
  constructor(message, name = 'AuthEnrollmentError') { super(message); this.name = name; }
}
export class AdmissionPausedError extends AuthEnrollmentError {
  constructor() { super('New cohort admissions are paused', 'AdmissionPausedError'); }
}
export class ProofAdmissionRequiredError extends AuthEnrollmentError {
  constructor() { super('Authenticated source ownership proof is required for enrollment admission', 'ProofAdmissionRequiredError'); }
}
export class LegacyIdentityNotAllowedError extends AuthEnrollmentError {
  constructor() { super('Legacy issuer and subject are not in the exact enrollment allowlist', 'LegacyIdentityNotAllowedError'); }
}
export class LegacyIdentityNotMappedError extends AuthEnrollmentError {
  constructor() { super('Legacy identity has no authoritative external identity mapping', 'LegacyIdentityNotMappedError'); }
}
export class EnrollmentAccountSuspendedError extends AuthEnrollmentError {
  constructor() { super('Authoritative account is suspended or on recovery hold', 'EnrollmentAccountSuspendedError'); }
}
export class EnrollmentNotFoundError extends AuthEnrollmentError {
  constructor() { super('Enrollment operation was not found', 'EnrollmentNotFoundError'); }
}
export class EnrollmentConflictError extends AuthEnrollmentError {
  constructor() { super('Enrollment operation conflicts with an existing ownership or state claim', 'EnrollmentConflictError'); }
}
export class EnrollmentFencedError extends EnrollmentConflictError {
  constructor() { super(); this.name = 'EnrollmentFencedError'; this.message = 'Canonical account has crossed the irreversible legacy-auth fence'; }
}
export class IdempotencyConflictError extends AuthEnrollmentError {
  constructor() { super('Idempotency key was reused with different operation data', 'IdempotencyConflictError'); }
}
export class EnrollmentStateError extends AuthEnrollmentError {
  constructor(message = 'Enrollment transition is not valid for the current state') { super(message, 'EnrollmentStateError'); }
}
export class LeaseHeldError extends AuthEnrollmentError {
  constructor() { super('Enrollment is leased by another active authority', 'LeaseHeldError'); }
}
export class LeaseExpiredError extends AuthEnrollmentError {
  constructor() { super('Enrollment lease is expired or fenced by a newer authority', 'LeaseExpiredError'); }
}

function text(value, max, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u001f\u007f]/u.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}

function uuid(value, label = 'operation ID') {
  if (typeof value !== 'string' || !UUID_RE.test(value)) throw new TypeError(`Invalid ${label}`);
  return value.toLowerCase();
}

function opaque(value, label) {
  if (typeof value !== 'string' || !OPAQUE_RE.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}

function identity(value) {
  return {
    issuer: text(value?.issuer, IDENTITY_LIMIT, 'issuer'),
    subject: text(value?.subject, IDENTITY_LIMIT, 'subject'),
  };
}

function identityKey({ issuer, subject }) { return JSON.stringify([issuer, subject]); }
function digest(value) { return createHash('sha256').update(value).digest('hex'); }
function idempotencyHash(value) { return digest(value); }
function fingerprint(value) { return digest(JSON.stringify(value)); }

export function createOperationId() { return randomUUID(); }
export function createIdempotencyKey() { return randomBytes(32).toString('base64url'); }

async function transaction(pool, operation) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL lock_timeout = '5s'");
    await client.query("SET LOCAL statement_timeout = '10s'");
    const result = await operation(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

async function serializeKey(client, value) {
  await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1, 0))', [value]);
}

async function audit(client, { operationId = null, accountId = null, action, provenance, metadata = {} }) {
  const eventId = randomUUID();
  await client.query(
    `INSERT INTO lakeside_enrollment.audit_event(event_id, operation_id, account_id, action, provenance, metadata)
     VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
    [eventId, operationId, accountId, action, provenance, JSON.stringify(metadata)],
  );
  await client.query('INSERT INTO lakeside_enrollment.outbox(event_id) VALUES ($1)', [eventId]);
}

function iso(value) {
  return value == null ? null : new Date(value).toISOString();
}

function publicEnrollment(row, includeLeaseToken = false) {
  const result = {
    operationId: row.operation_id,
    issuer: row.issuer,
    subject: row.subject,
    accountId: row.account_id,
    status: row.state,
  };
  if (row.state === 'enrolling') {
    result.lease = {
      authorityId: row.lease_authority,
      leaseGeneration: String(row.lease_generation),
      leaseExpiresAt: iso(row.lease_expires_at),
    };
    if (includeLeaseToken) result.lease.leaseToken = row.lease_token;
  } else {
    result.lease = null;
  }
  if (row.unified_at != null) result.unifiedAt = iso(row.unified_at);
  return result;
}

function publicLoginRoute(item, account = null, operation = null, fence = null) {
  const result = {
    issuer: item.issuer,
    subject: item.subject,
    accountId: account?.account_id ?? null,
    operationId: operation?.operation_id ?? null,
    enrollmentState: operation?.state ?? null,
  };
  if (!account) return { ...result, status: 'unmapped', blockedReason: null };
  if (account.status !== 'active' || account.recovery_hold !== false) {
    return {
      ...result,
      status: 'blocked',
      blockedReason: account.recovery_hold === true ? 'recovery_hold' : 'suspended',
    };
  }
  if (!operation) {
    // A fence without its operation is an inconsistent database state. Fail
    // closed rather than ever handing this account to legacy auth.
    if (fence) return { ...result, status: 'blocked', blockedReason: 'migration_fence' };
    return { ...result, status: 'legacy', blockedReason: null };
  }
  if (operation.state === 'unified') return { ...result, status: 'unified', blockedReason: null };
  if (operation.state === 'eligible' && fence) {
    return { ...result, status: 'blocked', blockedReason: 'migration_fence' };
  }
  if (operation.state !== 'eligible' && operation.state !== 'enrolling') {
    return { ...result, status: 'blocked', blockedReason: 'migration_fence' };
  }
  return {
    ...result,
    status: 'enrolling',
    blockedReason: null,
    leaseExpiresAt: operation.state === 'enrolling' ? iso(operation.lease_expires_at) : null,
  };
}

function storedResult(row) { return row?.result ?? null; }

async function existingRequest(client, phase, keyHash, requestFingerprint) {
  const { rows } = await client.query(
    'SELECT request_fingerprint, result FROM lakeside_enrollment.request WHERE phase=$1 AND idempotency_hash=$2',
    [phase, keyHash],
  );
  if (!rows[0]) return null;
  if (rows[0].request_fingerprint !== requestFingerprint) throw new IdempotencyConflictError();
  return storedResult(rows[0]);
}

async function insertRequest(client, { operationId, phase, keyHash, requestFingerprint, result }) {
  await client.query(
    `INSERT INTO lakeside_enrollment.request(request_id, operation_id, phase, idempotency_hash, request_fingerprint, result)
     VALUES ($1, $2, $3, $4, $5, $6::jsonb)`,
    [randomUUID(), operationId, phase, keyHash, requestFingerprint, JSON.stringify(result)],
  );
}

async function existingControlRequest(client, operationId, keyHash, requestFingerprint) {
  const { rows: byKey } = await client.query(
    'SELECT operation_id, request_fingerprint, result FROM lakeside_enrollment.control_request WHERE idempotency_hash=$1',
    [keyHash],
  );
  if (byKey[0]) {
    if (byKey[0].operation_id !== operationId || byKey[0].request_fingerprint !== requestFingerprint) throw new IdempotencyConflictError();
    return storedResult(byKey[0]);
  }
  const { rows: byOperation } = await client.query(
    'SELECT request_fingerprint FROM lakeside_enrollment.control_request WHERE operation_id=$1',
    [operationId],
  );
  if (byOperation[0]) throw new EnrollmentConflictError();
  return null;
}

function configuredIdentities(values) {
  if (!Array.isArray(values) || values.length === 0) throw new TypeError('A non-empty exact legacy identity allowlist is required');
  const allowed = new Set();
  for (const value of values) {
    const item = identity(value);
    const key = identityKey(item);
    if (allowed.has(key)) throw new TypeError('Legacy identity allowlist contains a duplicate');
    allowed.add(key);
  }
  return allowed;
}

async function lockActiveEnrollment(client, operationId) {
  // Account is the first lock in every enrollment path. The operation lock
  // follows it. The registry mapping is immutable, so it is rechecked without
  // taking a second row lock.
  const { rows: references } = await client.query(
    'SELECT account_id::text, issuer, subject FROM lakeside_enrollment.enrollment WHERE operation_id=$1',
    [operationId],
  );
  if (!references[0]) throw new EnrollmentNotFoundError();
  const reference = references[0];
  const { rows: accounts } = await client.query(
    `SELECT account_id::text, status, recovery_hold
       FROM lakeside_accounts.account a
      WHERE account_id=$1
      FOR UPDATE`,
    [reference.account_id],
  );
  if (!accounts[0]) throw new LegacyIdentityNotMappedError();
  if (accounts[0].status !== 'active' || accounts[0].recovery_hold !== false) throw new EnrollmentAccountSuspendedError();
  const { rows: mappings } = await client.query(
    `SELECT account_id::text
       FROM lakeside_accounts.external_identity
      WHERE issuer=$1 AND subject=$2 AND account_id=$3
    `,
    [reference.issuer, reference.subject, reference.account_id],
  );
  if (!mappings[0]) throw new LegacyIdentityNotMappedError();
  const { rows: operations } = await client.query(
    'SELECT * FROM lakeside_enrollment.enrollment WHERE operation_id=$1 FOR UPDATE',
    [operationId],
  );
  if (!operations[0]) throw new EnrollmentNotFoundError();
  return operations[0];
}

async function lockAccountFence(client, accountId) {
  const { rows } = await client.query(
    'SELECT account_id::text, operation_id, fence_generation::text, fence_authority, fence_token_hash, fenced_at FROM lakeside_enrollment.account_fence WHERE account_id=$1 FOR UPDATE',
    [accountId],
  );
  return rows[0] ?? null;
}

function leaseMatches(row, { authorityId, leaseToken, leaseGeneration }, now) {
  return row.lease_authority === authorityId
    && String(row.lease_generation) === String(leaseGeneration)
    && row.lease_token_hash === digest(leaseToken)
    && row.lease_expires_at != null
    && new Date(row.lease_expires_at) > now;
}

function fenceMatches(fence, { operationId, authorityId, leaseToken, leaseGeneration }) {
  return fence != null
    && fence.operation_id === operationId
    && fence.fence_authority === authorityId
    && String(fence.fence_generation) === String(leaseGeneration)
    && fence.fence_token_hash === digest(leaseToken);
}

export async function migrate(pool) {
  const migrations = await Promise.all(['schema.sql', 'schema-002.sql', 'schema-003.sql', 'schema-004.sql', 'schema-005.sql', 'schema-006.sql', 'schema-007.sql', 'schema-008.sql'].map(async (file, index) => {
    const sql = await readFile(new URL(`./${file}`, import.meta.url), 'utf8');
    return { version: index + 1, sql, checksum: digest(sql) };
  }));
  return transaction(pool, async client => {
    await client.query('SELECT pg_advisory_xact_lock(1684280517)');
    const { rows: recoveryColumns } = await client.query(
      `SELECT data_type, is_nullable
         FROM information_schema.columns
        WHERE table_schema='lakeside_accounts'
          AND table_name='account'
          AND column_name='recovery_hold'`,
    );
    if (!recoveryColumns[0] || recoveryColumns[0].data_type !== 'boolean' || recoveryColumns[0].is_nullable !== 'NO') {
      throw new Error('Account registry migration 3 with required boolean recovery_hold is required before auth enrollment migration');
    }
    await client.query('CREATE SCHEMA IF NOT EXISTS lakeside_enrollment');
    await client.query(`
      CREATE TABLE IF NOT EXISTS lakeside_enrollment.migration (
        version integer PRIMARY KEY,
        checksum text NOT NULL,
        applied_at timestamptz NOT NULL DEFAULT now()
      )`);
    for (const migration of migrations) {
      const { rows } = await client.query('SELECT checksum FROM lakeside_enrollment.migration WHERE version=$1', [migration.version]);
      if (rows[0]) {
        if (rows[0].checksum !== migration.checksum) throw new Error(`Applied auth enrollment migration ${migration.version} checksum differs`);
        continue;
      }
      await client.query(migration.sql);
      await client.query('INSERT INTO lakeside_enrollment.migration(version, checksum) VALUES ($1, $2)', [migration.version, migration.checksum]);
    }
  });
}

/**
 * Trusted backend boundary. The caller must provide an allowlisted exact
 * issuer and subject that the authoritative account registry already owns.
 * This module has no HTTP surface and accepts no email or arbitrary account.
 */
export function createCohortEnrollment(pool, options = {}) {
  if (!pool || typeof pool.connect !== 'function' || typeof pool.query !== 'function') throw new TypeError('A pg pool is required');
  const allowed = configuredIdentities(options.allowedLegacyIdentities);
  const leaseSeconds = options.leaseSeconds ?? 60;
  if (!Number.isInteger(leaseSeconds) || leaseSeconds < 1 || leaseSeconds > 3600) throw new TypeError('leaseSeconds must be an integer from 1 through 3600');

  const assertAllowed = item => {
    if (!allowed.has(identityKey(item))) throw new LegacyIdentityNotAllowedError();
  };

  async function startEnrollmentCore({ operationId, idempotencyKey, legacyIdentity, provenance }, proofContext = null) {
    operationId = uuid(operationId);
    idempotencyKey = opaque(idempotencyKey, 'idempotency key');
    const item = identity(legacyIdentity);
    provenance = text(provenance, 256, 'provenance');
    const keyHash = idempotencyHash(idempotencyKey);
    const admittedProofId = proofContext?.observation?.proof?.proofId ?? null;
    const requestFingerprint = fingerprint({ operationId, issuer: item.issuer, subject: item.subject, admittedProofId });
    return transaction(pool, async client => {
      await serializeKey(client, `start:${keyHash}`);
      const retry = await existingRequest(client, 'start', keyHash, requestFingerprint);
      if (retry) {
        if (proofContext) {
          const { rows } = await client.query(
            'SELECT proof_id::text FROM lakeside_enrollment.proof_admission WHERE operation_id=$1 AND proof_id=$2',
            [operationId, admittedProofId],
          );
          if (!rows[0]) throw new EnrollmentConflictError();
        }
        return retry;
      }
      assertAllowed(item);
      await serializeKey(client, `start-operation:${operationId}`);

      const { rows: initialControl } = await client.query('SELECT admissions_paused FROM lakeside_enrollment.rollout_control WHERE control_id=true');
      if (!initialControl[0]) throw new Error('Enrollment rollout control is missing');
      if (initialControl[0].admissions_paused) throw new AdmissionPausedError();

      const mapping = await client.query(
        `SELECT ei.account_id::text
           FROM lakeside_accounts.external_identity ei
           JOIN lakeside_accounts.account a ON a.account_id=ei.account_id
          WHERE ei.issuer=$1 AND ei.subject=$2
        `,
        [item.issuer, item.subject],
      );
      if (!mapping.rows[0]) throw new LegacyIdentityNotMappedError();
      const { rows: accounts } = await client.query(
        `SELECT account_id::text, status, recovery_hold
           FROM lakeside_accounts.account
          WHERE account_id=$1
          FOR UPDATE`,
        [mapping.rows[0].account_id],
      );
      if (!accounts[0]) throw new LegacyIdentityNotMappedError();
      const account = accounts[0];
      if (account.status !== 'active' || account.recovery_hold !== false) throw new EnrollmentAccountSuspendedError();

      // The account fence is authoritative even if an importer left an
      // incomplete operation row. Once present, this account can never start
      // another legacy enrollment or fall back to legacy auth.
      const existingFence = await lockAccountFence(client, account.account_id);
      if (existingFence) throw new EnrollmentFencedError();

      const { rows: verifiedMapping } = await client.query(
        `SELECT account_id::text
           FROM lakeside_accounts.external_identity
          WHERE issuer=$1 AND subject=$2 AND account_id=$3`,
        [item.issuer, item.subject, account.account_id],
      );
      if (!verifiedMapping[0]) throw new LegacyIdentityNotMappedError();

      if (proofContext) {
        const elapsedMs = proofContext.monotonicNow() - proofContext.startedAt;
        if (!Number.isFinite(elapsedMs) || elapsedMs < 0) throw new TypeError('Monotonic clock moved backwards');
        const { proof, sourceNowMs } = proofContext.observation;
        if (sourceNowMs + elapsedMs >= proof.expiresAtMs) throw new ProofAdmissionExpiredError();
        const reservation = proofContext.reservation;
        const { rows: reservations } = await client.query(
          `SELECT account_id::text
             FROM lakeside_enrollment.enrollment_reservation
            WHERE operation_id=$1 AND account_id=$2 AND source_issuer=$3 AND source_subject=$4`,
          [operationId, account.account_id, item.issuer, item.subject],
        );
        if (!reservations[0]) throw new EnrollmentConflictError();
      }

      const { rows: operationRows } = await client.query(
        'SELECT account_id::text FROM lakeside_enrollment.enrollment WHERE operation_id=$1',
        [operationId],
      );
      if (operationRows[0]) throw new EnrollmentConflictError();

      // Account-wide uniqueness prevents another exact legacy alias from
      // creating a second enrollment operation for the same canonical user.
      const { rows: existingAccount } = await client.query(
        'SELECT operation_id FROM lakeside_enrollment.enrollment WHERE account_id=$1 FOR UPDATE',
        [account.account_id],
      );
      if (existingAccount[0]) throw new EnrollmentConflictError();

      const { rows: controlRows } = await client.query('SELECT admissions_paused FROM lakeside_enrollment.rollout_control WHERE control_id=true FOR UPDATE');
      if (!controlRows[0]) throw new Error('Enrollment rollout control is missing');
      if (controlRows[0].admissions_paused) throw new AdmissionPausedError();

      await client.query(
        `INSERT INTO lakeside_enrollment.enrollment(operation_id, issuer, subject, account_id, state)
         VALUES ($1, $2, $3, $4, 'eligible')`,
        [operationId, item.issuer, item.subject, account.account_id],
      );
      if (proofContext) {
        const { proof, sourceNowMs } = proofContext.observation;
        await client.query(
          `INSERT INTO lakeside_enrollment.proof_admission(
             operation_id, proof_id, source_account_id, snapshot_digest,
             source_observed_at, source_expires_at, source_now_at_load
           ) VALUES ($1, $2, $3, $4, to_timestamp($5 / 1000.0),
                     to_timestamp($6 / 1000.0), to_timestamp($7 / 1000.0))`,
          [operationId, proof.proofId, proofContext.sourceAccountId, proof.snapshotDigest,
            proof.observedAtMs, proof.expiresAtMs, sourceNowMs],
        );
      }
      const result = {
        operationId,
        issuer: item.issuer,
        subject: item.subject,
        accountId: account.account_id,
        status: 'eligible',
        lease: null,
      };
      await insertRequest(client, { operationId, phase: 'start', keyHash, requestFingerprint, result });
      await audit(client, {
        operationId,
        accountId: account.account_id,
        action: 'enrollment.eligible',
        provenance,
        metadata: { state: 'eligible' },
      });
      return result;
    });
  }

  async function startEnrollment(input) {
    if (options.allowUnprovedAdmissions !== true) throw new ProofAdmissionRequiredError();
    return startEnrollmentCore(input);
  }

  let admitEnrollment;
  if (options.sourceProofReader) {
    const admission = createProofBackedAdmission({
      enrollment: { startEnrollment: startEnrollmentCore },
      proofReader: options.sourceProofReader,
      ...(options.monotonicNow ? { monotonicNow: options.monotonicNow } : {}),
    });
    admitEnrollment = admission.admit;
  } else {
    admitEnrollment = async () => { throw new ProofAdmissionRequiredError(); };
  }

  async function claimEnrollment({ operationId, idempotencyKey, authorityId, provenance }) {
    operationId = uuid(operationId);
    idempotencyKey = opaque(idempotencyKey, 'idempotency key');
    authorityId = text(authorityId, 128, 'authority ID');
    provenance = text(provenance, 256, 'provenance');
    const keyHash = idempotencyHash(idempotencyKey);
    const requestFingerprint = fingerprint({ operationId, authorityId });
    return transaction(pool, async client => {
      await serializeKey(client, `claim:${keyHash}`);
      const retry = await existingRequest(client, 'claim', keyHash, requestFingerprint);
      if (retry) {
        // A durable request result is not itself a current lease. Recheck the
        // authoritative account and the fenced lease before returning it.
        const current = await lockActiveEnrollment(client, operationId);
        if (await lockAccountFence(client, current.account_id)) throw new EnrollmentFencedError();
        if (current.state !== 'enrolling' || !retry.lease?.leaseToken) throw new LeaseExpiredError();
        const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
        const now = new Date(clockRows[0].now);
        const currentLease = current.lease_authority === retry.lease.authorityId
          && String(current.lease_generation) === String(retry.lease.leaseGeneration)
          && current.lease_token_hash === digest(retry.lease.leaseToken)
          && current.lease_expires_at != null
          && new Date(current.lease_expires_at) > now;
        if (!currentLease) throw new LeaseExpiredError();
        return retry;
      }
      const current = await lockActiveEnrollment(client, operationId);
      if (await lockAccountFence(client, current.account_id)) throw new EnrollmentFencedError();
      if (current.state === 'unified') throw new EnrollmentConflictError();

      const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
      const now = new Date(clockRows[0].now);
      const activeLease = current.state === 'enrolling' && current.lease_expires_at != null && new Date(current.lease_expires_at) > now;
      if (activeLease) throw new LeaseHeldError();

      const token = randomBytes(32).toString('base64url');
      const tokenHash = digest(token);
      const generation = BigInt(current.lease_generation) + 1n;
      const expiresAt = new Date(now.getTime() + leaseSeconds * 1000);
      const { rows: updated } = await client.query(
        `UPDATE lakeside_enrollment.enrollment
            SET state='enrolling', lease_generation=$2, lease_authority=$3,
                lease_token=$4, lease_token_hash=$5, lease_expires_at=$6, updated_at=clock_timestamp()
          WHERE operation_id=$1
          RETURNING *`,
        [operationId, generation.toString(), authorityId, token, tokenHash, expiresAt],
      );
      const result = publicEnrollment(updated[0], true);
      await insertRequest(client, { operationId, phase: 'claim', keyHash, requestFingerprint, result });
      await audit(client, {
        operationId,
        accountId: updated[0].account_id,
        action: current.state === 'enrolling' ? 'enrollment.lease.reclaimed' : 'enrollment.lease.claimed',
        provenance,
        metadata: { state: 'enrolling', authorityId, leaseGeneration: generation.toString() },
      });
      return result;
    });
  }

  /**
   * Permanently disables legacy fallback for this canonical account while the
   * current importer lease is still valid. Provider-side atomic enforcement
   * must also consume this binding; a separate assertMigrationFence call is
   * only a ledger check and cannot close an external check/use race.
   */
  async function fenceEnrollment({ operationId, idempotencyKey, authorityId, leaseToken, leaseGeneration, provenance }) {
    operationId = uuid(operationId);
    idempotencyKey = opaque(idempotencyKey, 'idempotency key');
    authorityId = text(authorityId, 128, 'authority ID');
    leaseToken = opaque(leaseToken, 'lease token');
    if (typeof leaseGeneration !== 'string' && typeof leaseGeneration !== 'number') throw new TypeError('Invalid lease generation');
    if (!/^[1-9][0-9]{0,18}$/u.test(String(leaseGeneration))) throw new TypeError('Invalid lease generation');
    leaseGeneration = String(leaseGeneration);
    provenance = text(provenance, 256, 'provenance');
    const keyHash = idempotencyHash(idempotencyKey);
    const requestFingerprint = fingerprint({ operationId, authorityId, leaseGeneration, leaseTokenHash: digest(leaseToken), provenance });
    return transaction(pool, async client => {
      await serializeKey(client, `fence:${keyHash}`);
      const retry = await existingRequest(client, 'fence', keyHash, requestFingerprint);
      const current = await lockActiveEnrollment(client, operationId);
      const existingFence = await lockAccountFence(client, current.account_id);
      const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
      const now = new Date(clockRows[0].now);

      if (retry) {
        // A stored fence result is not a reusable permit. The original lease
        // and immutable account fence must still be current for a retry.
        if (!fenceMatches(existingFence, { operationId, authorityId, leaseToken, leaseGeneration })
          || !leaseMatches(current, { authorityId, leaseToken, leaseGeneration }, now)) throw new LeaseExpiredError();
        return retry;
      }
      if (existingFence || current.state === 'unified') throw new EnrollmentFencedError();
      if (current.state !== 'enrolling') throw new EnrollmentStateError('Only an enrolling operation can cross the migration fence');
      if (!leaseMatches(current, { authorityId, leaseToken, leaseGeneration }, now)) throw new LeaseExpiredError();

      await client.query(
        `INSERT INTO lakeside_enrollment.account_fence(
           account_id, operation_id, fence_generation, fence_authority, fence_token_hash
         ) VALUES ($1, $2, $3, $4, $5)`,
        [current.account_id, operationId, leaseGeneration, authorityId, digest(leaseToken)],
      );
      const result = {
        operationId,
        accountId: current.account_id,
        status: 'fenced',
        fenceGeneration: leaseGeneration,
        leaseExpiresAt: iso(current.lease_expires_at),
      };
      await insertRequest(client, { operationId, phase: 'fence', keyHash, requestFingerprint, result });
      await audit(client, {
        operationId,
        accountId: current.account_id,
        action: 'enrollment.fenced',
        provenance,
        metadata: { state: 'enrolling', authorityId, fenceGeneration: leaseGeneration },
      });
      return result;
    });
  }

  /**
   * Read-only importer guard. It is intentionally tied to the live lease and
   * immutable account fence. After completion, expiry, or reclaim it rejects.
   */
  async function assertMigrationFence({ operationId, authorityId, leaseToken, leaseGeneration }) {
    operationId = uuid(operationId);
    authorityId = text(authorityId, 128, 'authority ID');
    leaseToken = opaque(leaseToken, 'lease token');
    if (typeof leaseGeneration !== 'string' && typeof leaseGeneration !== 'number') throw new TypeError('Invalid lease generation');
    if (!/^[1-9][0-9]{0,18}$/u.test(String(leaseGeneration))) throw new TypeError('Invalid lease generation');
    leaseGeneration = String(leaseGeneration);
    return transaction(pool, async client => {
      const current = await lockActiveEnrollment(client, operationId);
      const fence = await lockAccountFence(client, current.account_id);
      const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
      const now = new Date(clockRows[0].now);
      if (current.state !== 'enrolling'
        || !fenceMatches(fence, { operationId, authorityId, leaseToken, leaseGeneration })
        || !leaseMatches(current, { authorityId, leaseToken, leaseGeneration }, now)) throw new LeaseExpiredError();
      return {
        operationId,
        accountId: current.account_id,
        fenceGeneration: String(fence.fence_generation),
        fencedAt: iso(fence.fenced_at),
        leaseExpiresAt: iso(current.lease_expires_at),
      };
    });
  }

  async function completeEnrollment({ operationId, idempotencyKey, authorityId, leaseToken, leaseGeneration, provenance }) {
    operationId = uuid(operationId);
    idempotencyKey = opaque(idempotencyKey, 'idempotency key');
    authorityId = text(authorityId, 128, 'authority ID');
    leaseToken = opaque(leaseToken, 'lease token');
    if (typeof leaseGeneration !== 'string' && typeof leaseGeneration !== 'number') throw new TypeError('Invalid lease generation');
    if (!/^[1-9][0-9]{0,18}$/u.test(String(leaseGeneration))) throw new TypeError('Invalid lease generation');
    leaseGeneration = String(leaseGeneration);
    provenance = text(provenance, 256, 'provenance');
    const keyHash = idempotencyHash(idempotencyKey);
    const requestFingerprint = fingerprint({ operationId, authorityId, leaseGeneration, leaseTokenHash: digest(leaseToken) });
    return transaction(pool, async client => {
      await serializeKey(client, `complete:${keyHash}`);
      const retry = await existingRequest(client, 'complete', keyHash, requestFingerprint);
      if (retry) return retry;
      const current = await lockActiveEnrollment(client, operationId);
      const { rows: importBindings } = await client.query(
        `SELECT operation_id FROM lakeside_enrollment.import_binding WHERE operation_id=$1
         UNION ALL
         SELECT operation_id FROM lakeside_enrollment.import_attempt WHERE operation_id=$1
         UNION ALL
         SELECT operation_id FROM lakeside_enrollment.import_attempt_lease WHERE operation_id=$1`,
        [operationId],
      );
      if (importBindings.length) throw new EnrollmentStateError('Bound credential imports require authenticated receipt reconciliation');
      if (current.state === 'unified') throw new EnrollmentConflictError();
      if (current.state !== 'enrolling') throw new EnrollmentStateError('Only an enrolling operation can become unified');

      const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
      const now = new Date(clockRows[0].now);
      if (
        current.lease_authority !== authorityId
        || String(current.lease_generation) !== leaseGeneration
        || current.lease_token_hash !== digest(leaseToken)
        || current.lease_expires_at == null
        || new Date(current.lease_expires_at) <= now
      ) throw new LeaseExpiredError();
      const fence = await lockAccountFence(client, current.account_id);
      if (!fence) throw new EnrollmentStateError('An immutable account migration fence is required before completion');
      if (!fenceMatches(fence, { operationId, authorityId, leaseToken, leaseGeneration })) throw new LeaseExpiredError();

      const { rows: updated } = await client.query(
        `UPDATE lakeside_enrollment.enrollment
            SET state='unified', lease_authority=NULL, lease_token=NULL, lease_token_hash=NULL,
                lease_expires_at=NULL, unified_at=clock_timestamp(), updated_at=clock_timestamp()
          WHERE operation_id=$1 AND lease_expires_at > clock_timestamp()
          RETURNING *`,
        [operationId],
      );
      if (!updated[0]) throw new LeaseExpiredError();
      const result = publicEnrollment(updated[0]);
      await insertRequest(client, { operationId, phase: 'complete', keyHash, requestFingerprint, result });
      await audit(client, {
        operationId,
        accountId: updated[0].account_id,
        action: 'enrollment.unified',
        provenance,
        metadata: { state: 'unified', leaseGeneration },
      });
      return result;
    });
  }

  async function setAdmissionsPaused({ operationId, idempotencyKey, paused, provenance }) {
    operationId = uuid(operationId);
    idempotencyKey = opaque(idempotencyKey, 'idempotency key');
    if (typeof paused !== 'boolean') throw new TypeError('paused must be a boolean');
    provenance = text(provenance, 256, 'provenance');
    const keyHash = idempotencyHash(idempotencyKey);
    const requestFingerprint = fingerprint({ operationId, paused });
    return transaction(pool, async client => {
      await serializeKey(client, `control:${keyHash}`);
      const retry = await existingControlRequest(client, operationId, keyHash, requestFingerprint);
      if (retry) return retry;
      const { rows } = await client.query('SELECT * FROM lakeside_enrollment.rollout_control WHERE control_id=true FOR UPDATE');
      if (!rows[0]) throw new Error('Enrollment rollout control is missing');
      const { rows: updated } = await client.query(
        `UPDATE lakeside_enrollment.rollout_control
            SET admissions_paused=$1, revision=revision+1, updated_at=clock_timestamp()
          WHERE control_id=true
          RETURNING admissions_paused, revision::text`,
        [paused],
      );
      const result = { operationId, admissionsPaused: updated[0].admissions_paused, revision: updated[0].revision };
      await client.query(
        `INSERT INTO lakeside_enrollment.control_request(request_id, operation_id, idempotency_hash, request_fingerprint, result)
         VALUES ($1, $2, $3, $4, $5::jsonb)`,
        [randomUUID(), operationId, keyHash, requestFingerprint, JSON.stringify(result)],
      );
      await audit(client, {
        action: paused ? 'enrollment.admissions.paused' : 'enrollment.admissions.resumed',
        provenance,
        metadata: { admissionsPaused: paused, revision: updated[0].revision },
      });
      return result;
    });
  }

  async function getEnrollment(operationId) {
    operationId = uuid(operationId);
    const { rows } = await pool.query('SELECT * FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [operationId]);
    return rows[0] ? publicEnrollment(rows[0]) : null;
  }

  // Trusted backend routing metadata only. The caller must perform a fresh
  // authoritative account-security check before authorizing any request.
  async function getLoginRoute({ issuer, subject }) {
    const item = identity({ issuer, subject });
    // One statement gives the route a coherent MVCC snapshot while keeping
    // this path usable by the dedicated read-only route role. The unique
    // registry mapping, account-wide enrollment, and account-owned fence are
    // joined by their canonical account UUID. No request-selected account or
    // email participates in the lookup.
    const { rows } = await pool.query(
      `WITH matched AS (
         SELECT ei.account_id::text AS account_id,
                a.status,
                a.recovery_hold,
                e.operation_id,
                e.state,
                e.lease_expires_at,
                f.account_id::text AS fence_account_id,
                f.operation_id AS fence_operation_id
           FROM lakeside_accounts.external_identity ei
           JOIN lakeside_accounts.account a ON a.account_id=ei.account_id
           LEFT JOIN lakeside_enrollment.enrollment e ON e.account_id=ei.account_id
           LEFT JOIN lakeside_enrollment.account_fence f ON f.account_id=ei.account_id
          WHERE ei.issuer=$1 AND ei.subject=$2
       )
       SELECT matched.*, count(*) OVER ()::text AS match_count
         FROM matched`,
      [item.issuer, item.subject],
    );
    if (!rows[0]) return publicLoginRoute(item);
    if (rows.length !== 1 || rows[0].match_count !== '1') {
      throw new EnrollmentConflictError();
    }
    const row = rows[0];
    const account = {
      account_id: row.account_id,
      status: row.status,
      recovery_hold: row.recovery_hold,
    };
    const operation = row.operation_id == null ? null : {
      operation_id: row.operation_id,
      state: row.state,
      lease_expires_at: row.lease_expires_at,
    };
    const fence = row.fence_account_id == null ? null : {
      account_id: row.fence_account_id,
      operation_id: row.fence_operation_id,
    };
    return publicLoginRoute(item, account, operation, fence);
  }

  async function getRolloutState() {
    const { rows } = await pool.query('SELECT admissions_paused, revision::text, updated_at::text FROM lakeside_enrollment.rollout_control WHERE control_id=true');
    if (!rows[0]) throw new Error('Enrollment rollout control is missing');
    return {
      admissionsPaused: rows[0].admissions_paused,
      revision: rows[0].revision,
      updatedAt: iso(rows[0].updated_at),
    };
  }

  const importReconciliation = createImportReconciliation({ pool, options, leaseSeconds, transaction, lockActiveEnrollment, lockAccountFence,
    leaseMatches, fenceMatches, uuid, opaque, text, digest, fingerprint, audit, publicEnrollment,
    EnrollmentConflictError, EnrollmentStateError, LeaseExpiredError });
  const activationReconciliation = createActivationReconciliation({ pool, options, transaction, uuid, text, fingerprint, audit,
    publicEnrollment, EnrollmentConflictError, EnrollmentStateError, EnrollmentAccountSuspendedError });
  const api = {
    ...importReconciliation,
    ...activationReconciliation,
    admitEnrollment,
    startEnrollment,
    claimEnrollment,
    fenceEnrollment,
    assertMigrationFence,
    completeEnrollment,
    setAdmissionsPaused,
    pauseAdmissions: input => setAdmissionsPaused({ ...input, paused: true }),
    resumeAdmissions: input => setAdmissionsPaused({ ...input, paused: false }),
    getEnrollment,
    getLoginRoute,
    getRolloutState,
  };
  return api;
}
