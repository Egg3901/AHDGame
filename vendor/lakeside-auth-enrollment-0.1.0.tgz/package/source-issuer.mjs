const CONTROL = /[\u0000-\u0020\u007f\u2028\u2029]/u;
const LEGACY_NAMESPACE = /^urn:lakeside:legacy:[a-z0-9]+(?::[a-z0-9]+)*$/u;

export function isPinnedSourceIssuer(value) {
  if (typeof value !== 'string' || value.length < 1 || value.length > 512
      || !value.isWellFormed() || CONTROL.test(value)) return false;
  if (LEGACY_NAMESPACE.test(value)) return true;
  try {
    const parsed = new URL(value);
    return parsed.protocol === 'https:' && !parsed.username && !parsed.password
      && !parsed.search && !parsed.hash && !value.includes('?') && !value.includes('#')
      && !value.includes('@') && parsed.href === value;
  } catch {
    return false;
  }
}
