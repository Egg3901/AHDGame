-- Additive per-attempt evidence for provider aborts and same-fence retries.
-- The original account_fence, enrollment lease, import_binding and
-- import_receipt rows remain immutable historical evidence.
CREATE TABLE lakeside_enrollment.import_attempt_lease (
  attempt_id uuid PRIMARY KEY,
  operation_id uuid NOT NULL REFERENCES lakeside_enrollment.enrollment(operation_id),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  attempt_generation bigint NOT NULL CHECK (attempt_generation > 0),
  lease_token_hash text NOT NULL CHECK (length(lease_token_hash) = 64),
  lease_expires_at timestamptz NOT NULL,
  issued_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (operation_id, attempt_generation)
);

CREATE TABLE lakeside_enrollment.import_live_attempt (
  account_id uuid PRIMARY KEY REFERENCES lakeside_accounts.account(account_id),
  operation_id uuid NOT NULL UNIQUE REFERENCES lakeside_enrollment.enrollment(operation_id),
  attempt_id uuid NOT NULL UNIQUE REFERENCES lakeside_enrollment.import_attempt_lease(attempt_id)
);

CREATE TABLE lakeside_enrollment.import_v1_abort (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.import_binding(operation_id),
  receipt_id uuid NOT NULL UNIQUE,
  evidence_fingerprint text NOT NULL CHECK (length(evidence_fingerprint) = 64),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE lakeside_enrollment.import_attempt (
  attempt_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.import_attempt_lease(attempt_id),
  operation_id uuid NOT NULL REFERENCES lakeside_enrollment.enrollment(operation_id),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  attempt_generation bigint NOT NULL CHECK (attempt_generation > 0),
  binding jsonb NOT NULL CHECK (jsonb_typeof(binding) = 'object'),
  bound_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (operation_id, attempt_generation)
);

CREATE TABLE lakeside_enrollment.import_attempt_receipt (
  attempt_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.import_attempt(attempt_id),
  receipt_id uuid NOT NULL UNIQUE,
  evidence_fingerprint text NOT NULL CHECK (length(evidence_fingerprint) = 64),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE lakeside_enrollment.import_attempt_abort (
  attempt_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.import_attempt(attempt_id),
  receipt_id uuid NOT NULL UNIQUE,
  evidence_fingerprint text NOT NULL CHECK (length(evidence_fingerprint) = 64),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE OR REPLACE FUNCTION lakeside_enrollment.reject_account_fence_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'account migration fence is immutable';
END;
$$;

CREATE TRIGGER import_attempt_lease_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.import_attempt_lease
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER import_v1_abort_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.import_v1_abort
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER import_attempt_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.import_attempt
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER import_attempt_receipt_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.import_attempt_receipt
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER import_attempt_abort_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.import_attempt_abort
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();

-- Backfill only additive evidence for existing v1 bindings. The v1 JSON is
-- copied byte-for-byte and is never updated. A committed v1 receipt remains a
-- v1 receipt; it is not rewritten as an attempt receipt.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1
      FROM lakeside_enrollment.import_binding b
      JOIN lakeside_enrollment.enrollment e USING (operation_id)
     WHERE b.binding->>'operationId' IS NULL
        OR b.binding->>'operationId' <> b.operation_id::text
        OR b.binding->>'accountId' IS NULL
        OR b.binding->>'accountId' <> b.account_id::text
        OR b.binding->>'legacyIssuer' IS NULL
        OR b.binding->>'legacyIssuer' <> e.issuer
        OR b.binding->>'legacySubject' IS NULL
        OR b.binding->>'legacySubject' <> e.subject
        OR b.binding->>'fenceTokenHash' IS NULL
        OR b.binding->>'fenceTokenHash' !~ '^[0-9a-f]{64}$'
        OR b.binding->>'fenceGeneration' IS NULL
        OR b.binding->>'fenceGeneration' !~ '^[1-9][0-9]{0,18}$'
        OR b.binding->>'fenceExpiresAtMs' IS NULL
        OR b.binding->>'fenceExpiresAtMs' !~ '^[1-9][0-9]{0,18}$'
  ) THEN
    RAISE EXCEPTION 'auth enrollment v1 import binding cannot be safely backfilled';
  END IF;
END;
$$;

INSERT INTO lakeside_enrollment.import_attempt_lease(
  attempt_id, operation_id, account_id, attempt_generation,
  lease_token_hash, lease_expires_at, issued_at
)
SELECT b.operation_id, b.operation_id, b.account_id, 1,
       b.binding->>'fenceTokenHash',
       to_timestamp(((b.binding->>'fenceExpiresAtMs')::bigint) / 1000.0),
       b.bound_at
  FROM lakeside_enrollment.import_binding b
ON CONFLICT (attempt_id) DO NOTHING;

INSERT INTO lakeside_enrollment.import_attempt(
  attempt_id, operation_id, account_id, attempt_generation, binding, bound_at
)
SELECT b.operation_id, b.operation_id, b.account_id, 1, b.binding, b.bound_at
  FROM lakeside_enrollment.import_binding b
 WHERE EXISTS (
   SELECT 1 FROM lakeside_enrollment.import_attempt_lease l
    WHERE l.attempt_id=b.operation_id
 )
ON CONFLICT (attempt_id) DO NOTHING;

INSERT INTO lakeside_enrollment.import_attempt_receipt(
  attempt_id, receipt_id, evidence_fingerprint, recorded_at
)
SELECT r.operation_id, r.receipt_id, r.evidence_fingerprint, r.recorded_at
  FROM lakeside_enrollment.import_receipt r
 WHERE EXISTS (
   SELECT 1 FROM lakeside_enrollment.import_attempt a
    WHERE a.attempt_id=r.operation_id
 )
ON CONFLICT (attempt_id) DO NOTHING;

INSERT INTO lakeside_enrollment.import_live_attempt(account_id, operation_id, attempt_id)
SELECT e.account_id, e.operation_id, e.operation_id
  FROM lakeside_enrollment.enrollment e
  JOIN lakeside_enrollment.import_attempt a ON a.attempt_id=e.operation_id
  LEFT JOIN lakeside_enrollment.import_attempt_receipt r ON r.attempt_id=a.attempt_id
 WHERE e.state='enrolling' AND r.attempt_id IS NULL
ON CONFLICT (account_id) DO NOTHING;
