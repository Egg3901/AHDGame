# Auth enrollment

`createCentralFenceAttestationReader` is the trusted PostgreSQL adapter for
the source fence writer. It returns a digest-bound frozen snapshot only when
the exact source identity, active account, enrolling operation, immutable
central fence, committed disabled-target provision evidence, and target
identity mapping agree. The lease deadline is evidence data and may be in the
past so an exact fenced operation can be recovered. Its immutable fence
timestamp lets the source require a newly observed ownership proof after
lease expiry and reject every older pre-fence proof. The adapter never returns
the lease token and requires a bounded pool, bounded queries, pinned HTTPS
issuers, and a pinned target realm. Deploy it with the dedicated
`lakeside_fence_attestation_reader` role.

`@lakeside/auth-enrollment` is a small trusted-backend package for admitting an
explicit legacy identity cohort into unified auth. It has no HTTP routes, no
browser interface, no email matching, and no random traffic routing. The
account-registry recovery migration that adds `account.recovery_hold` is a
required prerequisite; enrollment migration fails closed when that column is
missing.

Claim, fence, and completion are state transitions, not source authentication.
Production admission uses `admitEnrollment`, which loads an authenticated
source ownership proof through the configured reader, binds it to the exact
immutable reservation, accounts for elapsed loader and coordinator time, and
stores an immutable proof-admission receipt in the same PostgreSQL transaction
as the enrollment row. A live legacy cookie alone never authorizes enrollment
or the irreversible account fence. See the
[source-proof admission order](../../integration/source-proof-admission-order.md)
and the package's [source ownership proof reader](./source-proof-reader.md).

`startEnrollment` now fails closed unless the constructor explicitly sets
`allowUnprovedAdmissions: true`. That switch exists only for isolated legacy
fixtures which test later state transitions; it is not a production migration
mode and must not be present in a deployed coordinator.

When a source flow needs stable identifiers before proof admission, use the
[enrollment reservation store](./reservation.md). A reservation resolves an
existing canonical mapping and reserves metadata only; it does not admit,
claim, fence, route, provision, enable, authenticate, or prove anything.

Disabled target provisioning is a separate trusted operation. The current
coordinator and bounded retry wrapper are documented in the account registry's
[provision workflow](../account-registry/provision-workflow.md); a dispatcher
candidate is not an ownership receipt.

Call `migrate(pool)` explicitly with migration credentials, after the
authoritative `lakeside_accounts` registry schema exists. Construct the runtime
boundary with:

```js
const proofReader = createSourceOwnershipProofReader({
  sourceIssuer: 'https://game.example.com',
  loadSourceProof: authenticatedSourceLoader,
  timeoutMs: 5000,
});
const enrollment = createCohortEnrollment(pool, {
  allowedLegacyIdentities: [
    { issuer: 'https://game.example.com', subject: 'exact-user-id' },
  ],
  sourceProofReader: proofReader,
  leaseSeconds: 60,
});
```

The allowlist is an exact, case-sensitive `(issuer, subject)` set. After the
source has verified ownership and used the reservation's stable identifiers to
persist the proof, admission is:

```js
const operation = await enrollment.admitEnrollment({
  reservation,
  proofId,
  sourceAccountId,
  idempotencyKey: createIdempotencyKey(),
  provenance: 'cohort-run-2026-09-10',
});
```

The operation starts in `eligible`. `startEnrollment` does not claim a lease,
cross the migration fence, or make a legacy identity eligible for a credential
write. A trusted authority claims it with
`claimEnrollment({ operationId, idempotencyKey, authorityId, provenance })`.
That moves the operation to `enrolling` and returns a random lease token and
monotonic `leaseGeneration`. The lease permits one bounded authority to carry
out the next migration step; it is not source proof, account authorization, or
the irreversible fallback decision. An expired lease can be reclaimed by
another authority; the generation and token fence the old authority. A late
completion can never complete a newer lease.

`fenceEnrollment` is a separate irreversible account-owned authority switch.
It requires the current `enrolling` lease and inserts a fence in migration 2,
making the account ineligible for every new legacy admission or fallback route.
The source-proof admission order requires fresh source ownership and disabled
target provisioning before this switch; this package does not perform those
external checks. A fence is not a lease, source proof, provider receipt, or
permission to mutate an external credential. The importer may call
`assertMigrationFence` as a final ledger check and then call the provider and
`completeEnrollment` with the same lease values. That check is not a lock
across the provider call: if the importer pauses after the check, or the
provider delays the request, the provider can receive a mutation after the
lease expires. Provider-side atomic fence enforcement and receipt
reconciliation are required.

A fence is irreversible; it cannot be reclaimed by another lease. If the lease
expires after fencing, this package rejects further mutation and completion
attempts. The account remains an operational gate until
`reconcileCredentialImport` can prove a previously bound provider write using
its authenticated committed receipt. Operations without a pre-write import
binding remain held for a separately reviewed reconciliation flow. Do not edit
the lease or fence rows manually.

The original enrollment and rollout mutating calls require a strong opaque idempotency key.
The import binding and receipt methods below instead use the immutable operation
and receipt identities as their durable idempotency keys. The key and a
semantic request fingerprint are stored durably. Repeating the same operation
with the same key returns the original result while its lease is still the
current, unexpired fence. If another authority reclaims the lease, the old
retry is rejected with `LeaseExpiredError`; it is never returned as a fresh
permit. Reusing a key with changed operation data raises
`IdempotencyConflictError`. A second key cannot take over an active lease, and
an operation cannot move backward from `unified`.

Admissions start paused in every fresh database. An explicit audited
`resumeAdmissions({ operationId, idempotencyKey, provenance })` is required
before any new `startEnrollment` call can succeed. `pauseAdmissions` durably
blocks new starts again. The pause is server-owned and audited. It does not
demote `eligible` operations, cancel an `enrolling` lease, or make an existing
`unified` account fall back to legacy auth. Claims for operations admitted
before the pause continue to work.

Safety invariants:

- Enrollment is account-wide. The only enrollment ownership source is the authoritative
  `lakeside_accounts.external_identity` row for the exact issuer and subject.
  The account UUID is read from that row, then the authoritative account row is
  locked and the mapping is rechecked. Callers cannot
  supply an arbitrary account UUID and email is ignored completely. A second
  exact legacy alias for the same account conflicts with the existing
  operation rather than creating another one.
- The mapped account must be active and must not have `recovery_hold=true`.
  The recovery hold is read from the required authoritative account row. The
  enrollment migration fails closed until registry migration 3 has added it.
- The account reference, exact legacy identity, and operation ID are immutable.
  There is no link, transfer, merge, unsuspend, or public proof method.
- The allowlist and registry mapping remain identity boundaries, not source
  proof. `admitEnrollment` additionally requires the authenticated proof reader
  and exact reservation. The package accepts no cookie or browser session.
- A database transaction and row locks serialize claims for one identity and
  one operation. Fencing generation, token, authority, and expiry prevent lease
  ambiguity from allowing two authorities to complete an operation.
- The account fence is a separate immutable authority switch. Its account and
  operation uniqueness prevent a second importer from taking ownership. A
  fenced account never returns a legacy route, even while its operation remains
  `enrolling`; a stale or expired importer guard cannot complete the ledger.
  A committed import moves only to `credentialed`, which remains blocked until
  authenticated target activation is implemented and reconciled.
- Audit and outbox rows are written in the same transaction as each successful
  state change. An audit failure rolls back the enrollment mutation.
- Admission pause is a durable control row. It is checked only for new
  admissions, so a pause cannot silently demote or revoke an existing user.
- `getEnrollment` is a trusted backend ledger read for an operation ID. It is
  not an authorization decision and does not replace the authoritative account
  security check.

`getLoginRoute({ issuer, subject })` is a trusted backend routing read. It does
not consult the enrollment allowlist or the pause flag, so every exact mapped
legacy alias for the same canonical account sees the same result. Its `status`
is `unmapped` when the registry has no exact mapping, `legacy` when the mapped
active account has no enrollment row, `enrolling` for either `eligible` or
`enrolling` enrollment state, `unified` only after activation completion, and
`blocked` for `credentialed`, a suspended account, or a recovery hold. A blocked
result never supplies a legacy route. The operation and account values are
returned for correlation only.
The route is computed by one parameterized MVCC `SELECT` joining the exact
registry mapping to the canonical account, account-owned enrollment, and
account-owned fence. It takes no row locks and works with a PostgreSQL
`default_transaction_read_only=on` connection. This result is routing metadata,
not authorization or a lease. The caller must re-read authoritative account
security and session state for the actual request; database fencing here only
makes the route snapshot coherent.

Production integration remains open. The package intentionally does not claim
to authorize an external credential mutation from a ledger token alone. An
atomic provider receipt that consumes the same fence, or an equivalent
provider-side idempotent mutation and reconciliation protocol, must enforce
the external write before this flow can be enabled. Operators must provision the dedicated
database and least-privilege roles, run the migration separately, supply and
review the exact allowlist, keep it identical across authorities, protect the
database and lease results, dispatch and monitor the outbox, define backup and
restore procedures, and integrate each consumer's own session and entitlement
checks. The package does not import credentials. Database fencing prevents stale
ledger completion and rejects stale importer guards, but it cannot cancel an
external request already admitted by a provider or close the check/use race.
Any external credential or account side effect therefore needs provider-side
atomic fence enforcement, idempotence, a bounded call deadline, and
reconciliation keyed by the immutable account fence before production. The
package does not establish fresh source ownership; the caller must satisfy
the source-proof admission order before admission. A live session or issuer
signature alone is not that proof. It does not deliver global logout,
roles, entitlements, or account suspension events by itself.

The real database tests are intentionally guarded. They require the isolated
compatibility PostgreSQL host and an explicit flag, create a random synthetic
database, and drop only that database:

```sh
cd packages/auth-enrollment
npm ci
LAKESIDE_ISOLATED_ENROLLMENT_TEST=true PGHOST=database npm test
```

Do not run these tests against a production database. Do not expose this
package as a browser or public endpoint.

## Credential import reconciliation

Migration 3 adds immutable `import_binding` and `import_receipt` tables. Configure
`allowedImportIssuers` as exact HTTPS issuer strings, and provide an authenticated
`loadCommittedImportReceipt(binding, { signal })` transport before using this flow.
No default transport or production issuer is supplied.

After fencing, and before any external credential mutation, call
`bindCredentialImport({ operationId, authorityId, leaseToken, leaseGeneration,
targetIdentity: { issuer, subject, realmId }, digestFingerprint, provenance })`.
The live lease must still match. The source identity and canonical account come
from the locked enrollment operation. The target issuer/subject must already be
registered to that same account by a separately trusted provisioning/proof flow.
The immutable binding stores the exact target, SHA-256 digest fingerprint, bcrypt
algorithm/work factor, fence hash/generation and original lease expiry. It stores
neither a credential digest nor a raw lease token. Changing a binding conflicts.
An operation with this binding cannot use generic `completeEnrollment`.

`reconcileCredentialImport({ operationId, provenance })` reads the provider
outside a database transaction, with a bounded timeout (default 5 seconds,
configurable 10..10000 milliseconds). The trusted reader must authenticate the
exact stored issuer and return all binding fields plus a canonical UUID
`receiptId` and `state: 'COMMITTED'`. It must query durable provider evidence;
never return browser input or infer success from an HTTP status alone. The
library checks every field and rechecks the current account, exact registry
mappings and immutable fence under database locks. Receipt persistence, the
transition to `credentialed`, audit, and outbox commit together. A matching
committed receipt can settle an expired lease because reconciliation performs
no credential write, renews no lease, and never removes the migration fence.
It cannot mark the account unified or enable the target. Concurrent identical
receipts converge. Changed, absent or MUTATING receipts, transport failures,
recovery holds and suspensions fail closed. Retries never clear restrictions.

The guarded PostgreSQL suite exercises expired-lease credential settlement, concurrent
receipt retries, mismatched binding fields, immutable rows, ordinary
completion bypass refusal, provider timeout/outage, account holds, audit
rollback, v1 abort evidence, same-fence retry, concurrent v2 binding, v1/v2
protocol serialization, bigint generation bounds, and hold denial for new
evidence. Run the reservation and source-proof-reader suites separately with
the focused commands in their linked package docs.
An already recorded abort tombstone may be read idempotently, but a held or
suspended account cannot create new abort evidence or reconcile a credential.
The real Keycloak/PostgreSQL fixture acceptance run remains a separate integration
gate. It uses an explicitly mapped synthetic HTTPS issuer label over the
isolated Docker HTTP network; it is not production TLS or source ownership
proof. Production receipt transport, provider abort evidence, and provisioning
attestation remain required.

## Target activation reconciliation

Credential import now ends in `credentialed`, not `unified`. Call
`bindTargetActivation({ operationId, provenance })` to derive and freeze the
exact account, issuer, realm, target subject, and committed import receipt from
the coordinator database. The caller cannot supply any of those ownership
fields. The immutable binding is the complete interface to the issuer-side
activation adapter.

`reconcileTargetActivation({ operationId, provenance })` accepts only an exact
`COMMITTED` receipt returned by the configured `loadActivationReceipt` transport.
The lookup is bounded by `activationReceiptTimeoutMs` (10..10000 milliseconds,
default 5000), receives an abort signal, and runs outside the database
transaction. The coordinator captures the returned primitive fields, then
rechecks the current active, unheld account and the committed import evidence
under locks. Activation receipt, `unified` transition, audit, and outbox commit
together. Exact replay is read-only. Missing, MUTATING, malformed, conflicting,
timed-out, or failed evidence leaves the target fail-closed in `credentialed`.

This coordinator seam does not itself enable a Keycloak user or authenticate
the injected transport. The issuer-side atomic enablement operation and its
authenticated receipt reader remain required before production composition.

### Abort evidence and same-fence retry

Migration 4 adds immutable per-attempt lease, binding, receipt and abort
evidence. It leaves the migration 1 checksum, the account fence, the original
enrollment lease and every v1 binding JSON byte-identical. The permanent fence
never changes generation, token hash, authority or owner.

After a provider call is ambiguous, `issueImportAttemptLease` cannot issue a
new attempt until the previous bound attempt has authenticated terminal
`ABORTED` evidence. `abortCredentialImport` accepts a provider `abortImport`
transport, or the explicitly authenticated `loadImportReceipt` transport, and
records an immutable abort tombstone. `COMMITTED` always wins and reconciles
the enrollment. Missing, `MUTATING`, malformed, mismatched or timed-out
evidence remains unavailable and does not unlock retry.

Use the additive v2 sequence for a retry:

```js
const lease = await enrollment.issueImportAttemptLease({ operationId, authorityId, provenance });
const binding = await enrollment.bindImportAttempt({
  operationId,
  attemptId: lease.attemptId,
  attemptGeneration: lease.attemptGeneration,
  leaseToken: lease.leaseToken,
  targetIdentity,
  digestFingerprint,
  provenance,
});
await enrollment.reconcileImportAttempt({ operationId, attemptId: binding.attemptId, provenance });
```

An unbound expired attempt lease may be reclaimed because no durable binding
could have admitted a provider mutation. A bound lease remains blocked after
expiry until authenticated abort or commit evidence is recorded. The package
does not claim that an enrollment ledger check can cancel a provider request;
the provider-side abort and commit protocol, source proof, target provisioning,
and v1 writer drain remain production gates. Unbound attempt issuance also
blocks ordinary completion. Migration-4 backfill preserves exact v1 replay;
an actual v2 lease permanently closes the v1 binding path.
