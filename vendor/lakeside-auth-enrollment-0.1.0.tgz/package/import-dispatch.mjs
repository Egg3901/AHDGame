import { createHash } from 'node:crypto';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
const HEX64 = /^[0-9a-f]{64}$/u;
const BCRYPT12 = /^\$2[aby]\$12\$[./A-Za-z0-9]{53}$/u;
const CONTROL = /[\u0000-\u001f\u007f]/u;
const BINDING_KEYS = [
  'version', 'attemptId', 'attemptGeneration', 'accountId', 'operationId', 'issuer',
  'realmId', 'userId', 'legacyIssuer', 'legacySubject', 'digestFingerprint',
  'credentialAlgorithm', 'hashIterations', 'fenceGeneration', 'fenceTokenHash',
  'fenceExpiresAtMs', 'attemptLeaseTokenHash', 'attemptExpiresAtMs',
];

export class CredentialImportDispatchError extends Error {
  constructor(code = 'dispatch_failed', requestMayHaveReachedIssuer = false) {
    super('Credential import dispatch failed');
    this.name = 'CredentialImportDispatchError';
    this.code = code;
    this.requestMayHaveReachedIssuer = requestMayHaveReachedIssuer;
    Object.freeze(this);
  }
}

function exactKeys(value, keys) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const actual = Object.keys(value).sort();
  return actual.length === keys.length && keys.every(key => actual.includes(key));
}
function text(value, max) {
  return typeof value === 'string' && value.length > 0 && value.length <= max
    && value === value.trim() && value.isWellFormed() && !CONTROL.test(value);
}
function uuid(value) { return text(value, 36) && UUID.test(value); }
function safeInteger(value) { return Number.isSafeInteger(value) && value > 0; }
function exactHttps(value) {
  if (!text(value, 512)) return null;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password && !url.search && !url.hash
      && url.href === value ? url : null;
  } catch { return null; }
}
function digest(value) { return createHash('sha256').update(value).digest('hex'); }

function validate(binding, credentialDigest, issuer, realmId) {
  if (!exactKeys(binding, BINDING_KEYS) || binding.version !== 2 || binding.issuer !== issuer
      || binding.realmId !== realmId || !uuid(binding.accountId) || !uuid(binding.operationId)
      || !uuid(binding.attemptId) || !uuid(binding.userId) || !text(binding.legacyIssuer, 512)
      || !text(binding.legacySubject, 512) || binding.credentialAlgorithm !== 'lakeside-legacy-bcrypt-v1'
      || binding.hashIterations !== 12 || !HEX64.test(binding.digestFingerprint)
      || !HEX64.test(binding.fenceTokenHash) || !HEX64.test(binding.attemptLeaseTokenHash)
      || !safeInteger(Number(binding.fenceGeneration)) || String(Number(binding.fenceGeneration)) !== binding.fenceGeneration
      || !safeInteger(Number(binding.attemptGeneration)) || String(Number(binding.attemptGeneration)) !== binding.attemptGeneration
      || !safeInteger(binding.fenceExpiresAtMs) || !safeInteger(binding.attemptExpiresAtMs)
      || typeof credentialDigest !== 'string' || !BCRYPT12.test(credentialDigest)
      || digest(credentialDigest) !== binding.digestFingerprint) {
    throw new CredentialImportDispatchError('invalid_binding', false);
  }
  return Object.freeze({ ...binding, credentialDigest });
}

async function readBounded(response, maxBytes, signal) {
  const reader = response.body?.getReader?.();
  if (!reader) throw new CredentialImportDispatchError('invalid_response', true);
  const chunks = [];
  let length = 0;
  try {
    while (true) {
      if (signal.aborted) throw new CredentialImportDispatchError('timeout', true);
      const item = await reader.read();
      if (item.done) break;
      length += item.value.byteLength;
      if (length > maxBytes) throw new CredentialImportDispatchError('invalid_response', true);
      chunks.push(item.value);
    }
  } finally { reader.cancel().catch(() => {}); }
  const joined = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { joined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder('utf-8', { fatal: true }).decode(joined);
}

export function createCredentialImportDispatcher({
  endpoint, issuer, realmId, obtainAccessToken, fetchImpl = globalThis.fetch, timeoutMs = 5000,
} = {}) {
  const base = exactHttps(endpoint);
  if (!base || base.search || base.hash || base.pathname.endsWith('/import-credential')) {
    throw new TypeError('Explicit import base endpoint required');
  }
  if (!exactHttps(issuer) || !text(realmId, 255) || typeof obtainAccessToken !== 'function'
      || typeof fetchImpl !== 'function' || !Number.isSafeInteger(timeoutMs)
      || timeoutMs < 100 || timeoutMs > 5000) throw new TypeError('Invalid import dispatcher config');
  const url = new URL(base.href);
  url.pathname = `${url.pathname.replace(/\/+$/u, '')}/import-credential`;

  async function importCredential(binding, credentialDigest, { signal: parentSignal } = {}) {
    const input = validate(binding, credentialDigest, issuer, realmId);
    const controller = new AbortController();
    const onAbort = () => controller.abort();
    parentSignal?.addEventListener?.('abort', onAbort, { once: true });
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    let reached = false;
    try {
      if (parentSignal?.aborted) throw new CredentialImportDispatchError('aborted', false);
      const token = await obtainAccessToken({ signal: controller.signal });
      if (!text(token, 8192) || !/^[A-Za-z0-9._~+/-]+=*$/u.test(token)) {
        throw new CredentialImportDispatchError('invalid_token', false);
      }
      reached = true;
      const response = await fetchImpl(url.href, {
        method: 'POST', redirect: 'error', signal: controller.signal,
        headers: { accept: 'application/json', 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: JSON.stringify({
          accountId: input.accountId, operationId: input.operationId, userId: input.userId,
          legacyIssuer: input.legacyIssuer, legacySubject: input.legacySubject,
          credentialAlgorithm: input.credentialAlgorithm, hashIterations: input.hashIterations,
          credentialDigest: input.credentialDigest, fenceTokenHash: input.fenceTokenHash,
          fenceGeneration: input.fenceGeneration, fenceExpiresAtMs: input.fenceExpiresAtMs,
          attemptId: input.attemptId, attemptGeneration: input.attemptGeneration,
          attemptLeaseTokenHash: input.attemptLeaseTokenHash, attemptExpiresAtMs: input.attemptExpiresAtMs,
        }),
      });
      if (response.redirected || response.status !== 200
          || response.headers?.get?.('content-type')?.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
        throw new CredentialImportDispatchError('invalid_response', true);
      }
      const parsed = JSON.parse(await readBounded(response, 16_384, controller.signal));
      if (!exactKeys(parsed, ['state', 'receiptId'])
          || !['COMMITTED', 'REPLAY_NO_MUTATION'].includes(parsed.state) || !uuid(parsed.receiptId)) {
        throw new CredentialImportDispatchError('invalid_response', true);
      }
      return Object.freeze({ state: parsed.state, receiptId: parsed.receiptId });
    } catch (error) {
      if (error instanceof CredentialImportDispatchError) throw error;
      throw new CredentialImportDispatchError(controller.signal.aborted ? 'timeout' : 'transport', reached);
    } finally {
      clearTimeout(timer);
      controller.abort();
      parentSignal?.removeEventListener?.('abort', onAbort);
    }
  }
  return Object.freeze({ importCredential });
}
