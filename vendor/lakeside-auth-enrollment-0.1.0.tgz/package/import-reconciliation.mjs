import { randomBytes, randomUUID } from 'node:crypto';

// Trusted backend composition only. Provider I/O is authenticated by the
// injected transport. This module records only immutable evidence and never
// accepts a browser assertion as proof of a credential write.
export function createImportReconciliation(context) {
  const {
    pool, options, leaseSeconds, transaction, lockActiveEnrollment, lockAccountFence,
    leaseMatches, fenceMatches, uuid, opaque, text, digest, fingerprint, audit,
    publicEnrollment, EnrollmentConflictError, EnrollmentStateError, LeaseExpiredError,
  } = context;

  const MAX_GENERATION = 9223372036854775807n;

  function generation(value, label = 'generation') {
    const candidate = String(value);
    if (!/^[1-9][0-9]{0,18}$/u.test(candidate) || BigInt(candidate) > MAX_GENERATION) {
      throw new TypeError(`Invalid ${label}`);
    }
    return candidate;
  }

  function nextGeneration(...values) {
    let maximum = 0n;
    for (const value of values) {
      const candidate = String(value ?? '0');
      if (!/^[0-9]+$/u.test(candidate)) throw new EnrollmentConflictError();
      const parsed = BigInt(candidate);
      if (parsed > maximum) maximum = parsed;
    }
    if (maximum >= MAX_GENERATION) throw new EnrollmentConflictError();
    return String(maximum + 1n);
  }

  function hash(value) {
    if (typeof value !== 'string' || !/^[0-9a-f]{64}$/u.test(value)) throw new TypeError('Invalid credential fingerprint');
    return value;
  }

  function target(value) {
    const issuer = text(value?.issuer, 512, 'target issuer');
    if (!Array.isArray(options.allowedImportIssuers) || !options.allowedImportIssuers.includes(issuer)) {
      throw new TypeError('Import issuer is not explicitly configured');
    }
    const url = new URL(issuer);
    if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash) throw new TypeError('Import issuer must be an exact HTTPS issuer');
    return { issuer, subject: text(value?.subject, 128, 'target subject'), realmId: text(value?.realmId, 255, 'target realm') };
  }

  async function requireTargetMapping(client, binding) {
    const { rows } = await client.query(
      'SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2 AND account_id=$3',
      [binding.issuer, binding.userId, binding.accountId],
    );
    if (rows.length !== 1) throw new EnrollmentConflictError();
  }

  async function storedBinding(client, operationId) {
    const { rows } = await client.query('SELECT binding FROM lakeside_enrollment.import_binding WHERE operation_id=$1', [operationId]);
    return rows[0]?.binding ?? null;
  }

  async function storedAttempt(client, attemptId, forUpdate = false) {
    const { rows } = await client.query(
      `SELECT attempt_id, operation_id, account_id::text, attempt_generation::text, binding, bound_at
         FROM lakeside_enrollment.import_attempt
        WHERE attempt_id=$1${forUpdate ? ' FOR UPDATE' : ''}`,
      [attemptId],
    );
    return rows[0] ?? null;
  }

  function sameBinding(expected, actual) {
    return actual != null && typeof actual === 'object' && !Array.isArray(actual)
      && Object.keys(expected).every(key => actual[key] === expected[key]);
  }

  function sameVersionBinding(expected, actual) {
    return sameBinding(expected, actual) && Object.keys(expected).length === Object.keys(actual).length;
  }

  function sameReceiptBinding(expected, actual) {
    if (!actual || typeof actual !== 'object' || Array.isArray(actual)) return false;
    const allowed = new Set([...Object.keys(expected), 'state', 'receiptId']);
    if (Object.keys(actual).some(key => !allowed.has(key))) return false;
    return sameBinding(expected, actual);
  }

  function v2IdentityEqual(expected, actual) {
    return [
      'accountId', 'issuer', 'realmId', 'userId', 'legacyIssuer', 'legacySubject',
      'digestFingerprint', 'credentialAlgorithm', 'hashIterations',
      'fenceGeneration', 'fenceTokenHash', 'fenceExpiresAtMs',
    ].every(key => expected[key] === actual[key]);
  }

  function assertFenceOwnership(fence, current, operationId) {
    if (!fence || fence.operation_id !== operationId || fence.account_id !== current.account_id) {
      throw new EnrollmentConflictError();
    }
  }

  async function currentFenceState(client, operationId) {
    const current = await lockActiveEnrollment(client, operationId);
    const fence = await lockAccountFence(client, current.account_id);
    assertFenceOwnership(fence, current, operationId);
    return { current, fence };
  }

  async function loadAttemptLease(client, { operationId, attemptId, attemptGeneration, leaseToken, accountId }) {
    const { rows } = await client.query(
      `SELECT attempt_id, operation_id, account_id::text, attempt_generation::text,
              lease_token_hash, lease_expires_at
         FROM lakeside_enrollment.import_attempt_lease
        WHERE attempt_id=$1
        FOR UPDATE`,
      [attemptId],
    );
    const lease = rows[0];
    if (!lease) throw new LeaseExpiredError();
    if (lease.operation_id !== operationId || lease.account_id !== accountId) throw new EnrollmentConflictError();
    if (String(lease.attempt_generation) !== String(attemptGeneration)
        || lease.lease_token_hash !== digest(leaseToken)) throw new LeaseExpiredError();
    const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
    if (new Date(lease.lease_expires_at) <= new Date(clockRows[0].now)) throw new LeaseExpiredError();
    const { rows: live } = await client.query(
      'SELECT account_id::text, operation_id, attempt_id FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 FOR UPDATE',
      [accountId],
    );
    if (!live[0] || live[0].operation_id !== operationId || live[0].attempt_id !== attemptId) throw new EnrollmentConflictError();
    return lease;
  }

  async function bindCredentialImport(input) {
    const operationId = uuid(input.operationId);
    const authorityId = text(input.authorityId, 128, 'authority ID');
    const leaseToken = opaque(input.leaseToken, 'lease token');
    const leaseGeneration = generation(input.leaseGeneration, 'lease generation');
    const destination = target(input.targetIdentity);
    const digestFingerprint = hash(input.digestFingerprint);
    const provenance = text(input.provenance, 256, 'provenance');
    return transaction(pool, async client => {
      const current = await lockActiveEnrollment(client, operationId);
      const fence = await lockAccountFence(client, current.account_id);
      const { rows: aborted } = await client.query('SELECT 1 FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [operationId]);
      if (aborted[0]) throw new EnrollmentConflictError();
      // Backfilled v1 leases use attempt_id=operation_id and retain replay.
      // Once an actual v2 attempt lease exists, this operation cannot fall back to
      // the legacy v1 binding path. Both paths take the account and operation
      // locks first, so the protocol choice is serialized.
      const { rows: attemptLeases } = await client.query(
        'SELECT 1 FROM lakeside_enrollment.import_attempt_lease WHERE operation_id=$1 AND attempt_id<>operation_id LIMIT 1',
        [operationId],
      );
      if (attemptLeases[0]) throw new EnrollmentConflictError();
      const lease = { operationId, authorityId, leaseToken, leaseGeneration };
      const { rows: times } = await client.query('SELECT clock_timestamp() AS now');
      if (current.state !== 'enrolling' || !fenceMatches(fence, lease)
          || !leaseMatches(current, lease, new Date(times[0].now))) throw new LeaseExpiredError();
      const binding = {
        operationId, accountId: current.account_id, issuer: destination.issuer,
        realmId: destination.realmId, userId: destination.subject,
        legacyIssuer: current.issuer, legacySubject: current.subject,
        digestFingerprint, credentialAlgorithm: 'lakeside-legacy-bcrypt-v1', hashIterations: 12,
        fenceGeneration: leaseGeneration, fenceTokenHash: digest(leaseToken),
        fenceExpiresAtMs: new Date(current.lease_expires_at).getTime(),
      };
      await requireTargetMapping(client, binding);
      const previous = await storedBinding(client, operationId);
      if (previous) {
        if (!sameVersionBinding(previous, binding)) throw new EnrollmentConflictError();
        return previous;
      }
      const { rows: attempts } = await client.query('SELECT attempt_id FROM lakeside_enrollment.import_attempt WHERE operation_id=$1', [operationId]);
      if (attempts[0]) throw new EnrollmentConflictError();
      await client.query('INSERT INTO lakeside_enrollment.import_binding(operation_id, account_id, binding) VALUES ($1,$2,$3::jsonb)',
        [operationId, current.account_id, JSON.stringify(binding)]);
      await audit(client, { operationId, accountId: current.account_id, action: 'enrollment.import_bound', provenance,
        metadata: { issuer: binding.issuer, fenceGeneration: leaseGeneration } });
      return binding;
    });
  }

  async function issueImportAttemptLease({ operationId, authorityId, provenance }) {
    operationId = uuid(operationId);
    authorityId = text(authorityId, 128, 'authority ID');
    provenance = text(provenance, 256, 'provenance');
    return transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (current.state !== 'enrolling') throw new EnrollmentConflictError();
      const { rows: v1Receipt } = await client.query('SELECT 1 FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [operationId]);
      if (v1Receipt[0]) throw new EnrollmentConflictError();
      const { rows: v1 } = await client.query('SELECT binding FROM lakeside_enrollment.import_binding WHERE operation_id=$1', [operationId]);
      const { rows: v1Abort } = await client.query('SELECT 1 FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [operationId]);
      if (v1[0] && !v1Abort[0]) throw new EnrollmentConflictError();
      const { rows: committedAttempt } = await client.query(
        `SELECT r.attempt_id
           FROM lakeside_enrollment.import_attempt_receipt r
           JOIN lakeside_enrollment.import_attempt a ON a.attempt_id=r.attempt_id
          WHERE a.operation_id=$1`,
        [operationId],
      );
      if (committedAttempt[0]) throw new EnrollmentConflictError();

      const { rows: unresolved } = await client.query(
        `SELECT a.attempt_id
           FROM lakeside_enrollment.import_attempt a
           LEFT JOIN lakeside_enrollment.import_attempt_receipt r ON r.attempt_id=a.attempt_id
           LEFT JOIN lakeside_enrollment.import_attempt_abort b ON b.attempt_id=a.attempt_id
          WHERE a.operation_id=$1 AND a.binding->>'version'='2'
            AND r.attempt_id IS NULL AND b.attempt_id IS NULL`,
        [operationId],
      );
      if (unresolved[0]) throw new EnrollmentConflictError();

      const { rows: liveRows } = await client.query(
        `SELECT l.account_id::text, l.operation_id, l.attempt_id,
                x.lease_expires_at, a.attempt_id AS bound_attempt_id
           FROM lakeside_enrollment.import_live_attempt l
           JOIN lakeside_enrollment.import_attempt_lease x ON x.attempt_id=l.attempt_id
           LEFT JOIN lakeside_enrollment.import_attempt a ON a.attempt_id=l.attempt_id
          WHERE l.account_id=$1
          FOR UPDATE OF l, x`,
        [current.account_id],
      );
      if (liveRows[0]) {
        const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
        const expired = new Date(liveRows[0].lease_expires_at) <= new Date(clockRows[0].now);
        const boundV2 = liveRows[0].bound_attempt_id && !(v1[0] && v1Abort[0]);
        if (boundV2 || !expired) throw new EnrollmentConflictError();
        await client.query('DELETE FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND attempt_id=$2', [current.account_id, liveRows[0].attempt_id]);
      }

      const { rows: maxRows } = await client.query(
        `SELECT GREATEST(
           COALESCE((SELECT MAX(attempt_generation) FROM lakeside_enrollment.import_attempt WHERE operation_id=$1), 0),
           COALESCE((SELECT MAX(attempt_generation) FROM lakeside_enrollment.import_attempt_lease WHERE operation_id=$1), 0)
         )::text AS max_generation`,
        [operationId],
      );
      const attemptGeneration = nextGeneration(maxRows[0].max_generation, v1[0] ? '1' : '0');
      const attemptId = randomUUID();
      const leaseToken = randomBytes(32).toString('base64url');
      const { rows: clockRows } = await client.query('SELECT clock_timestamp() AS now');
      const leaseExpiresAt = new Date(new Date(clockRows[0].now).getTime() + leaseSeconds * 1000);
      await client.query(
        `INSERT INTO lakeside_enrollment.import_attempt_lease(
           attempt_id, operation_id, account_id, attempt_generation,
           lease_token_hash, lease_expires_at
         ) VALUES ($1,$2,$3,$4,$5,$6)`,
        [attemptId, operationId, current.account_id, attemptGeneration, digest(leaseToken), leaseExpiresAt],
      );
      await client.query(
        'INSERT INTO lakeside_enrollment.import_live_attempt(account_id, operation_id, attempt_id) VALUES ($1,$2,$3)',
        [current.account_id, operationId, attemptId],
      );
      await audit(client, { operationId, accountId: current.account_id, action: 'enrollment.import_attempt_lease_issued', provenance,
        metadata: { authorityId, attemptId, attemptGeneration, fenceGeneration: String(fence.fence_generation) } });
      return {
        operationId, accountId: current.account_id, attemptId,
        attemptGeneration, leaseToken, leaseExpiresAt: leaseExpiresAt.toISOString(), status: 'leased',
      };
    });
  }

  async function bindImportAttempt(input) {
    const operationId = uuid(input.operationId);
    const attemptId = uuid(input.attemptId, 'attempt ID');
    if (attemptId === operationId) throw new EnrollmentConflictError();
    const attemptGeneration = generation(input.attemptGeneration, 'attempt generation');
    const leaseToken = opaque(input.leaseToken, 'attempt lease token');
    const destination = target(input.targetIdentity);
    const digestFingerprint = hash(input.digestFingerprint);
    const provenance = text(input.provenance, 256, 'provenance');
    return transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (current.state !== 'enrolling') throw new EnrollmentConflictError();
      const { rows: v1 } = await client.query('SELECT binding FROM lakeside_enrollment.import_binding WHERE operation_id=$1', [operationId]);
      const { rows: v1Abort } = await client.query('SELECT 1 FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [operationId]);
      if (v1[0] && !v1Abort[0]) throw new EnrollmentConflictError();
      const lease = await loadAttemptLease(client, { operationId, attemptId, attemptGeneration, leaseToken, accountId: current.account_id });
      const binding = {
        version: 2, attemptId, attemptGeneration,
        accountId: current.account_id, operationId,
        issuer: destination.issuer, realmId: destination.realmId, userId: destination.subject,
        legacyIssuer: current.issuer, legacySubject: current.subject,
        digestFingerprint, credentialAlgorithm: 'lakeside-legacy-bcrypt-v1', hashIterations: 12,
        fenceGeneration: String(fence.fence_generation), fenceTokenHash: fence.fence_token_hash,
        fenceExpiresAtMs: new Date(current.lease_expires_at).getTime(),
        attemptLeaseTokenHash: digest(leaseToken),
        attemptExpiresAtMs: new Date(lease.lease_expires_at).getTime(),
      };
      await requireTargetMapping(client, binding);
      const previousV2 = await client.query(
        'SELECT binding FROM lakeside_enrollment.import_attempt WHERE operation_id=$1 ORDER BY attempt_generation DESC LIMIT 1',
        [operationId],
      );
      const prior = previousV2.rows[0]?.binding ?? v1[0]?.binding ?? null;
      if (prior && !v2IdentityEqual(prior, binding)) throw new EnrollmentConflictError();
      const existing = await storedAttempt(client, attemptId, true);
      if (existing) {
        if (existing.operation_id !== operationId || existing.account_id !== current.account_id || String(existing.attempt_generation) !== attemptGeneration
            || !sameVersionBinding(existing.binding, binding)) throw new EnrollmentConflictError();
        return existing.binding;
      }
      const { rows: priorGeneration } = await client.query(
        `SELECT GREATEST(
           COALESCE((SELECT MAX(attempt_generation) FROM lakeside_enrollment.import_attempt WHERE operation_id=$1 AND attempt_id<>$2), 0),
           COALESCE((SELECT MAX(attempt_generation) FROM lakeside_enrollment.import_attempt_lease WHERE operation_id=$1 AND attempt_id<>$2), 0)
         )::text AS max_generation`,
        [operationId, attemptId],
      );
      const previousGeneration = nextGeneration(priorGeneration[0].max_generation, v1[0] ? '1' : '0');
      if (BigInt(attemptGeneration) !== BigInt(previousGeneration)) throw new EnrollmentConflictError();
      const { rows: generationRows } = await client.query(
        'SELECT attempt_id FROM lakeside_enrollment.import_attempt WHERE operation_id=$1 AND attempt_generation=$2',
        [operationId, attemptGeneration],
      );
      if (generationRows[0]) throw new EnrollmentConflictError();
      await client.query(
        `INSERT INTO lakeside_enrollment.import_attempt(
           attempt_id, operation_id, account_id, attempt_generation, binding
         ) VALUES ($1,$2,$3,$4,$5::jsonb)`,
        [attemptId, operationId, current.account_id, attemptGeneration, JSON.stringify(binding)],
      );
      await audit(client, { operationId, accountId: current.account_id, action: 'enrollment.import_attempt_bound', provenance,
        metadata: { attemptId, attemptGeneration, fenceGeneration: binding.fenceGeneration } });
      return binding;
    });
  }

  async function readProvider(binding, mode) {
    const loader = mode === 'abort'
      ? (options.abortImport ?? options.loadImportReceipt)
      : (options.loadCommittedImportReceipt ?? options.loadImportReceipt);
    if (typeof loader !== 'function') throw new EnrollmentStateError('Authenticated import receipt reader is required');
    const timeoutMs = options.importReceiptTimeoutMs ?? 5000;
    if (!Number.isInteger(timeoutMs) || timeoutMs < 10 || timeoutMs > 10000) throw new TypeError('Invalid import receipt timeout');
    const controller = new AbortController();
    let timer;
    try {
      return await Promise.race([
        Promise.resolve().then(() => loader(Object.freeze({ ...binding }), { signal: controller.signal })),
        new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new EnrollmentStateError('Import receipt lookup timed out')); }, timeoutMs); }),
      ]);
    } catch {
      throw new EnrollmentStateError('Authenticated import receipt is unavailable');
    } finally { clearTimeout(timer); controller.abort(); }
  }

  function receiptEvidence(binding, receipt, expectedState) {
    if (!receipt || receipt.state !== expectedState) {
      // Preserve v1 reconcile's conflict classification for malformed or
      // MUTATING committed evidence. Abort requests use the explicit state
      // error before reaching this helper.
      if (expectedState === 'COMMITTED') throw new EnrollmentConflictError();
      throw new EnrollmentStateError('Authenticated import receipt is unavailable');
    }
    if (!sameReceiptBinding(binding, receipt)) throw new EnrollmentConflictError();
    const receiptId = uuid(receipt.receiptId, 'receipt ID');
    return { receiptId, evidenceFingerprint: fingerprint({ ...binding, receiptId, state: expectedState }) };
  }

  async function persistV1Committed(client, current, binding, receiptId, evidenceFingerprint, provenance) {
    const { rows: aborted } = await client.query('SELECT 1 FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [binding.operationId]);
    if (aborted[0]) throw new EnrollmentConflictError();
    const { rows: recorded } = await client.query('SELECT receipt_id, evidence_fingerprint FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [binding.operationId]);
    if (recorded[0]) {
      if (recorded[0].receipt_id !== receiptId || recorded[0].evidence_fingerprint !== evidenceFingerprint || current.state !== 'credentialed') throw new EnrollmentConflictError();
      return publicEnrollment(current);
    }
    if (current.state !== 'enrolling') throw new EnrollmentConflictError();
    await client.query('INSERT INTO lakeside_enrollment.import_receipt(operation_id, receipt_id, evidence_fingerprint) VALUES ($1,$2,$3)', [binding.operationId, receiptId, evidenceFingerprint]);
    const { rows } = await client.query(`UPDATE lakeside_enrollment.enrollment
      SET state='credentialed', lease_authority=NULL, lease_token=NULL, lease_token_hash=NULL,
          lease_expires_at=NULL, updated_at=clock_timestamp()
      WHERE operation_id=$1 AND state='enrolling' RETURNING *`, [binding.operationId]);
    if (!rows[0]) throw new EnrollmentConflictError();
    await client.query('DELETE FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND operation_id=$2', [current.account_id, binding.operationId]);
    await audit(client, { operationId: binding.operationId, accountId: current.account_id, action: 'enrollment.import_reconciled', provenance,
      metadata: { receiptId, fenceGeneration: binding.fenceGeneration, state: 'credentialed' } });
    return publicEnrollment(rows[0]);
  }

  async function persistAttemptCommitted(client, current, binding, receiptId, evidenceFingerprint, provenance) {
    const attempt = await storedAttempt(client, binding.attemptId, true);
    if (!attempt || attempt.operation_id !== binding.operationId || attempt.account_id !== current.account_id || !sameVersionBinding(attempt.binding, binding)) throw new EnrollmentConflictError();
    const { rows: aborted } = await client.query('SELECT 1 FROM lakeside_enrollment.import_attempt_abort WHERE attempt_id=$1', [binding.attemptId]);
    if (aborted[0]) throw new EnrollmentConflictError();
    const { rows: recorded } = await client.query('SELECT receipt_id, evidence_fingerprint FROM lakeside_enrollment.import_attempt_receipt WHERE attempt_id=$1', [binding.attemptId]);
    if (recorded[0]) {
      if (recorded[0].receipt_id !== receiptId || recorded[0].evidence_fingerprint !== evidenceFingerprint || current.state !== 'credentialed') throw new EnrollmentConflictError();
      return publicEnrollment(current);
    }
    const { rows: live } = await client.query('SELECT attempt_id FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND attempt_id=$2 FOR UPDATE', [current.account_id, binding.attemptId]);
    if (!live[0]) throw new EnrollmentConflictError();
    if (current.state !== 'enrolling') throw new EnrollmentConflictError();
    await client.query('INSERT INTO lakeside_enrollment.import_attempt_receipt(attempt_id, receipt_id, evidence_fingerprint) VALUES ($1,$2,$3)', [binding.attemptId, receiptId, evidenceFingerprint]);
    const { rows } = await client.query(`UPDATE lakeside_enrollment.enrollment
      SET state='credentialed', lease_authority=NULL, lease_token=NULL, lease_token_hash=NULL,
          lease_expires_at=NULL, updated_at=clock_timestamp()
      WHERE operation_id=$1 AND state='enrolling' RETURNING *`, [binding.operationId]);
    if (!rows[0]) throw new EnrollmentConflictError();
    await client.query('DELETE FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND attempt_id=$2', [current.account_id, binding.attemptId]);
    await audit(client, { operationId: binding.operationId, accountId: current.account_id, action: 'enrollment.import_attempt_reconciled', provenance,
      metadata: { attemptId: binding.attemptId, receiptId, attemptGeneration: binding.attemptGeneration, state: 'credentialed' } });
    return publicEnrollment(rows[0]);
  }

  async function reconcileCredentialImport({ operationId, provenance }) {
    operationId = uuid(operationId);
    provenance = text(provenance, 256, 'provenance');
    const binding = await storedBinding(pool, operationId);
    if (!binding) throw new EnrollmentStateError('Immutable import binding is required');
    const receipt = await readProvider(binding, 'committed');
    const { receiptId, evidenceFingerprint } = receiptEvidence(binding, receipt, 'COMMITTED');
    return transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (fence.fence_token_hash !== binding.fenceTokenHash || String(fence.fence_generation) !== binding.fenceGeneration || current.account_id !== binding.accountId) throw new EnrollmentConflictError();
      await requireTargetMapping(client, binding);
      return persistV1Committed(client, current, binding, receiptId, evidenceFingerprint, provenance);
    });
  }

  async function reconcileImportAttempt({ operationId, attemptId, provenance }) {
    operationId = uuid(operationId);
    attemptId = uuid(attemptId, 'attempt ID');
    provenance = text(provenance, 256, 'provenance');
    const attempt = await storedAttempt(pool, attemptId);
    if (!attempt || attempt.operation_id !== operationId || attempt.binding?.version !== 2) throw new EnrollmentStateError('Immutable import attempt binding is required');
    const binding = attempt.binding;
    const receipt = await readProvider(binding, 'committed');
    const { receiptId, evidenceFingerprint } = receiptEvidence(binding, receipt, 'COMMITTED');
    return transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (fence.fence_token_hash !== binding.fenceTokenHash || String(fence.fence_generation) !== binding.fenceGeneration || current.account_id !== binding.accountId) throw new EnrollmentConflictError();
      await requireTargetMapping(client, binding);
      return persistAttemptCommitted(client, current, binding, receiptId, evidenceFingerprint, provenance);
    });
  }

  async function persistAborted(client, current, binding, receiptId, evidenceFingerprint, provenance, v1) {
    if (current.state === 'unified') throw new EnrollmentConflictError();
    if (v1) {
      const { rows: committed } = await client.query('SELECT 1 FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [binding.operationId]);
      if (committed[0]) throw new EnrollmentConflictError();
      const { rows: existing } = await client.query('SELECT receipt_id, evidence_fingerprint FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1', [binding.operationId]);
      if (existing[0]) {
        if (existing[0].receipt_id !== receiptId || existing[0].evidence_fingerprint !== evidenceFingerprint) throw new EnrollmentConflictError();
        return publicEnrollment(current);
      }
      await client.query('INSERT INTO lakeside_enrollment.import_v1_abort(operation_id, receipt_id, evidence_fingerprint) VALUES ($1,$2,$3)', [binding.operationId, receiptId, evidenceFingerprint]);
      await client.query('DELETE FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND attempt_id=$2', [current.account_id, binding.operationId]);
    } else {
      const attempt = await storedAttempt(client, binding.attemptId, true);
      if (!attempt || !sameVersionBinding(attempt.binding, binding)) throw new EnrollmentConflictError();
      const { rows: committed } = await client.query('SELECT 1 FROM lakeside_enrollment.import_attempt_receipt WHERE attempt_id=$1', [binding.attemptId]);
      if (committed[0]) throw new EnrollmentConflictError();
      const { rows: existing } = await client.query('SELECT receipt_id, evidence_fingerprint FROM lakeside_enrollment.import_attempt_abort WHERE attempt_id=$1', [binding.attemptId]);
      if (existing[0]) {
        if (existing[0].receipt_id !== receiptId || existing[0].evidence_fingerprint !== evidenceFingerprint) throw new EnrollmentConflictError();
        return publicEnrollment(current);
      }
      await client.query('INSERT INTO lakeside_enrollment.import_attempt_abort(attempt_id, receipt_id, evidence_fingerprint) VALUES ($1,$2,$3)', [binding.attemptId, receiptId, evidenceFingerprint]);
      await client.query('DELETE FROM lakeside_enrollment.import_live_attempt WHERE account_id=$1 AND attempt_id=$2', [current.account_id, binding.attemptId]);
    }
    await audit(client, { operationId: binding.operationId, accountId: current.account_id, action: 'enrollment.import_aborted', provenance,
      metadata: { receiptId, attemptId: binding.attemptId ?? null, state: 'enrolling' } });
    return publicEnrollment(current);
  }

  async function abortCredentialImport({ operationId, attemptId, provenance }) {
    operationId = uuid(operationId);
    provenance = text(provenance, 256, 'provenance');
    const v1 = await storedBinding(pool, operationId);
    const candidateId = attemptId == null ? null : uuid(attemptId, 'attempt ID');
    const candidate = candidateId ? await storedAttempt(pool, candidateId) : null;
    const isV1 = v1 != null && (candidateId == null || candidateId === operationId) && (!candidate || candidate.binding?.version == null);
    if (!isV1 && !candidate) throw new EnrollmentStateError('Immutable import binding or attempt is required');
    const binding = isV1 ? v1 : candidate.binding;
    if (!isV1 && candidate.operation_id !== operationId) throw new EnrollmentConflictError();
    const existingAbort = await pool.query(
      isV1
        ? 'SELECT receipt_id FROM lakeside_enrollment.import_v1_abort WHERE operation_id=$1'
        : 'SELECT receipt_id FROM lakeside_enrollment.import_attempt_abort WHERE attempt_id=$1',
      [isV1 ? operationId : candidateId],
    );
    if (existingAbort.rows[0]) {
      const { rows } = await pool.query('SELECT * FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [operationId]);
      if (!rows[0]) throw new EnrollmentStateError('Enrollment operation was not found');
      return publicEnrollment(rows[0]);
    }
    // Reject held or suspended accounts before invoking the provider abort
    // operation. The provider call is terminal evidence, but it is still a
    // trusted state-changing operation and must not bypass account security.
    await transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (fence.fence_token_hash !== binding.fenceTokenHash || String(fence.fence_generation) !== binding.fenceGeneration || current.account_id !== binding.accountId) throw new EnrollmentConflictError();
      await requireTargetMapping(client, binding);
      if (current.state === 'unified') throw new EnrollmentConflictError();
      if (isV1) {
        const { rows } = await client.query('SELECT 1 FROM lakeside_enrollment.import_receipt WHERE operation_id=$1', [operationId]);
        if (rows[0]) throw new EnrollmentConflictError();
      } else {
        const { rows } = await client.query('SELECT 1 FROM lakeside_enrollment.import_attempt_receipt WHERE attempt_id=$1', [candidateId]);
        if (rows[0]) throw new EnrollmentConflictError();
      }
    });
    const evidence = await readProvider(binding, 'abort');
    if (evidence?.state !== 'ABORTED' && evidence?.state !== 'COMMITTED') throw new EnrollmentStateError('Authenticated import receipt is unavailable');
    const { receiptId, evidenceFingerprint } = receiptEvidence(binding, evidence, evidence.state);
    return transaction(pool, async client => {
      const { current, fence } = await currentFenceState(client, operationId);
      if (fence.fence_token_hash !== binding.fenceTokenHash || String(fence.fence_generation) !== binding.fenceGeneration || current.account_id !== binding.accountId) throw new EnrollmentConflictError();
      await requireTargetMapping(client, binding);
      if (evidence.state === 'COMMITTED') {
        if (isV1) return persistV1Committed(client, current, binding, receiptId, evidenceFingerprint, provenance);
        return persistAttemptCommitted(client, current, binding, receiptId, evidenceFingerprint, provenance);
      }
      return persistAborted(client, current, binding, receiptId, evidenceFingerprint, provenance, isV1);
    });
  }

  return {
    bindCredentialImport,
    reconcileCredentialImport,
    issueImportAttemptLease,
    bindImportAttempt,
    reconcileImportAttempt,
    abortCredentialImport,
  };
}
