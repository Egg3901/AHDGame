// Final activation is its own durable step. Credential-import success is a
// prerequisite, never evidence that the disabled issuer account was enabled.
export function createActivationReconciliation(context) {
  const { pool, options, transaction, uuid, text, fingerprint, audit, publicEnrollment,
    EnrollmentConflictError, EnrollmentStateError, EnrollmentAccountSuspendedError } = context;
  const sameBinding = (left, right) => left && right
    && ['version', 'operationId', 'accountId', 'issuer', 'realmId', 'userId', 'importReceiptId']
      .every(key => left[key] === right[key])
    && Object.keys(left).length === Object.keys(right).length;

  async function deriveBinding(client, operationId) {
    const { rows } = await client.query(
      `SELECT e.operation_id, e.account_id::text, e.state, a.status, a.recovery_hold,
              COALESCE(v2.binding, v1.binding) AS import_binding,
              COALESCE(v2.receipt_id, v1r.receipt_id)::text AS import_receipt_id
         FROM lakeside_enrollment.enrollment e
         JOIN lakeside_accounts.account a ON a.account_id=e.account_id
         LEFT JOIN lakeside_enrollment.import_binding v1 ON v1.operation_id=e.operation_id
         LEFT JOIN lakeside_enrollment.import_receipt v1r ON v1r.operation_id=v1.operation_id
         LEFT JOIN LATERAL (
           SELECT attempt.binding, receipt.receipt_id
             FROM lakeside_enrollment.import_attempt attempt
             JOIN lakeside_enrollment.import_attempt_receipt receipt
               ON receipt.attempt_id=attempt.attempt_id
            WHERE attempt.operation_id=e.operation_id
            LIMIT 1
         ) v2 ON true
        WHERE e.operation_id=$1
        FOR UPDATE OF e, a`,
      [operationId],
    );
    if (rows.length !== 1) throw new EnrollmentStateError('One committed credential import is required');
    const row = rows[0];
    if (row.status !== 'active' || row.recovery_hold !== false) throw new EnrollmentAccountSuspendedError();
    if (row.state !== 'credentialed' || !row.import_binding || !row.import_receipt_id) {
      throw new EnrollmentStateError('Credentialed target evidence is required');
    }
    const imported = row.import_binding;
    return Object.freeze({
      version: 1,
      operationId: uuid(row.operation_id),
      accountId: uuid(row.account_id, 'account ID'),
      issuer: text(imported.issuer, 512, 'target issuer'),
      realmId: text(imported.realmId, 255, 'target realm'),
      userId: uuid(imported.userId, 'target subject'),
      importReceiptId: uuid(row.import_receipt_id, 'import receipt ID'),
    });
  }

  async function bindTargetActivation({ operationId, provenance }) {
    operationId = uuid(operationId);
    provenance = text(provenance, 256, 'provenance');
    return transaction(pool, async client => {
      const binding = await deriveBinding(client, operationId);
      const { rows } = await client.query(
        'SELECT binding FROM lakeside_enrollment.activation_binding WHERE operation_id=$1',
        [operationId],
      );
      if (rows[0]) {
        if (!sameBinding(rows[0].binding, binding)) throw new EnrollmentConflictError();
        return binding;
      }
      await client.query(
        'INSERT INTO lakeside_enrollment.activation_binding(operation_id,account_id,binding) VALUES($1,$2,$3::jsonb)',
        [operationId, binding.accountId, JSON.stringify(binding)],
      );
      await audit(client, { operationId, accountId: binding.accountId,
        action: 'enrollment.activation_bound', provenance,
        metadata: { issuer: binding.issuer, importReceiptId: binding.importReceiptId } });
      return binding;
    });
  }

  async function reconcileTargetActivation({ operationId, provenance }) {
    operationId = uuid(operationId);
    provenance = text(provenance, 256, 'provenance');
    const { rows } = await pool.query(
      'SELECT binding FROM lakeside_enrollment.activation_binding WHERE operation_id=$1',
      [operationId],
    );
    const binding = rows[0]?.binding;
    if (!binding) throw new EnrollmentStateError('Immutable activation binding is required');
    if (typeof options.loadActivationReceipt !== 'function') {
      throw new EnrollmentStateError('Authenticated activation receipt is unavailable');
    }
    const timeoutMs = options.activationReceiptTimeoutMs ?? 5000;
    if (!Number.isInteger(timeoutMs) || timeoutMs < 10 || timeoutMs > 10000) {
      throw new TypeError('activationReceiptTimeoutMs must be an integer from 10 through 10000');
    }
    const controller = new AbortController();
    let timer;
    let loaded;
    try {
      loaded = await Promise.race([
        Promise.resolve().then(() => options.loadActivationReceipt(
          Object.freeze({ ...binding }), { signal: controller.signal },
        )),
        new Promise((_, reject) => {
          timer = setTimeout(() => {
            controller.abort();
            reject(new Error('activation receipt timeout'));
          }, timeoutMs);
        }),
      ]);
    } catch {
      throw new EnrollmentStateError('Authenticated activation receipt is unavailable');
    } finally {
      clearTimeout(timer);
      controller.abort();
    }
    const evidence = loaded && typeof loaded === 'object' && !Array.isArray(loaded)
      ? Object.fromEntries(Object.entries(loaded)) : loaded;
    const expected = { ...binding, state: 'COMMITTED' };
    if (!evidence || Object.keys(expected).some(key => evidence[key] !== expected[key])) {
      throw new EnrollmentConflictError();
    }
    const receiptId = uuid(evidence.receiptId, 'receipt ID');
    if (Object.keys(evidence).sort().join() !== [...Object.keys(expected), 'receiptId'].sort().join()) {
      throw new EnrollmentConflictError();
    }
    const evidenceFingerprint = fingerprint({ ...expected, receiptId });
    return transaction(pool, async client => {
      const { rows: recorded } = await client.query(
        'SELECT receipt_id::text,evidence_fingerprint FROM lakeside_enrollment.activation_receipt WHERE operation_id=$1',
        [operationId],
      );
      if (recorded[0]) {
        if (recorded[0].receipt_id !== receiptId || recorded[0].evidence_fingerprint !== evidenceFingerprint) throw new EnrollmentConflictError();
        const { rows: enrollment } = await client.query('SELECT * FROM lakeside_enrollment.enrollment WHERE operation_id=$1', [operationId]);
        if (enrollment[0]?.state !== 'unified') throw new EnrollmentConflictError();
        return publicEnrollment(enrollment[0]);
      }
      const current = await deriveBinding(client, operationId);
      if (!sameBinding(current, binding)) throw new EnrollmentConflictError();
      await client.query(
        'INSERT INTO lakeside_enrollment.activation_receipt(operation_id,receipt_id,evidence_fingerprint) VALUES($1,$2,$3)',
        [operationId, receiptId, evidenceFingerprint],
      );
      const { rows: updated } = await client.query(
        `UPDATE lakeside_enrollment.enrollment
            SET state='unified', unified_at=clock_timestamp(), updated_at=clock_timestamp()
          WHERE operation_id=$1 AND state='credentialed' RETURNING *`,
        [operationId],
      );
      if (!updated[0]) throw new EnrollmentConflictError();
      await audit(client, { operationId, accountId: binding.accountId,
        action: 'enrollment.activation_reconciled', provenance,
        metadata: { receiptId, importReceiptId: binding.importReceiptId, state: 'unified' } });
      return publicEnrollment(updated[0]);
    });
  }

  return { bindTargetActivation, reconcileTargetActivation };
}
