const ERROR_MESSAGES = Object.freeze({
  missing: 'Source ownership proof was not found',
  unavailable: 'Source ownership proof is unavailable',
  invalid: 'Source ownership proof is invalid',
  expired: 'Source ownership proof is expired',
  binding: 'Source ownership proof binding does not match',
});

const INPUT_KEYS = Object.freeze(['canonicalAccountId', 'enrollmentOperationId', 'proofId', 'sourceAccountId']);
const WRAPPER_KEYS = Object.freeze(['expired', 'proof', 'sourceNowMs']);
const PROOF_KEYS = Object.freeze([
  'canonicalAccountId',
  'enrollmentOperationId',
  'expiresAtMs',
  'method',
  'observationWindowMs',
  'observedAtMs',
  'proofId',
  'retainedMethods',
  'snapshotDigest',
  'snapshotVersion',
  'sourceAccountId',
  'sourceIssuer',
  'version',
]);

const UUID_V4 = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})(?![\s\S])/u;
const HEX24 = /^(?:[0-9a-f]{24})(?![\s\S])/u;
const HEX64 = /^(?:[0-9a-f]{64})(?![\s\S])/u;
const CONTROL = /[\u0000-\u0020\u007f\u2028\u2029]/u;
const PROOF_LIFETIME_MS = 270000;
const OBSERVATION_WINDOW_MS = 30000;
const DEFAULT_TIMEOUT_MS = 5000;
const MIN_TIMEOUT_MS = 10;
const MAX_TIMEOUT_MS = 10000;
const MAX_ISSUER_LENGTH = 512;

/**
 * Sanitized local failure. Messages never include a proof body, token,
 * endpoint, injected exception, cause, or getter-derived text.
 */
export class SourceOwnershipProofReadError extends Error {
  constructor(code = 'unavailable') {
    const safeCode = typeof code === 'string' && Object.hasOwn(ERROR_MESSAGES, code) ? code : 'unavailable';
    super(ERROR_MESSAGES[safeCode]);
    this.name = 'SourceOwnershipProofReadError';
    this.code = safeCode;
  }
}

function fail(code) {
  return new SourceOwnershipProofReadError(code);
}

function ignore(promise) {
  Promise.resolve(promise).then(() => {}, () => {});
}

function ownKeys(value) {
  if (value == null || typeof value !== 'object' || Array.isArray(value)) return null;
  try {
    return Object.keys(value);
  } catch {
    return null;
  }
}

function exactKeys(value, expected) {
  const actual = ownKeys(value);
  if (!actual || actual.length !== expected.length) return false;
  actual.sort();
  return actual.every((key, index) => key === expected[index]);
}

function pinnedSourceIssuer(value) {
  if (!isPinnedSourceIssuer(value)) throw new TypeError('Exact source issuer required');
  return value;
}

function lowercaseV4Uuid(value) {
  return typeof value === 'string' && value.length === 36 && value.isWellFormed() && UUID_V4.test(value);
}

function lowercaseHex24(value) {
  return typeof value === 'string' && value.length === 24 && value.isWellFormed() && HEX24.test(value);
}

function lowercaseHex64(value) {
  return typeof value === 'string' && value.length === 64 && value.isWellFormed() && HEX64.test(value);
}

function positiveSafeInteger(value) {
  return typeof value === 'number' && Number.isSafeInteger(value) && value > 0;
}

function reconstruct(caught, fallback) {
  let code = fallback;
  try {
    if (caught instanceof SourceOwnershipProofReadError) code = caught.code;
  } catch {
    code = fallback;
  }
  throw fail(code);
}

function captureInput(input) {
  try {
    if (!exactKeys(input, INPUT_KEYS)) throw fail('invalid');
    const proofId = input.proofId;
    const sourceAccountId = input.sourceAccountId;
    const canonicalAccountId = input.canonicalAccountId;
    const enrollmentOperationId = input.enrollmentOperationId;
    if (!lowercaseV4Uuid(proofId) || !lowercaseHex24(sourceAccountId)
        || !lowercaseV4Uuid(canonicalAccountId) || !lowercaseV4Uuid(enrollmentOperationId)) {
      throw fail('invalid');
    }
    return Object.freeze({ proofId, sourceAccountId, canonicalAccountId, enrollmentOperationId });
  } catch (caught) {
    reconstruct(caught, 'invalid');
  }
}

function captureParentSignal(options) {
  try {
    if (options === undefined) return undefined;
    if (!exactKeys(options, Object.freeze(['parentAbortSignal'])) && !exactKeys(options, Object.freeze([]))) {
      throw fail('invalid');
    }
    if (!Object.hasOwn(options, 'parentAbortSignal')) return undefined;
    const parent = options.parentAbortSignal;
    if (parent === undefined) return undefined;
    if (!(parent instanceof AbortSignal)) throw fail('invalid');
    return parent;
  } catch (caught) {
    reconstruct(caught, 'invalid');
  }
}

function freezeProof(fields) {
  return Object.freeze({
    proofId: fields.proofId,
    version: 1,
    sourceIssuer: fields.sourceIssuer,
    sourceAccountId: fields.sourceAccountId,
    canonicalAccountId: fields.canonicalAccountId,
    enrollmentOperationId: fields.enrollmentOperationId,
    snapshotVersion: 1,
    snapshotDigest: fields.snapshotDigest,
    method: 'password',
    retainedMethods: Object.freeze(['password']),
    observedAtMs: fields.observedAtMs,
    expiresAtMs: fields.expiresAtMs,
    observationWindowMs: OBSERVATION_WINDOW_MS,
  });
}

function interpretResult(raw, requested, configuredIssuer) {
  try {
    if (raw === null) throw fail('missing');
    if (!exactKeys(raw, WRAPPER_KEYS)) throw fail('invalid');
    const sourceNowMs = raw.sourceNowMs;
    const expiredFlag = raw.expired;
    const proof = raw.proof;
    if (typeof expiredFlag !== 'boolean' || !positiveSafeInteger(sourceNowMs) || !exactKeys(proof, PROOF_KEYS)) {
      throw fail('invalid');
    }
    const proofId = proof.proofId;
    const version = proof.version;
    const sourceIssuer = proof.sourceIssuer;
    const sourceAccountId = proof.sourceAccountId;
    const canonicalAccountId = proof.canonicalAccountId;
    const enrollmentOperationId = proof.enrollmentOperationId;
    const snapshotVersion = proof.snapshotVersion;
    const snapshotDigest = proof.snapshotDigest;
    const method = proof.method;
    const retainedMethods = proof.retainedMethods;
    const observedAtMs = proof.observedAtMs;
    const expiresAtMs = proof.expiresAtMs;
    const observationWindowMs = proof.observationWindowMs;
    if (version !== 1 || snapshotVersion !== 1 || method !== 'password'
        || observationWindowMs !== OBSERVATION_WINDOW_MS
        || !lowercaseV4Uuid(proofId) || !lowercaseHex24(sourceAccountId)
        || !lowercaseV4Uuid(canonicalAccountId) || !lowercaseV4Uuid(enrollmentOperationId)
        || !lowercaseHex64(snapshotDigest)
        || typeof sourceIssuer !== 'string' || sourceIssuer.length < 1 || sourceIssuer.length > MAX_ISSUER_LENGTH
        || !sourceIssuer.isWellFormed() || CONTROL.test(sourceIssuer)
        || !positiveSafeInteger(observedAtMs) || !positiveSafeInteger(expiresAtMs)
        || expiresAtMs - observedAtMs !== PROOF_LIFETIME_MS
        || !Array.isArray(retainedMethods) || retainedMethods.length !== 1
        || retainedMethods[0] !== 'password') {
      throw fail('invalid');
    }
    if (!isPinnedSourceIssuer(sourceIssuer)) throw fail('invalid');
    if (proofId !== requested.proofId || sourceIssuer !== configuredIssuer
        || sourceAccountId !== requested.sourceAccountId
        || canonicalAccountId !== requested.canonicalAccountId
        || enrollmentOperationId !== requested.enrollmentOperationId) {
      throw fail('binding');
    }
    if (sourceNowMs < observedAtMs) throw fail('invalid');
    if (expiredFlag === true && sourceNowMs >= expiresAtMs) throw fail('expired');
    if (expiredFlag !== false || sourceNowMs >= expiresAtMs) throw fail('invalid');
    return Object.freeze({
      proof: freezeProof({
        proofId,
        sourceIssuer,
        sourceAccountId,
        canonicalAccountId,
        enrollmentOperationId,
        snapshotDigest,
        observedAtMs,
        expiresAtMs,
      }),
      sourceNowMs,
      expired: false,
    });
  } catch (caught) {
    reconstruct(caught, 'invalid');
  }
}

/**
 * Trusted-backend adapter. Authentication is the deployer-injected loader
 * pinned to the configured source issuer, not a claim hash or timestamp.
 * The adapter does not authenticate transport by itself.
 */
export function createSourceOwnershipProofReader(config) {
  if (config == null || typeof config !== 'object' || Array.isArray(config)) {
    throw new TypeError('Invalid source ownership proof reader configuration');
  }
  const configKeys = ownKeys(config);
  if (!configKeys) throw new TypeError('Invalid source ownership proof reader configuration');
  for (const key of configKeys) {
    if (key !== 'sourceIssuer' && key !== 'loadSourceProof' && key !== 'timeoutMs') {
      throw new TypeError('Invalid source ownership proof reader configuration');
    }
  }
  const sourceIssuer = pinnedSourceIssuer(config.sourceIssuer);
  const loadSourceProof = config.loadSourceProof;
  if (typeof loadSourceProof !== 'function') {
    throw new TypeError('An authenticated source proof loader is required');
  }
  const timeoutMs = Object.hasOwn(config, 'timeoutMs') ? config.timeoutMs : DEFAULT_TIMEOUT_MS;
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < MIN_TIMEOUT_MS || timeoutMs > MAX_TIMEOUT_MS) {
    throw new TypeError('Source proof loader timeout must be bounded');
  }

  async function loadBounded(proofId, parentAbortSignal) {
    const controller = new AbortController();
    let timer;
    const onParentAbort = () => controller.abort();
    if (parentAbortSignal && !parentAbortSignal.aborted) {
      parentAbortSignal.addEventListener('abort', onParentAbort, { once: true });
    }
    timer = setTimeout(() => controller.abort(), timeoutMs);
    if (parentAbortSignal?.aborted) controller.abort();
    const loaderPromise = Promise.resolve().then(() => {
      if (controller.signal.aborted) throw fail('unavailable');
      return loadSourceProof(Object.freeze({ proofId }), Object.freeze({ signal: controller.signal }));
    });
    ignore(loaderPromise);
    try {
      return await new Promise((resolve, reject) => {
        let settled = false;
        const finish = (fn, value) => {
          if (settled) return;
          settled = true;
          controller.signal.removeEventListener('abort', onAbort);
          fn(value);
        };
        const onAbort = () => finish(reject, fail('unavailable'));
        controller.signal.addEventListener('abort', onAbort, { once: true });
        if (controller.signal.aborted) {
          onAbort();
          return;
        }
        loaderPromise.then(
          value => finish(resolve, value),
          () => finish(reject, fail('unavailable')),
        );
      });
    } finally {
      clearTimeout(timer);
      if (parentAbortSignal) parentAbortSignal.removeEventListener('abort', onParentAbort);
      controller.abort();
    }
  }

  async function loadProof(input, options) {
    const requested = captureInput(input);
    const parentAbortSignal = captureParentSignal(options);
    if (parentAbortSignal?.aborted) throw fail('unavailable');
    let raw;
    try {
      raw = await loadBounded(requested.proofId, parentAbortSignal);
    } catch {
      throw fail('unavailable');
    }
    return interpretResult(raw, requested, sourceIssuer);
  }

  return Object.freeze({ loadProof });
}
import { isPinnedSourceIssuer } from './source-issuer.mjs';
