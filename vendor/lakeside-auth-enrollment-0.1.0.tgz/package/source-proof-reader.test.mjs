import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createSourceOwnershipProofReader,
  SourceOwnershipProofReadError,
} from './source-proof-reader.mjs';

const ISSUER = 'https://source.example.invalid/auth';
const PROOF_ID = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa';
const ACCOUNT = '0123456789abcdef01234567';
const CANONICAL = 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb';
const ENROLL = 'cccccccc-cccc-4ccc-8ccc-cccccccccccc';
const DIGEST = 'a'.repeat(64);
const OBSERVED = 1_700_000_000_000;
const LIFETIME = 270_000;
const EXPIRES = OBSERVED + LIFETIME;
const NOW = OBSERVED + 1_000;

const INPUT = Object.freeze({
  proofId: PROOF_ID,
  sourceAccountId: ACCOUNT,
  canonicalAccountId: CANONICAL,
  enrollmentOperationId: ENROLL,
});

function proof(overrides = {}) {
  return {
    proofId: PROOF_ID,
    version: 1,
    sourceIssuer: ISSUER,
    sourceAccountId: ACCOUNT,
    canonicalAccountId: CANONICAL,
    enrollmentOperationId: ENROLL,
    snapshotVersion: 1,
    snapshotDigest: DIGEST,
    method: 'password',
    retainedMethods: ['password'],
    observedAtMs: OBSERVED,
    expiresAtMs: EXPIRES,
    observationWindowMs: 30_000,
    ...overrides,
  };
}

function wrapper(overrides = {}, proofOverrides = {}) {
  return {
    proof: proof(proofOverrides),
    sourceNowMs: NOW,
    expired: false,
    ...overrides,
  };
}

function reader(loadSourceProof, overrides = {}) {
  return createSourceOwnershipProofReader({
    sourceIssuer: ISSUER,
    loadSourceProof,
    timeoutMs: 100,
    ...overrides,
  });
}

function isCode(code) {
  return error => error instanceof SourceOwnershipProofReadError
    && error.code === code
    && error.message === {
      missing: 'Source ownership proof was not found',
      unavailable: 'Source ownership proof is unavailable',
      invalid: 'Source ownership proof is invalid',
      expired: 'Source ownership proof is expired',
      binding: 'Source ownership proof binding does not match',
    }[code];
}

test('reads exact frozen metadata plus the source clock from the trusted loader', async () => {
  let seenQuery;
  let seenOptions;
  const loadSourceProof = async (query, options) => {
    seenQuery = query;
    seenOptions = options;
    return wrapper();
  };
  const result = await reader(loadSourceProof).loadProof({ ...INPUT });
  assert.equal(Object.isFrozen(result), true);
  assert.equal(Object.isFrozen(result.proof), true);
  assert.equal(Object.isFrozen(result.proof.retainedMethods), true);
  assert.deepEqual(Object.keys(result).sort(), ['expired', 'proof', 'sourceNowMs']);
  assert.deepEqual(Object.keys(result.proof).sort(), [
    'canonicalAccountId', 'enrollmentOperationId', 'expiresAtMs', 'method',
    'observationWindowMs', 'observedAtMs', 'proofId', 'retainedMethods',
    'snapshotDigest', 'snapshotVersion', 'sourceAccountId', 'sourceIssuer', 'version',
  ]);
  assert.deepEqual(result, {
    proof: {
      proofId: PROOF_ID,
      version: 1,
      sourceIssuer: ISSUER,
      sourceAccountId: ACCOUNT,
      canonicalAccountId: CANONICAL,
      enrollmentOperationId: ENROLL,
      snapshotVersion: 1,
      snapshotDigest: DIGEST,
      method: 'password',
      retainedMethods: ['password'],
      observedAtMs: OBSERVED,
      expiresAtMs: EXPIRES,
      observationWindowMs: 30_000,
    },
    sourceNowMs: NOW,
    expired: false,
  });
  assert.equal(result.proof.expiresAtMs - result.proof.observedAtMs, 270000);
  assert.equal(Object.isFrozen(seenQuery), true);
  assert.deepEqual(Object.keys(seenQuery), ['proofId']);
  assert.equal(seenQuery.proofId, PROOF_ID);
  assert.equal(Object.isFrozen(seenOptions), true);
  assert.deepEqual(Object.keys(seenOptions), ['signal']);
  assert.equal(seenOptions.signal instanceof AbortSignal, true);
});

test('missing null is missing, not abort or unavailable', async () => {
  let calls = 0;
  const result = reader(async () => {
    calls += 1;
    return null;
  });
  await assert.rejects(result.loadProof({ ...INPUT }), isCode('missing'));
  assert.equal(calls, 1);
});

test('timeout bounds an uncooperative loader, aborts its signal, and suppresses a late result', async () => {
  let seenSignal;
  let resolveLate;
  const late = new Promise(resolve => { resolveLate = resolve; });
  const loadSourceProof = (_query, { signal }) => {
    seenSignal = signal;
    return late;
  };
  const started = Date.now();
  await assert.rejects(reader(loadSourceProof, { timeoutMs: 20 }).loadProof({ ...INPUT }), isCode('unavailable'));
  assert.equal(Date.now() - started < 1000, true);
  assert.equal(seenSignal.aborted, true);
  resolveLate(wrapper());
  await new Promise(resolve => setTimeout(resolve, 20));
});

test('parent abort bounds the loader and an already-aborted parent never calls it', async () => {
  let calls = 0;
  const hanging = reader(async () => {
    calls += 1;
    return new Promise(() => {});
  });
  const live = new AbortController();
  const pending = hanging.loadProof({ ...INPUT }, { parentAbortSignal: live.signal });
  live.abort();
  await assert.rejects(pending, isCode('unavailable'));

  const prior = new AbortController();
  prior.abort();
  const callsBefore = calls;
  await assert.rejects(
    hanging.loadProof({ ...INPUT }, { parentAbortSignal: prior.signal }),
    isCode('unavailable'),
  );
  assert.equal(calls, callsBefore);
});

test('invalid input never calls the loader', async () => {
  let calls = 0;
  const load = reader(async () => {
    calls += 1;
    return wrapper();
  });
  const badUuid = `${PROOF_ID}\n`;
  const newlineIds = {
    proofId: `${PROOF_ID}\n`,
    sourceAccountId: `${ACCOUNT}\n`,
    canonicalAccountId: `${CANONICAL}\n`,
    enrollmentOperationId: `${ENROLL}\n`,
  };
  for (const input of [
    null,
    undefined,
    [],
    { ...INPUT, extra: true },
    { proofId: PROOF_ID, sourceAccountId: ACCOUNT, canonicalAccountId: CANONICAL },
    { ...INPUT, proofId: 'not-a-uuid' },
    { ...INPUT, proofId: PROOF_ID.toUpperCase() },
    { ...INPUT, proofId: 'aaaaaaaa-aaaa-1aaa-8aaa-aaaaaaaaaaaa' },
    { ...INPUT, proofId: { toString: () => PROOF_ID } },
    { ...INPUT, sourceAccountId: ACCOUNT.toUpperCase() },
    { ...INPUT, sourceAccountId: `${ACCOUNT}aa` },
    { ...INPUT, password: 'synthetic-password' },
    { ...INPUT, cookie: 'session=1' },
    { ...INPUT, proofId: badUuid },
  ]) {
    await assert.rejects(load.loadProof(input), isCode('invalid'));
  }
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    for (const [key, value] of Object.entries(newlineIds)) {
      await assert.rejects(load.loadProof({ ...INPUT, [key]: value.replace('\n', suffix) }), isCode('invalid'));
    }
  }
  await assert.rejects(load.loadProof({ ...INPUT }, { signal: new AbortController().signal }), isCode('invalid'));
  await assert.rejects(load.loadProof({ ...INPUT }, { parentAbortSignal: {} }), isCode('invalid'));
  await assert.rejects(load.loadProof({ ...INPUT }, null), isCode('invalid'));
  assert.equal(calls, 0);
});

test('exact source and requested identifier mismatches are binding failures', async () => {
  const mismatches = [
    { proofId: 'dddddddd-dddd-4ddd-8ddd-dddddddddddd' },
    { sourceIssuer: 'https://other.example.invalid/auth' },
    { sourceAccountId: 'abcdef0123456789abcdef01' },
    { canonicalAccountId: 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee' },
    { enrollmentOperationId: 'ffffffff-ffff-4fff-8fff-ffffffffffff' },
  ];
  for (const change of mismatches) {
    const load = reader(async () => wrapper({}, change));
    await assert.rejects(load.loadProof({ ...INPUT }), isCode('binding'));
  }
});

test('malformed UUID, digest, and line separators in the loader result are invalid', async () => {
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    await assert.rejects(reader(async () => wrapper({}, { proofId: PROOF_ID + suffix })).loadProof({ ...INPUT }), isCode('invalid'));
    await assert.rejects(reader(async () => wrapper({}, { snapshotDigest: DIGEST + suffix })).loadProof({ ...INPUT }), isCode('invalid'));
    await assert.rejects(reader(async () => wrapper({}, { sourceAccountId: ACCOUNT + suffix })).loadProof({ ...INPUT }), isCode('invalid'));
    await assert.rejects(reader(async () => wrapper({}, { canonicalAccountId: CANONICAL + suffix })).loadProof({ ...INPUT }), isCode('invalid'));
  }
  await assert.rejects(reader(async () => wrapper({}, { snapshotDigest: DIGEST.toUpperCase() })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { snapshotDigest: { toString: () => DIGEST } })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { proofId: PROOF_ID.toUpperCase() })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({ sourceNowMs: { toString: () => NOW } })).loadProof({ ...INPUT }), isCode('invalid'));
});

test('safe-integer edges and non-positive times are invalid', async () => {
  for (const value of [0, -1, 1.5, NaN, Infinity, -Infinity, Number.MAX_SAFE_INTEGER + 1, Number.MIN_SAFE_INTEGER, '1700000000000', new Date(NOW)]) {
    await assert.rejects(reader(async () => wrapper({ sourceNowMs: value })).loadProof({ ...INPUT }), isCode('invalid'));
    await assert.rejects(reader(async () => wrapper({}, { observedAtMs: value, expiresAtMs: value === OBSERVED ? EXPIRES : OBSERVED + LIFETIME })).loadProof({ ...INPUT }), isCode('invalid'));
  }
  await assert.rejects(reader(async () => wrapper({}, { expiresAtMs: OBSERVED + 269999 })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { expiresAtMs: OBSERVED + 270001 })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { observationWindowMs: 29999 })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { observedAtMs: Number.MAX_SAFE_INTEGER, expiresAtMs: Number.MAX_SAFE_INTEGER })).loadProof({ ...INPUT }), isCode('invalid'));
});

test('expired, future, and inconsistent wrappers fail closed', async () => {
  await assert.rejects(
    reader(async () => wrapper({ sourceNowMs: EXPIRES, expired: true })).loadProof({ ...INPUT }),
    isCode('expired'),
  );
  await assert.rejects(
    reader(async () => wrapper({ sourceNowMs: EXPIRES + 1, expired: true })).loadProof({ ...INPUT }),
    isCode('expired'),
  );
  await assert.rejects(
    reader(async () => wrapper({ sourceNowMs: OBSERVED - 1, expired: false })).loadProof({ ...INPUT }),
    isCode('invalid'),
  );
  await assert.rejects(
    reader(async () => wrapper({ sourceNowMs: EXPIRES, expired: false })).loadProof({ ...INPUT }),
    isCode('invalid'),
  );
  await assert.rejects(
    reader(async () => wrapper({ sourceNowMs: NOW, expired: true })).loadProof({ ...INPUT }),
    isCode('invalid'),
  );
  await assert.rejects(
    reader(async () => wrapper({ expired: 0 })).loadProof({ ...INPUT }),
    isCode('invalid'),
  );
  const fresh = await reader(async () => wrapper({ sourceNowMs: OBSERVED, expired: false })).loadProof({ ...INPUT });
  assert.equal(fresh.expired, false);
  assert.equal(fresh.sourceNowMs, OBSERVED);
  const lastTick = await reader(async () => wrapper({ sourceNowMs: EXPIRES - 1, expired: false })).loadProof({ ...INPUT });
  assert.equal(lastTick.sourceNowMs, EXPIRES - 1);
});

test('retained social methods, duplicates, and unknown keys are invalid', async () => {
  for (const retained of [['google'], ['password', 'google'], ['password', 'password'], [], 'password', ['Password']]) {
    await assert.rejects(reader(async () => wrapper({}, { retainedMethods: retained })).loadProof({ ...INPUT }), isCode('invalid'));
  }
  await assert.rejects(reader(async () => wrapper({}, { method: 'google' })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { extra: true })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { password: 'synthetic-password' })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { hash: 'synthetic-hash' })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({ verified: true })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({ extra: 1 })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => wrapper({}, { version: 2 })).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => ({})).loadProof({ ...INPUT }), isCode('invalid'));
  await assert.rejects(reader(async () => undefined).loadProof({ ...INPUT }), isCode('invalid'));
});

test('getters that throw a token do not leak into the local error', async () => {
  const token = 'synthetic-secret-token-must-not-escape';
  const hostileProof = {};
  for (const key of Object.keys(proof())) {
    Object.defineProperty(hostileProof, key, { enumerable: true, get() { throw new Error(token); } });
  }
  await assert.rejects(
    reader(async () => ({ proof: hostileProof, sourceNowMs: NOW, expired: false })).loadProof({ ...INPUT }),
    error => isCode('invalid')(error) && !error.message.includes(token) && !('cause' in error),
  );
  const injected = new Error('innocent');
  Object.defineProperty(injected, 'message', { get() { throw new Error(token); } });
  Object.defineProperty(injected, 'code', { get() { throw new Error(token); } });
  Object.defineProperty(injected, 'cause', { get() { throw new Error(token); } });
  await assert.rejects(
    reader(async () => { throw injected; }).loadProof({ ...INPUT }),
    error => isCode('unavailable')(error) && !error.message.includes(token) && !('cause' in error),
  );
});

test('mutating the input during the loader wait cannot reroute the binding', async () => {
  const mutable = { ...INPUT };
  const otherAccount = 'abcdef0123456789abcdef01';
  const loadSourceProof = async () => {
    mutable.sourceAccountId = otherAccount;
    mutable.proofId = 'dddddddd-dddd-4ddd-8ddd-dddddddddddd';
    mutable.canonicalAccountId = 'eeeeeeee-eeee-4eee-8eee-eeeeeeeeeeee';
    mutable.enrollmentOperationId = 'ffffffff-ffff-4fff-8fff-ffffffffffff';
    return wrapper({}, { sourceAccountId: otherAccount });
  };
  await assert.rejects(reader(loadSourceProof).loadProof(mutable), isCode('binding'));
  const captured = { ...INPUT };
  const ok = reader(async () => {
    captured.sourceAccountId = otherAccount;
    return wrapper();
  });
  const result = await ok.loadProof(captured);
  assert.equal(result.proof.sourceAccountId, ACCOUNT);
});

test('mutating the raw loader result after return cannot change the captured value', async () => {
  const rawProof = proof();
  const raw = { proof: rawProof, sourceNowMs: NOW, expired: false };
  const result = await reader(async () => raw).loadProof({ ...INPUT });
  rawProof.sourceAccountId = 'abcdef0123456789abcdef01';
  rawProof.snapshotDigest = 'b'.repeat(64);
  raw.sourceNowMs = 1;
  raw.expired = true;
  rawProof.retainedMethods.push('google');
  assert.equal(result.proof.sourceAccountId, ACCOUNT);
  assert.equal(result.proof.snapshotDigest, DIGEST);
  assert.equal(result.sourceNowMs, NOW);
  assert.equal(result.expired, false);
  assert.deepEqual(result.proof.retainedMethods, ['password']);
});

test('injected typed errors with mutated secrets stay sanitized as unavailable', async () => {
  const secret = 'synthetic-secret-in-typed-error';
  const injected = new SourceOwnershipProofReadError('expired');
  injected.message = secret;
  await assert.rejects(
    reader(async () => { throw injected; }).loadProof({ ...INPUT }),
    error => isCode('unavailable')(error) && error.message !== secret && !error.message.includes(secret),
  );
  const typed = new TypeError(secret);
  typed.code = 'expired';
  typed.cause = { token: secret };
  await assert.rejects(
    reader(async () => { throw typed; }).loadProof({ ...INPUT }),
    error => isCode('unavailable')(error) && !error.message.includes(secret) && error.cause !== typed.cause,
  );
});

test('factory requires a pinned HTTPS issuer, injected loader, and bounded timeout', () => {
  const loadSourceProof = async () => wrapper();
  const valid = { sourceIssuer: ISSUER, loadSourceProof };
  assert.equal(typeof createSourceOwnershipProofReader(valid).loadProof, 'function');
  for (const changed of [
    { sourceIssuer: 'http://source.example.invalid/auth' },
    { sourceIssuer: 'urn:lakeside:source:test' },
    { sourceIssuer: 'urn:lakeside:legacy:ahd:Production' },
    { sourceIssuer: 'urn:lakeside:legacy:ahd:production?x' },
    { sourceIssuer: `${ISSUER}?` },
    { sourceIssuer: `${ISSUER}#fragment` },
    { sourceIssuer: 'https://user:secret@source.example.invalid/auth' },
    { sourceIssuer: 'https://source.example.invalid' },
    { sourceIssuer: 'https://Source.example.invalid/auth' },
    { sourceIssuer: 'https://source.example.invalid:443/auth' },
    { sourceIssuer: `${ISSUER}/../auth` },
    { sourceIssuer: 'lakeside-test-source' },
    { timeoutMs: 9 },
    { timeoutMs: 10001 },
    { timeoutMs: 5000.5 },
    { loadSourceProof: null },
    { extra: true },
  ]) {
    assert.throws(() => createSourceOwnershipProofReader({ ...valid, ...changed }), TypeError);
  }
  assert.throws(() => createSourceOwnershipProofReader({ loadSourceProof }), TypeError);
  assert.throws(() => createSourceOwnershipProofReader({ sourceIssuer: ISSUER }), TypeError);
  assert.throws(() => createSourceOwnershipProofReader({ ...valid, timeoutMs: undefined }), TypeError);
});

test('accepts the canonical legacy issuer namespace and binds returned proof to it', async () => {
  const legacyIssuer = 'urn:lakeside:legacy:ahd:production';
  const result = await reader(async () => wrapper({}, { sourceIssuer: legacyIssuer }), {
    sourceIssuer: legacyIssuer,
  }).loadProof({ ...INPUT });
  assert.equal(result.proof.sourceIssuer, legacyIssuer);
});
