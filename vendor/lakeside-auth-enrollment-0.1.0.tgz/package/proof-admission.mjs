import { performance } from 'node:perf_hooks';

const EXACT_INPUT_KEYS = Object.freeze([
  'idempotencyKey',
  'proofId',
  'provenance',
  'reservation',
  'sourceAccountId',
]);
const EXACT_RESERVATION_KEYS = Object.freeze([
  'canonicalAccountId',
  'enrollmentOperationId',
  'sourceIssuer',
  'sourceSubject',
  'version',
]);
const UUID_V4 = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u;
const HEX24 = /^[0-9a-f]{24}$/u;

export class ProofAdmissionExpiredError extends Error {
  constructor() {
    super('Source ownership proof expired before enrollment admission');
    this.name = 'ProofAdmissionExpiredError';
  }
}

function hasExactKeys(value, expected) {
  if (value == null || typeof value !== 'object' || Array.isArray(value)) return false;
  const keys = Object.keys(value).sort();
  return keys.length === expected.length && keys.every((key, index) => key === expected[index]);
}

function uuid(value, label) {
  if (typeof value !== 'string' || !UUID_V4.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}

function text(value, max, label) {
  if (typeof value !== 'string' || value.length < 1 || value.length > max
      || !value.isWellFormed() || value !== value.trim() || /[\u0000-\u001f\u007f]/u.test(value)) {
    throw new TypeError(`Invalid ${label}`);
  }
  return value;
}

function captureReservation(value) {
  if (!hasExactKeys(value, EXACT_RESERVATION_KEYS) || value.version !== 1) {
    throw new TypeError('Invalid enrollment reservation');
  }
  return Object.freeze({
    version: 1,
    sourceIssuer: text(value.sourceIssuer, 512, 'source issuer'),
    sourceSubject: text(value.sourceSubject, 512, 'source subject'),
    canonicalAccountId: uuid(value.canonicalAccountId, 'canonical account ID'),
    enrollmentOperationId: uuid(value.enrollmentOperationId, 'enrollment operation ID'),
  });
}

/**
 * Disabled trusted-backend composition boundary for proof-backed admission.
 * Authentication belongs to the injected proof reader. This module exposes
 * no HTTP route and never resumes admissions or selects a cohort.
 */
export function createProofBackedAdmission(options) {
  const optionKeys = options != null && typeof options === 'object' && !Array.isArray(options)
    ? Object.keys(options).sort()
    : [];
  if ((optionKeys.length !== 2 && optionKeys.length !== 3)
      || optionKeys[0] !== 'enrollment'
      || optionKeys[optionKeys.length - 1] !== 'proofReader'
      || (optionKeys.length === 3 && optionKeys[1] !== 'monotonicNow')) {
    throw new TypeError('Invalid proof admission configuration');
  }
  const { enrollment, proofReader } = options;
  const monotonicNow = options.monotonicNow ?? (() => performance.now());
  if (typeof enrollment?.startEnrollment !== 'function') throw new TypeError('Enrollment service is required');
  if (typeof proofReader?.loadProof !== 'function') throw new TypeError('Source proof reader is required');
  if (typeof monotonicNow !== 'function') throw new TypeError('Monotonic clock is required');

  async function admit(input) {
    if (!hasExactKeys(input, EXACT_INPUT_KEYS)) throw new TypeError('Invalid proof admission input');
    const reservation = captureReservation(input.reservation);
    const proofId = uuid(input.proofId, 'proof ID');
    const sourceAccountId = input.sourceAccountId;
    if (typeof sourceAccountId !== 'string' || !HEX24.test(sourceAccountId)) {
      throw new TypeError('Invalid source account ID');
    }
    text(input.idempotencyKey, 256, 'idempotency key');
    text(input.provenance, 256, 'provenance');

    const startedAt = monotonicNow();
    if (!Number.isFinite(startedAt)) throw new TypeError('Monotonic clock returned an invalid value');
    const observation = await proofReader.loadProof(Object.freeze({
      proofId,
      sourceAccountId,
      canonicalAccountId: reservation.canonicalAccountId,
      enrollmentOperationId: reservation.enrollmentOperationId,
    }));
    const checkedAt = monotonicNow();
    if (!Number.isFinite(checkedAt) || checkedAt < startedAt) {
      throw new TypeError('Monotonic clock moved backwards');
    }
    if (observation.sourceNowMs + (checkedAt - startedAt) >= observation.proof.expiresAtMs) {
      throw new ProofAdmissionExpiredError();
    }
    return enrollment.startEnrollment(Object.freeze({
      operationId: reservation.enrollmentOperationId,
      idempotencyKey: input.idempotencyKey,
      legacyIdentity: Object.freeze({
        issuer: reservation.sourceIssuer,
        subject: reservation.sourceSubject,
      }),
      provenance: input.provenance,
    }), Object.freeze({ observation, reservation, sourceAccountId, startedAt, monotonicNow }));
  }

  return Object.freeze({ admit });
}
