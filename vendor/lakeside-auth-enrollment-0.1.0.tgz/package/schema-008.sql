-- Immutable authorization and evidence for the final disabled-target activation.
CREATE TABLE lakeside_enrollment.activation_binding (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.enrollment(operation_id),
  account_id uuid NOT NULL UNIQUE REFERENCES lakeside_accounts.account(account_id),
  binding jsonb NOT NULL CHECK (jsonb_typeof(binding) = 'object'),
  bound_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE lakeside_enrollment.activation_receipt (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.activation_binding(operation_id),
  receipt_id uuid NOT NULL UNIQUE,
  evidence_fingerprint text NOT NULL CHECK (length(evidence_fingerprint) = 64),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TRIGGER activation_binding_immutable BEFORE UPDATE OR DELETE
ON lakeside_enrollment.activation_binding FOR EACH ROW
EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
CREATE TRIGGER activation_receipt_immutable BEFORE UPDATE OR DELETE
ON lakeside_enrollment.activation_receipt FOR EACH ROW
EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();
