import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { createCentralFenceAttestationReader, CentralFenceAttestationReadError } from './central-fence-attestation-reader.mjs';

const sourceIssuer = 'https://legacy.example.invalid';
const targetIssuer = 'https://accounts.example.invalid/realms/lakeside';
const targetRealmId = 'lakeside';
const binding = { canonicalAccountId: randomUUID(), enrollmentOperationId: randomUUID() };
const row = { account_id: binding.canonicalAccountId, operation_id: binding.enrollmentOperationId,
  lease_expires_ms: '1700000000000', fence_generation: '2', fence_authority: 'migration-worker',
  fence_token_hash: 'a'.repeat(64), fenced_at_ms: '1699999999000', source_account_id: '507f1f77bcf86cd799439011',
  target_issuer: targetIssuer, target_subject: randomUUID() };

function fixture(rows = [row], failAt = 0, controller) {
  const queries = [], releases = [];
  const client = { async query(q) {
    queries.push(q);
    if (queries.length === failAt) throw new Error('synthetic secret');
    if (q.text.startsWith('SELECT e.account_id')) { controller?.abort(); return { rows }; }
    return { rows: [] };
  }, release(value) { releases.push(value); } };
  const pool = { options: { connectionTimeoutMillis: 100 }, async connect() { return client; } };
  return { load: createCentralFenceAttestationReader(pool, { sourceIssuer, targetIssuer, targetRealmId }), queries, releases, pool };
}

test('returns a frozen digest-bound attestation from one read-only snapshot', async () => {
  const f = fixture();
  const result = await f.load(binding);
  const unsigned = { ...result }; delete unsigned.attestationDigest;
  const canonical = Object.fromEntries(Object.keys(unsigned).sort().map(key => [key, unsigned[key]]));
  assert.equal(result.attestationDigest, createHash('sha256').update(JSON.stringify(canonical)).digest('hex'));
  assert.deepEqual(unsigned, { version: 1, sourceIssuer, sourceAccountId: row.source_account_id,
    canonicalAccountId: binding.canonicalAccountId, enrollmentOperationId: binding.enrollmentOperationId,
    fenceGeneration: '2', fenceAuthority: row.fence_authority, fenceTokenHash: row.fence_token_hash,
    fencedAtMs: 1699999999000,
    leaseExpiresAtMs: 1700000000000, targetIssuer, targetSubject: row.target_subject });
  assert.ok(Object.isFrozen(result));
  assert.equal(f.queries[0].text, 'BEGIN READ ONLY ISOLATION LEVEL REPEATABLE READ');
  assert.equal(f.queries.at(-1).text, 'COMMIT');
  assert.deepEqual(f.queries[2].values, [binding.canonicalAccountId, binding.enrollmentOperationId,
    targetIssuer, targetRealmId, sourceIssuer]);
  assert.deepEqual(f.releases, [false]);
});

test('absence is not authority and expired lease timestamps remain evidence data', async () => {
  assert.equal(await fixture([]).load(binding), null);
  const result = await fixture([{ ...row, lease_expires_ms: '1' }]).load(binding);
  assert.equal(result.leaseExpiresAtMs, 1);
});

for (const [key, value] of Object.entries({ account_id: randomUUID(), operation_id: randomUUID(),
  lease_expires_ms: '0', fence_generation: '0', fence_authority: 'bad\n', fence_token_hash: 'bad', fenced_at_ms: '0',
  source_account_id: '', target_issuer: 'https://wrong.invalid', target_subject: '' })) {
  test(`rejects malformed or conflicting ${key}`, async () => {
    await assert.rejects(fixture([{ ...row, [key]: value }]).load(binding), CentralFenceAttestationReadError);
  });
}

test('rejects duplicate rows, cancellation, invalid input, and query failures', async () => {
  await assert.rejects(fixture([row, row]).load(binding), CentralFenceAttestationReadError);
  const aborted = new AbortController(); aborted.abort();
  const f = fixture(); await assert.rejects(f.load(binding, { signal: aborted.signal }), CentralFenceAttestationReadError);
  assert.equal(f.queries.length, 0);
  await assert.rejects(fixture().load({ ...binding, canonicalAccountId: 'bad' }), CentralFenceAttestationReadError);
  for (const index of [1, 2, 3, 4]) {
    const failed = fixture([row], index);
    await assert.rejects(failed.load(binding), error => error instanceof CentralFenceAttestationReadError && !error.message.includes('secret'));
    assert.deepEqual(failed.releases, [true]);
  }
});

test('captures identity before connect and discards evidence cancelled during query', async () => {
  const mutable = { ...binding }; const f = fixture(); const connect = f.pool.connect;
  f.pool.connect = async () => { mutable.canonicalAccountId = randomUUID(); return connect(); };
  assert.equal((await f.load(mutable)).canonicalAccountId, binding.canonicalAccountId);
  const controller = new AbortController(); const cancelled = fixture([row], 0, controller);
  await assert.rejects(cancelled.load(binding, { signal: controller.signal }), CentralFenceAttestationReadError);
  assert.deepEqual(cancelled.releases, [true]);
});

test('requires bounded pool, query budget, and exact trusted authorities', () => {
  const { pool } = fixture();
  for (const options of [{ sourceIssuer: 'http://legacy.invalid' }, { targetIssuer: `${targetIssuer}?x` },
    { targetRealmId: 'bad\n' }, { queryTimeoutMs: 99 }, { queryTimeoutMs: 5001 }]) {
    assert.throws(() => createCentralFenceAttestationReader(pool,
      { sourceIssuer, targetIssuer, targetRealmId, ...options }), TypeError);
  }
  assert.throws(() => createCentralFenceAttestationReader({ ...pool, options: {} },
    { sourceIssuer, targetIssuer, targetRealmId }), TypeError);
});

test('accepts the canonical legacy source namespace while target remains HTTPS', () => {
  const { pool } = fixture();
  const reader = createCentralFenceAttestationReader(pool, {
    sourceIssuer: 'urn:lakeside:legacy:ahd:production', targetIssuer, targetRealmId,
  });
  assert.equal(typeof reader, 'function');
  assert.throws(() => createCentralFenceAttestationReader(pool, {
    sourceIssuer, targetIssuer: 'urn:lakeside:accounts:production', targetRealmId,
  }), TypeError);
});
