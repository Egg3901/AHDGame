-- Immutable evidence that enrollment admission used one exact, authenticated
-- source ownership proof. This receipt is not proof consumption and does not
-- authorize the later irreversible source fence.
CREATE TABLE lakeside_enrollment.proof_admission (
  operation_id uuid PRIMARY KEY REFERENCES lakeside_enrollment.enrollment(operation_id),
  proof_id uuid NOT NULL UNIQUE,
  source_account_id text NOT NULL CHECK (source_account_id ~ '^[0-9a-f]{24}$'),
  snapshot_digest text NOT NULL CHECK (snapshot_digest ~ '^[0-9a-f]{64}$'),
  source_observed_at timestamptz NOT NULL,
  source_expires_at timestamptz NOT NULL,
  source_now_at_load timestamptz NOT NULL,
  admitted_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  CHECK (source_expires_at > source_observed_at),
  CHECK (source_now_at_load >= source_observed_at),
  CHECK (source_now_at_load < source_expires_at)
);

CREATE OR REPLACE FUNCTION lakeside_enrollment.reject_proof_admission_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'proof admission receipt is immutable';
END;
$$;

CREATE TRIGGER proof_admission_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.proof_admission
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_proof_admission_mutation();

REVOKE ALL ON FUNCTION lakeside_enrollment.reject_proof_admission_mutation() FROM PUBLIC;
