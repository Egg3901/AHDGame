-- Account-owned irreversible migration authority.
-- A row means this account has crossed the legacy-auth fence. It is never
-- updated or deleted by the package. The lease values bind the importer that
-- established the fence until completion or lease expiry.
ALTER TABLE lakeside_enrollment.request
  DROP CONSTRAINT IF EXISTS request_phase_check;
ALTER TABLE lakeside_enrollment.request
  ADD CONSTRAINT request_phase_check
  CHECK (phase IN ('start', 'claim', 'fence', 'complete'));

CREATE TABLE lakeside_enrollment.account_fence (
  account_id uuid PRIMARY KEY REFERENCES lakeside_accounts.account(account_id),
  operation_id uuid NOT NULL UNIQUE REFERENCES lakeside_enrollment.enrollment(operation_id),
  fence_generation bigint NOT NULL CHECK (fence_generation > 0),
  fence_authority text NOT NULL CHECK (length(fence_authority) BETWEEN 1 AND 128),
  fence_token_hash text NOT NULL CHECK (length(fence_token_hash) = 64),
  fenced_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX enrollment_account_fence_operation_idx
  ON lakeside_enrollment.account_fence(operation_id);

CREATE OR REPLACE FUNCTION lakeside_enrollment.reject_account_fence_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'account migration fence is immutable';
END;
$$;

CREATE TRIGGER account_fence_immutable
BEFORE UPDATE OR DELETE ON lakeside_enrollment.account_fence
FOR EACH ROW EXECUTE FUNCTION lakeside_enrollment.reject_account_fence_mutation();

-- Migration 1 could already contain completed operations. Make those
-- irreversible before the new fence-aware runtime is allowed to start.
INSERT INTO lakeside_enrollment.account_fence(
  account_id, operation_id, fence_generation, fence_authority, fence_token_hash
)
SELECT account_id, operation_id, GREATEST(lease_generation, 1),
       'migration-002-backfill', repeat('0', 64)
  FROM lakeside_enrollment.enrollment
 WHERE state = 'unified'
ON CONFLICT DO NOTHING;
