-- A committed credential import does not prove that the disabled target was
-- enabled. Hold the operation in a fail-closed state until a separate,
-- authenticated activation receipt is reconciled.
ALTER TABLE lakeside_enrollment.enrollment
  DROP CONSTRAINT enrollment_state_check;

ALTER TABLE lakeside_enrollment.enrollment
  ADD CONSTRAINT enrollment_state_check
  CHECK (state IN ('eligible', 'enrolling', 'credentialed', 'unified'));
