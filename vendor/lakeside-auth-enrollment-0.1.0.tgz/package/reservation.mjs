import { randomUUID } from 'node:crypto';

export class SourceIssuerNotAllowedError extends Error {
  constructor() { super('Source issuer is not in the exact reservation allowlist'); this.name = 'SourceIssuerNotAllowedError'; }
}
export class SourceIdentityNotMappedError extends Error {
  constructor() { super('Source identity has no authoritative external identity mapping'); this.name = 'SourceIdentityNotMappedError'; }
}
export class ReservationSuspendedError extends Error {
  constructor() { super('Authoritative account is suspended or on recovery hold'); this.name = 'ReservationSuspendedError'; }
}
export class ReservationConflictError extends Error {
  constructor(message = 'Reservation conflicts with an existing reservation or enrollment claim') { super(message); this.name = 'ReservationConflictError'; }
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
const CONTROL_RE = /[\u0000-\u001f\u007f]/u;

// Text is validated before UTF-8 encoding; UUIDs also require exact length.
function boundedText(value, max, label) {
  if (typeof value !== 'string' || !value.isWellFormed()) throw new TypeError(`Invalid ${label}`);
  if (value.length === 0 || value.length > max) throw new TypeError(`Invalid ${label}`);
  if (value !== value.trim()) throw new TypeError(`Invalid ${label}`);
  if (CONTROL_RE.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}

function sourceIdentity(value) {
  if (value == null || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Invalid source identity');
  const keys = Object.keys(value).sort();
  if (keys.length !== 2 || keys[0] !== 'issuer' || keys[1] !== 'subject') throw new TypeError('Invalid source identity');
  return {
    issuer: boundedText(value.issuer, 512, 'source issuer'),
    subject: boundedText(value.subject, 512, 'source subject'),
  };
}

function operationUuid(value) {
  if (typeof value !== 'string' || value.length !== 36 || !UUID_RE.test(value) || CONTROL_RE.test(value)) throw new TypeError('Invalid operation ID');
  return value.toLowerCase();
}

function configuredIssuers(values) {
  if (!Array.isArray(values) || values.length === 0) throw new TypeError('A non-empty exact source issuer allowlist is required');
  const allowed = new Set();
  for (const value of values) {
    const issuer = boundedText(value, 512, 'source issuer');
    if (allowed.has(issuer)) throw new TypeError('Source issuer allowlist contains a duplicate');
    allowed.add(issuer);
  }
  return allowed;
}

async function transaction(pool, work) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL lock_timeout = '5s'");
    await client.query("SET LOCAL statement_timeout = '10s'");
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally {
    client.release();
  }
}

function frozenReservation(row) {
  return Object.freeze({
    version: 1,
    sourceIssuer: row.source_issuer,
    sourceSubject: row.source_subject,
    canonicalAccountId: operationUuid(row.account_id),
    enrollmentOperationId: operationUuid(row.operation_id),
  });
}

/**
 * Stable enrollment identifiers before admission. Trusted backend only.
 *
 * Reserves stable canonical account and enrollment operation IDs BEFORE
 * startEnrollment runs, after the source backend has verified fresh
 * ownership elsewhere. Reserving IDs starts, enrolls, fences, claims,
 * routes, admits, provisions, enables, authenticates and proves nothing.
 * This table is metadata only, not admission. The caller must have verified
 * fresh source ownership through its own trusted path before calling; that
 * authorization is explicitly not implemented by this metadata API.
 *
 * The browser can never choose the account or operation: reserve takes no
 * caller account or operation ID, and unknown input keys are rejected.
 */
export function createEnrollmentReservationStore(pool, options = {}) {
  if (!pool || typeof pool.connect !== 'function' || typeof pool.query !== 'function') throw new TypeError('A pg pool is required');
  if (!Number.isSafeInteger(pool.options?.connectionTimeoutMillis)
      || pool.options.connectionTimeoutMillis < 1 || pool.options.connectionTimeoutMillis > 5000
      || !Number.isSafeInteger(pool.options?.query_timeout)
      || pool.options.query_timeout < 100 || pool.options.query_timeout > 15000) {
    throw new TypeError('Reservation pool must have bounded connection and query timeouts');
  }
  const allowed = configuredIssuers(options.allowedSourceIssuers);

  async function reserve(input = {}) {
    if (input == null || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('Invalid reservation input');
    const keys = Object.keys(input).sort();
    if (keys.length !== 2 || keys[0] !== 'provenance' || keys[1] !== 'sourceIdentity') throw new TypeError('Invalid reservation input');
    const item = sourceIdentity(input.sourceIdentity);
    boundedText(input.provenance, 256, 'provenance');
    if (!allowed.has(item.issuer)) throw new SourceIssuerNotAllowedError();
    // Minted once outside the transaction and used only for a new record.
    // Concurrent retries converge on the stored row instead of this value.
    const minted = randomUUID();
    return transaction(pool, async client => {
      const { rows: mapped } = await client.query(
        `SELECT account_id::text AS account_id
           FROM lakeside_accounts.external_identity
          WHERE issuer=$1 AND subject=$2`,
        [item.issuer, item.subject],
      );
      if (!mapped[0]) throw new SourceIdentityNotMappedError();
      // Canonical account lock first, then recheck the immutable mapping.
      // Same lock order as the enrollment paths: account before anything else.
      const { rows: accounts } = await client.query(
        `SELECT account_id::text AS account_id, status, recovery_hold
           FROM lakeside_accounts.account
          WHERE account_id=$1
          FOR UPDATE`,
        [mapped[0].account_id],
      );
      if (!accounts[0]) throw new SourceIdentityNotMappedError();
      if (accounts[0].status !== 'active' || accounts[0].recovery_hold !== false) throw new ReservationSuspendedError();
      const { rows: verified } = await client.query(
        `SELECT account_id::text AS account_id
           FROM lakeside_accounts.external_identity
          WHERE issuer=$1 AND subject=$2 AND account_id=$3`,
        [item.issuer, item.subject, accounts[0].account_id],
      );
      if (!verified[0]) throw new SourceIdentityNotMappedError();
      const accountId = accounts[0].account_id;

      const { rows: existing } = await client.query(
        `SELECT account_id::text AS account_id, source_issuer, source_subject, operation_id
           FROM lakeside_enrollment.enrollment_reservation
          WHERE source_issuer=$1 AND source_subject=$2`,
        [item.issuer, item.subject],
      );
      if (existing[0]) {
        if (existing[0].account_id !== accountId) throw new ReservationConflictError();
        await assertEnrollmentCompatible(client, existing[0]);
        return frozenReservation(existing[0]);
      }

      // A preexisting enrollment without a reservation is never adopted or
      // guessed. Reject rather than binding an arbitrary historical operation.
      const { rows: enrolled } = await client.query(
        'SELECT operation_id FROM lakeside_enrollment.enrollment WHERE account_id=$1',
        [accountId],
      );
      if (enrolled[0]) throw new ReservationConflictError('Account already has an enrollment operation without a reservation');

      // Never catch a unique violation inside this transaction. Concurrent
      // same-source inserts converge on one row; a lost cross-source account
      // race reads back the winner and conflicts below.
      await client.query(
        `INSERT INTO lakeside_enrollment.enrollment_reservation(account_id, source_issuer, source_subject, operation_id)
         VALUES ($1, $2, $3, $4)
         ON CONFLICT DO NOTHING`,
        [accountId, item.issuer, item.subject, minted],
      );
      const { rows: stored } = await client.query(
        `SELECT account_id::text AS account_id, source_issuer, source_subject, operation_id
           FROM lakeside_enrollment.enrollment_reservation
          WHERE source_issuer=$1 AND source_subject=$2`,
        [item.issuer, item.subject],
      );
      if (!stored[0] || stored[0].account_id !== accountId) {
        throw new ReservationConflictError('Canonical account already has a reservation for a different source identity');
      }
      return frozenReservation(stored[0]);
    });
  }

  async function assertEnrollmentCompatible(client, reservation) {
    const { rows } = await client.query(
      `SELECT operation_id, account_id::text AS account_id, issuer, subject
         FROM lakeside_enrollment.enrollment
        WHERE account_id=$1`,
      [reservation.account_id],
    );
    if (!rows[0]) return;
    if (rows[0].operation_id !== reservation.operation_id
      || rows[0].account_id !== reservation.account_id
      || rows[0].issuer !== reservation.source_issuer
      || rows[0].subject !== reservation.source_subject) {
      throw new ReservationConflictError('Reservation does not match the existing enrollment operation');
    }
    // Exact replay is allowed in every enrollment state, including unified:
    // the reservation changes nothing, and redrive requires the same account
    // and operation IDs. A conflicting operation always rejects above.
  }

  // Exact-source metadata read. Enforces the same allowlist, mapping and
  // hold checks as reserve, so it cannot be used to bypass a hold.
  async function loadReservation(input = {}) {
    if (input == null || typeof input !== 'object' || Array.isArray(input)) throw new TypeError('Invalid reservation lookup');
    const keys = Object.keys(input).sort();
    if (keys.length !== 2 || keys[0] !== 'issuer' || keys[1] !== 'subject') throw new TypeError('Invalid reservation lookup');
    const item = sourceIdentity(input);
    if (!allowed.has(item.issuer)) throw new SourceIssuerNotAllowedError();
    return transaction(pool, async client => {
      const { rows: mapped } = await client.query(
        `SELECT account_id::text AS account_id
           FROM lakeside_accounts.external_identity
          WHERE issuer=$1 AND subject=$2`,
        [item.issuer, item.subject],
      );
      if (!mapped[0]) throw new SourceIdentityNotMappedError();
      const { rows: accounts } = await client.query(
        `SELECT account_id::text AS account_id, status, recovery_hold
           FROM lakeside_accounts.account
          WHERE account_id=$1 FOR UPDATE`,
        [mapped[0].account_id],
      );
      if (!accounts[0]) throw new SourceIdentityNotMappedError();
      if (accounts[0].status !== 'active' || accounts[0].recovery_hold !== false) throw new ReservationSuspendedError();
      const { rows: currentMapping } = await client.query(
        'SELECT account_id::text FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2 AND account_id=$3',
        [item.issuer, item.subject, accounts[0].account_id],
      );
      if (!currentMapping[0]) throw new SourceIdentityNotMappedError();
      const { rows: stored } = await client.query(
        `SELECT account_id::text AS account_id, source_issuer, source_subject, operation_id
           FROM lakeside_enrollment.enrollment_reservation
          WHERE source_issuer=$1 AND source_subject=$2`,
        [item.issuer, item.subject],
      );
      if (!stored[0]) return null;
      if (stored[0].account_id !== accounts[0].account_id) throw new ReservationConflictError();
      await assertEnrollmentCompatible(client, stored[0]);
      return frozenReservation(stored[0]);
    });
  }

  return Object.freeze({ reserve, loadReservation });
}
