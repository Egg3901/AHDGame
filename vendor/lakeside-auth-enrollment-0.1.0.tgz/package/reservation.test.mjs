import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import pg from 'pg';
import {
  createCohortEnrollment,
  createEnrollmentReservationStore,
  createIdempotencyKey,
  createOperationId,
  migrate,
  ReservationConflictError,
  ReservationSuspendedError,
  SourceIdentityNotMappedError,
  SourceIssuerNotAllowedError,
} from './index.mjs';
import { createAccountRegistry, migrate as migrateRegistry } from '../account-registry/index.mjs';

if (process.env.LAKESIDE_ISOLATED_ENROLLMENT_TEST !== 'true' || process.env.PGHOST !== 'database') {
  throw new Error('Run through the isolated compat Compose enrollment-tests service with PGHOST=database');
}

const T = { timeout: 120_000 };
const database = `reservation_test_${randomUUID().replaceAll('-', '')}`;
const admin = new pg.Pool({ max: 1, connectionTimeoutMillis: 5000, query_timeout: 10000 });
let pool;
let registry;
let reservations;
const issuer = 'urn:lakeside:source:reservation-test';
const subject = suffix => `reservation-source-${suffix}`;
const identity = value => ({ issuer, subject: value });
const input = value => ({ sourceIdentity: identity(value), provenance: `test:${value}` });

test.before(async () => {
  try {
    await admin.query(`CREATE DATABASE ${database}`);
    pool = new pg.Pool({ database, max: 8, connectionTimeoutMillis: 5000, query_timeout: 10000 });
    await migrateRegistry(pool);
    await migrate(pool);
    registry = createAccountRegistry(pool, { allowedIssuers: [issuer], allowedApplications: [] });
    reservations = createEnrollmentReservationStore(pool, { allowedSourceIssuers: [issuer] });
  } finally {
    if (!pool) await admin.end();
  }
}, T);

test.after(async () => {
  try {
    await pool?.end();
    await admin.query(`DROP DATABASE IF EXISTS ${database}`);
  } finally {
    await admin.end();
  }
}, T);

function cohortFor(...subjects) {
  return createCohortEnrollment(pool, {
    allowUnprovedAdmissions: true,
    allowedLegacyIdentities: subjects.map(value => identity(value)),
    leaseSeconds: 30,
  });
}

async function resume(cohort) {
  await cohort.resumeAdmissions({ operationId: createOperationId(), idempotencyKey: createIdempotencyKey(), provenance: 'test:reserve-resume' });
}

test('requires bounded connection and query timeouts', () => {
  for (const overrides of [{ connectionTimeoutMillis: 0 }, { connectionTimeoutMillis: 5001 }, { query_timeout: 0 }, { query_timeout: 15001 }]) {
    const fake = { connect() {}, query() {}, options: { connectionTimeoutMillis: 5000, query_timeout: 10000, ...overrides } };
    assert.throws(() => createEnrollmentReservationStore(fake, { allowedSourceIssuers: [issuer] }), TypeError);
  }
});

test('rejects malformed Unicode before any identity lookup', async () => {
  for (const value of ['source-\ud800', 'source-\udfff']) {
    await assert.rejects(reservations.reserve({ sourceIdentity: identity(value), provenance: 'test:unicode' }), TypeError);
    await assert.rejects(reservations.loadReservation(identity(value)), TypeError);
    assert.throws(() => createEnrollmentReservationStore(pool, { allowedSourceIssuers: [value] }), TypeError);
  }
});

test('first reserve mints a frozen version-1 primitive with no login status or permit', async () => {
  const owner = await registry.resolveOrCreateVerifiedIdentity(identity(subject('first')), 'test:reserve');
  const reserved = await reservations.reserve(input(subject('first')));
  assert.equal(Object.isFrozen(reserved), true);
  assert.deepEqual(Object.keys(reserved).sort(), ['canonicalAccountId', 'enrollmentOperationId', 'sourceIssuer', 'sourceSubject', 'version']);
  assert.equal(reserved.version, 1);
  assert.equal(reserved.sourceIssuer, issuer);
  assert.equal(reserved.sourceSubject, subject('first'));
  assert.equal(reserved.canonicalAccountId, owner.account_id);
  assert.match(reserved.enrollmentOperationId, /^[0-9a-f-]{36}$/u);
}, T);

test('exact replay returns the same IDs without a new row', async () => {
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('replay')), 'test:reserve');
  const first = await reservations.reserve(input(subject('replay')));
  const second = await reservations.reserve(input(subject('replay')));
  assert.deepEqual(second, first);
  const { rows } = await pool.query('SELECT count(*) AS count FROM lakeside_enrollment.enrollment_reservation WHERE source_issuer=$1 AND source_subject=$2', [issuer, subject('replay')]);
  assert.equal(rows[0].count, '1');
}, T);

test('parallel reserves for one identity and account converge on one row', async () => {
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('race')), 'test:reserve');
  const results = await Promise.all(Array.from({ length: 10 }, () => reservations.reserve(input(subject('race')))));
  for (const result of results) assert.deepEqual(result, results[0]);
  const { rows } = await pool.query('SELECT count(*) AS count FROM lakeside_enrollment.enrollment_reservation WHERE source_issuer=$1 AND source_subject=$2', [issuer, subject('race')]);
  assert.equal(rows[0].count, '1');
}, T);

test('a different source tuple for the same canonical account conflicts', async () => {
  const owner = await registry.resolveOrCreateVerifiedIdentity(identity(subject('alias-a')), 'test:reserve');
  const now = Math.floor(Date.now() / 1000);
  await registry.linkVerifiedIdentity({
    primary: { accountId: owner.account_id, securityVersion: owner.security_version, issuer, subject: subject('alias-a'), authenticatedAt: now },
    secondary: { issuer, subject: subject('alias-b'), authenticatedAt: now },
  }, 'test:reserve-alias');
  const first = await reservations.reserve(input(subject('alias-a')));
  assert.equal(first.canonicalAccountId, owner.account_id);
  await assert.rejects(reservations.reserve(input(subject('alias-b'))), ReservationConflictError);
}, T);

test('unmapped subject and disallowed issuer are rejected', async () => {
  await assert.rejects(reservations.reserve(input(subject('unmapped'))), SourceIdentityNotMappedError);
  const foreign = createEnrollmentReservationStore(pool, { allowedSourceIssuers: ['urn:lakeside:source:foreign'] });
  await assert.rejects(foreign.reserve({ sourceIdentity: identity(subject('first')), provenance: 'test:reserve' }), SourceIssuerNotAllowedError);
  await assert.rejects(foreign.loadReservation(identity(subject('first'))), SourceIssuerNotAllowedError);
}, T);

test('recovery hold and suspension always reject, including replays and reads', async () => {
  const held = await registry.resolveOrCreateVerifiedIdentity(identity(subject('held')), 'test:reserve');
  const before = await reservations.reserve(input(subject('held')));
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [held.account_id]);
  await assert.rejects(reservations.reserve(input(subject('held'))), ReservationSuspendedError);
  await assert.rejects(reservations.loadReservation(identity(subject('held'))), ReservationSuspendedError);
  await pool.query("UPDATE lakeside_accounts.account SET recovery_hold=false, status='suspended' WHERE account_id=$1", [held.account_id]);
  await assert.rejects(reservations.reserve(input(subject('held'))), ReservationSuspendedError);
  await pool.query("UPDATE lakeside_accounts.account SET status='active' WHERE account_id=$1", [held.account_id]);
  assert.deepEqual(await reservations.reserve(input(subject('held'))), before);
  assert.deepEqual(await reservations.loadReservation(identity(subject('held'))), before);
}, T);

test('reservation is not admission: route stays legacy and control is unchanged', async () => {
  const cohort = cohortFor(subject('not-admission'));
  assert.equal((await cohort.getRolloutState()).admissionsPaused, true);
  const controlBefore = await pool.query('SELECT admissions_paused, revision::text AS revision FROM lakeside_enrollment.rollout_control WHERE control_id=true');
  const owner = await registry.resolveOrCreateVerifiedIdentity(identity(subject('not-admission')), 'test:reserve');
  const reserved = await reservations.reserve(input(subject('not-admission')));
  assert.deepEqual(await cohort.getLoginRoute(identity(subject('not-admission'))), {
    issuer,
    subject: subject('not-admission'),
    accountId: owner.account_id,
    operationId: null,
    enrollmentState: null,
    status: 'legacy',
    blockedReason: null,
  });
  assert.deepEqual(await pool.query('SELECT admissions_paused, revision::text AS revision FROM lakeside_enrollment.rollout_control WHERE control_id=true'), controlBefore);
  assert.equal((await pool.query('SELECT count(*) AS count FROM lakeside_enrollment.enrollment WHERE account_id=$1', [owner.account_id])).rows[0].count, '0');
  await resume(cohort);
  const started = await cohort.startEnrollment({
    operationId: reserved.enrollmentOperationId,
    idempotencyKey: createIdempotencyKey(),
    legacyIdentity: identity(subject('not-admission')),
    provenance: 'test:reserve-start',
  });
  assert.equal(started.status, 'eligible');
  assert.equal(started.accountId, reserved.canonicalAccountId);
}, T);

test('caller-chosen IDs and unknown keys are rejected with no String coercion', async () => {
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('strict')), 'test:reserve');
  const good = input(subject('strict'));
  await assert.rejects(reservations.reserve({ ...good, accountId: createOperationId() }), TypeError);
  await assert.rejects(reservations.reserve({ ...good, operationId: createOperationId() }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { ...good.sourceIdentity, email: 'ignored@example.invalid' }, provenance: good.provenance }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: good.sourceIdentity }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { issuer: 42, subject: subject('strict') }, provenance: good.provenance }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { issuer, subject: '' }, provenance: good.provenance }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { issuer, subject: ` ${subject('strict')}` }, provenance: good.provenance }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { issuer, subject: `${subject('strict')}\n` }, provenance: good.provenance }), TypeError);
  await assert.rejects(reservations.reserve({ sourceIdentity: { issuer, subject: subject('strict') }, provenance: '  ' }), TypeError);
  await assert.rejects(reservations.loadReservation({ ...identity(subject('strict')), extra: true }), TypeError);
  assert.equal((await reservations.reserve(good)).sourceSubject, subject('strict'));
}, T);

test('reservation rows are immutable with exact unique constraints and no public execute', async () => {
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('immutable')), 'test:reserve');
  const reserved = await reservations.reserve(input(subject('immutable')));
  await assert.rejects(pool.query('UPDATE lakeside_enrollment.enrollment_reservation SET source_subject=$1 WHERE operation_id=$2', ['tampered', reserved.enrollmentOperationId]), /enrollment reservation is immutable/iu);
  await assert.rejects(pool.query('DELETE FROM lakeside_enrollment.enrollment_reservation WHERE operation_id=$1', [reserved.enrollmentOperationId]), /enrollment reservation is immutable/iu);
  const constraints = await pool.query(
    `SELECT constraint_name FROM information_schema.table_constraints
      WHERE table_schema='lakeside_enrollment' AND table_name='enrollment_reservation' AND constraint_type='UNIQUE'`,
  );
  assert.equal(constraints.rows.length, 2);
  const { rows: [grant] } = await pool.query(
    "SELECT has_function_privilege('public', 'lakeside_enrollment.reject_enrollment_reservation_mutation()', 'execute') AS allowed",
  );
  assert.equal(grant.allowed, false);
}, T);

test('a preexisting enrollment without a reservation rejects instead of adopting it', async () => {
  const cohort = cohortFor(subject('preexisting'));
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('preexisting')), 'test:reserve');
  await resume(cohort);
  await cohort.startEnrollment({
    operationId: createOperationId(),
    idempotencyKey: createIdempotencyKey(),
    legacyIdentity: identity(subject('preexisting')),
    provenance: 'test:reserve-historical',
  });
  await assert.rejects(reservations.reserve(input(subject('preexisting'))), ReservationConflictError);
}, T);

test('unambiguous replay matches the existing operation through unified, conflicting operations reject', async () => {
  const cohort = cohortFor(subject('redrive'), subject('diverged'));
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('redrive')), 'test:reserve');
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('diverged')), 'test:reserve');
  await resume(cohort);
  const reserved = await reservations.reserve(input(subject('redrive')));
  const started = await cohort.startEnrollment({
    operationId: reserved.enrollmentOperationId,
    idempotencyKey: createIdempotencyKey(),
    legacyIdentity: identity(subject('redrive')),
    provenance: 'test:reserve-redrive',
  });
  assert.equal(started.operationId, reserved.enrollmentOperationId);
  assert.deepEqual(await reservations.reserve(input(subject('redrive'))), reserved);
  const claim = await cohort.claimEnrollment({ operationId: reserved.enrollmentOperationId, idempotencyKey: createIdempotencyKey(), authorityId: 'redrive-authority', provenance: 'test:reserve-claim' });
  await cohort.fenceEnrollment({
    operationId: reserved.enrollmentOperationId,
    idempotencyKey: createIdempotencyKey(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:reserve-fence',
  });
  const unified = await cohort.completeEnrollment({
    operationId: reserved.enrollmentOperationId,
    idempotencyKey: createIdempotencyKey(),
    authorityId: claim.lease.authorityId,
    leaseToken: claim.lease.leaseToken,
    leaseGeneration: claim.lease.leaseGeneration,
    provenance: 'test:reserve-complete',
  });
  assert.equal(unified.status, 'unified');
  assert.deepEqual(await reservations.reserve(input(subject('redrive'))), reserved);

  const diverged = await reservations.reserve(input(subject('diverged')));
  await cohort.startEnrollment({
    operationId: createOperationId(),
    idempotencyKey: createIdempotencyKey(),
    legacyIdentity: identity(subject('diverged')),
    provenance: 'test:reserve-diverged',
  });
  await assert.rejects(reservations.reserve(input(subject('diverged'))), ReservationConflictError);
  await assert.rejects(reservations.loadReservation(identity(subject('diverged'))), ReservationConflictError);
  assert.equal(diverged.sourceSubject, subject('diverged'));
}, T);

test('load returns the frozen primitive and null when missing', async () => {
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('loaded')), 'test:reserve');
  await registry.resolveOrCreateVerifiedIdentity(identity(subject('absent')), 'test:reserve');
  assert.equal(await reservations.loadReservation(identity(subject('absent'))), null);
  const reserved = await reservations.reserve(input(subject('loaded')));
  assert.deepEqual(await reservations.loadReservation(identity(subject('loaded'))), reserved);
  await assert.rejects(reservations.loadReservation(identity(subject('unmapped-load'))), SourceIdentityNotMappedError);
}, T);
