import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash, randomUUID } from 'node:crypto';
import { createCredentialImportDispatcher, CredentialImportDispatchError } from './import-dispatch.mjs';
import { createCredentialImportReceiptReader, CredentialImportReceiptReadError } from './import-receipt-reader.mjs';

const issuer = 'https://issuer.example.invalid/realms/accounts';
const realmId = 'realm-id';
const credentialDigest = '$2b$12$abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXY12';
const binding = Object.freeze({
  version: 2, attemptId: randomUUID(), attemptGeneration: '1', accountId: randomUUID(),
  operationId: randomUUID(), issuer, realmId, userId: randomUUID(),
  legacyIssuer: 'urn:lakeside:legacy:ahd:production', legacySubject: '0123456789abcdef01234567',
  digestFingerprint: createHash('sha256').update(credentialDigest).digest('hex'),
  credentialAlgorithm: 'lakeside-legacy-bcrypt-v1', hashIterations: 12,
  fenceGeneration: '1', fenceTokenHash: 'a'.repeat(64), fenceExpiresAtMs: 1780000000000,
  attemptLeaseTokenHash: 'b'.repeat(64), attemptExpiresAtMs: 1780000000000,
});

test('dispatch sends the exact credential and immutable binding once', async () => {
  const calls = [];
  const receiptId = randomUUID();
  const dispatcher = createCredentialImportDispatcher({
    endpoint: `${issuer}/lakeside-provision-transport`, issuer, realmId,
    obtainAccessToken: async () => 'token.value',
    fetchImpl: async (url, init) => {
      calls.push({ url, init, body: JSON.parse(init.body) });
      return new Response(JSON.stringify({ state: 'COMMITTED', receiptId }), {
        status: 200, headers: { 'content-type': 'application/json' },
      });
    },
  });
  assert.deepEqual(await dispatcher.importCredential(binding, credentialDigest), { state: 'COMMITTED', receiptId });
  assert.equal(calls.length, 1);
  assert.equal(calls[0].body.credentialDigest, credentialDigest);
  assert.equal(calls[0].body.realmId, undefined);
  assert.equal(calls[0].body.digestFingerprint, undefined);
});

test('dispatch rejects a digest not bound by the coordinator before token or fetch', async () => {
  let tokens = 0;
  const dispatcher = createCredentialImportDispatcher({
    endpoint: `${issuer}/lakeside-provision-transport`, issuer, realmId,
    obtainAccessToken: async () => { tokens += 1; return 'token.value'; },
    fetchImpl: async () => { throw new Error('must not fetch'); },
  });
  await assert.rejects(dispatcher.importCredential(binding, credentialDigest.replace('12', '13')),
    error => error instanceof CredentialImportDispatchError && !error.requestMayHaveReachedIssuer);
  assert.equal(tokens, 0);
});

function receiptFixture(overrides = {}) {
  const row = {
    account_id: binding.accountId, operation_id: binding.operationId, realm_id: realmId,
    user_id: binding.userId, legacy_issuer: binding.legacyIssuer, legacy_subject: binding.legacySubject,
    digest_fingerprint: binding.digestFingerprint, credential_algorithm: binding.credentialAlgorithm,
    hash_iterations: 12, fence_generation: '1', fence_token_hash: binding.fenceTokenHash,
    fence_expires_ms: String(binding.fenceExpiresAtMs), attempt_id: binding.attemptId,
    attempt_generation: '1', lease_token_hash: binding.attemptLeaseTokenHash,
    lease_expires_ms: String(binding.attemptExpiresAtMs), receipt_id: randomUUID(), state: 'COMMITTED',
    ...overrides,
  };
  const queries = [];
  const releases = [];
  const client = { query: async query => {
    queries.push(query);
    return query.text.startsWith('SELECT o.') ? { rows: [row] } : { rows: [] };
  }, release: broken => releases.push(broken) };
  const pool = { options: { connectionTimeoutMillis: 100 }, connect: async () => client };
  return { reader: createCredentialImportReceiptReader(pool, { issuer, realmId }), row, queries, releases };
}

test('receipt reader returns only exact committed issuer ledger evidence', async () => {
  const fixture = receiptFixture();
  const receipt = await fixture.reader(binding);
  assert.equal(receipt.state, 'COMMITTED');
  assert.equal(receipt.receiptId, fixture.row.receipt_id);
  assert.equal(fixture.queries[0].text, 'BEGIN READ ONLY');
  assert.deepEqual(fixture.releases, [false]);
});

test('receipt reader rejects binding drift and MUTATING is unavailable', async () => {
  const drift = receiptFixture({ legacy_subject: 'fedcba987654321001234567' });
  await assert.rejects(drift.reader(binding), CredentialImportReceiptReadError);
  assert.deepEqual(drift.releases, [true]);
  assert.equal(await receiptFixture({ state: 'MUTATING' }).reader(binding), null);
});
