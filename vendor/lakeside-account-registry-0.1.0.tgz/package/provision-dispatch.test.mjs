import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createProvisionDispatcher, ProvisionDispatchError } from './provision-dispatch.mjs';

const issuer = 'https://issuer.example.invalid/realms/lakeside';
const realmId = 'lakeside-fixture';
const token = 'opaque-fixture-token';
const binding = Object.freeze({
  version: 1,
  accountId: '00000000-0000-4000-8000-000000000001',
  operationId: '00000000-0000-4000-8000-000000000002',
  issuer,
  realmId,
  username: 'lakeside:00000000-0000-4000-8000-000000000001',
  attemptId: '00000000-0000-4000-8000-000000000003',
  attemptGeneration: 7,
  leaseTokenHash: 'a'.repeat(64),
  leaseExpiresAtMs: 4102444800000,
});
function response(value, { status = 200, contentType = 'application/json' } = {}) {
  const body = JSON.stringify(value);
  return new Response(body, { status, headers: { 'content-type': contentType } });
}
function make(overrides = {}) {
  return createProvisionDispatcher({
    endpoint: 'https://keycloak.example.invalid/private/account-provision', issuer, realmId,
    obtainAccessToken: async () => token,
    fetchImpl: async () => response({ state: 'COMMITTED', receiptId: randomUUID(), userId: randomUUID() }),
    timeoutMs: 200,
    ...overrides,
  });
}

test('sends exact provision wire body and returns frozen candidate', async () => {
  let seen;
  const receiptId = randomUUID(); const userId = randomUUID();
  const dispatcher = make({
    fetchImpl: async (request) => { seen = request; return response({ state: 'COMMITTED', receiptId, userId }); },
  });
  const result = await dispatcher.provision(binding);
  assert.deepEqual(result, { state: 'COMMITTED', receiptId, userId });
  assert.ok(Object.isFrozen(result));
  assert.equal(seen.url, 'https://keycloak.example.invalid/private/account-provision/provision');
  assert.equal(seen.method, 'POST');
  assert.equal(seen.headers.get('authorization'), `Bearer ${token}`);
  const wireText = await seen.clone().text();
  assert.deepEqual(Object.keys(JSON.parse(wireText)), [
    'accountId', 'operationId', 'attemptId', 'attemptGeneration', 'attemptLeaseTokenHash', 'attemptExpiresAtMs',
  ]);
  const wire = JSON.parse(wireText);
  assert.equal(wire.attemptGeneration, '7');
  assert.equal(wire.attemptExpiresAtMs, binding.leaseExpiresAtMs);
  assert.ok(!('issuer' in wire) && !('realmId' in wire) && !('username' in wire) && !('version' in wire));
});

test('uses /abort and accepts terminal abort candidate without treating it as durable evidence', async () => {
  let url;
  const receiptId = randomUUID(); const userId = randomUUID();
  const dispatcher = make({ fetchImpl: async request => { url = request.url; return response({ state: 'ABORTED', receiptId, userId }); } });
  const result = await dispatcher.abort(binding);
  assert.equal(url, 'https://keycloak.example.invalid/private/account-provision/abort');
  assert.deepEqual(result, { state: 'ABORTED', receiptId, userId });
});

test('validates trusted binding before obtaining an access token', async () => {
  let calls = 0;
  const dispatcher = make({ obtainAccessToken: async () => { calls += 1; return token; } });
  for (const change of [
    { issuer: 'https://other.example.invalid/realms/lakeside' },
    { realmId: 'other-realm' },
    { username: 'lakeside:00000000-0000-4000-8000-000000000099' },
    { version: 2 },
    { attemptGeneration: '7' },
    { leaseTokenHash: 'not-a-hash' },
  ]) await assert.rejects(dispatcher.provision({ ...binding, ...change }));
  assert.equal(calls, 0);
});

test('rejects insecure, credentialed, query, fragment, and double-suffixed endpoints', () => {
  for (const endpoint of [
    'http://keycloak.example.invalid/private',
    'https://user:pass@keycloak.example.invalid/private',
    'https://keycloak.example.invalid/private?',
    'https://keycloak.example.invalid/private#fragment',
    'https://keycloak.example.invalid/private/provision',
  ]) assert.throws(() => make({ endpoint }), TypeError);
  assert.throws(() => make({ issuer: 'http://issuer.example.invalid/realms/lakeside' }), TypeError);
});

test('rejects malformed candidate keys, states, UUIDs, and content types as ambiguous', async () => {
  const cases = [
    { state: 'PROCEED', receiptId: randomUUID(), userId: randomUUID() },
    { state: 'COMMITTED', receiptId: 'bad', userId: randomUUID() },
    { state: 'COMMITTED', receiptId: randomUUID(), userId: randomUUID(), extra: true },
  ];
  for (const value of cases) {
    const dispatcher = make({ fetchImpl: async () => response(value) });
    await assert.rejects(dispatcher.provision(binding), error => error instanceof ProvisionDispatchError && error.requestMayHaveReachedIssuer && error.code === 'response_invalid');
  }
  await assert.rejects(make({ fetchImpl: async () => response({ state: 'COMMITTED', receiptId: randomUUID(), userId: randomUUID() }, { contentType: 'text/plain' }) }).provision(binding), error => error.code === 'response_content_type' && error.ambiguous);
});

test('rejects redirects and non-success statuses as ambiguous', async () => {
  await assert.rejects(make({ fetchImpl: async () => ({ redirected: true, status: 200, headers: new Headers({ 'content-type': 'application/json' }), text: async () => '{}' }) }).provision(binding), error => error.code === 'redirect_rejected' && error.ambiguous);
  await assert.rejects(make({ fetchImpl: async () => response({ error: 'no' }, { status: 429 }) }).provision(binding), error => error.code === 'issuer_rejected' && error.ambiguous);
});

test('bounds an access-token provider that ignores abort without an unhandled rejection', async () => {
  const dispatcher = make({ timeoutMs: 100, obtainAccessToken: () => new Promise(() => {}) });
  const started = Date.now();
  await assert.rejects(dispatcher.provision(binding), error => error.code === 'timeout' && !error.requestMayHaveReachedIssuer);
  assert.ok(Date.now() - started < 500);
});

test('bounds a fetch that ignores abort and reports request ambiguity', async () => {
  const dispatcher = make({ timeoutMs: 100, fetchImpl: () => new Promise(() => {}) });
  await assert.rejects(dispatcher.provision(binding), error => error.code === 'timeout' && error.requestMayHaveReachedIssuer && error.ambiguous);
});

test('parent abort before dispatch skips token acquisition and during fetch is ambiguous', async () => {
  let tokenCalls = 0;
  const before = new AbortController(); before.abort();
  await assert.rejects(make({ obtainAccessToken: async () => { tokenCalls += 1; return token; } }).provision(binding, { signal: before.signal }), error => error.code === 'aborted' && !error.ambiguous);
  assert.equal(tokenCalls, 0);
  const during = new AbortController();
  const dispatcher = make({ fetchImpl: async () => { await new Promise(resolve => setTimeout(resolve, 100)); return response({ state: 'COMMITTED', receiptId: randomUUID(), userId: randomUUID() }); } });
  const pending = dispatcher.provision(binding, { signal: during.signal });
  setTimeout(() => during.abort(), 10);
  await assert.rejects(pending, error => error.code === 'aborted' && error.requestMayHaveReachedIssuer);
});

test('bounds streamed response bytes', async () => {
  const dispatcher = make({ maxResponseBytes: 256, fetchImpl: async () => ({
    status: 200,
    redirected: false,
    headers: new Headers({ 'content-type': 'application/json' }),
    body: new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(300)); controller.close(); } }),
  }) });
  await assert.rejects(dispatcher.provision(binding), error => error.code === 'response_too_large' && error.ambiguous);
});

test('rejects noncanonical identities and hashes before requesting a token', async () => {
  let calls = 0;
  const d = make({ obtainAccessToken: async () => { calls++; return token; } });
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    for (const field of ['operationId', 'attemptId', 'leaseTokenHash']) {
      await assert.rejects(d.provision({ ...binding, [field]: binding[field] + suffix }));
    }
    await assert.rejects(make({ fetchImpl: async () => response({ state: 'COMMITTED', receiptId: randomUUID() + suffix, userId: randomUUID() }) }).provision(binding), e => e.ambiguous);
  }
  assert.equal(calls, 0);
});
test('token-provider and fetch exceptions cannot smuggle secrets through typed errors', async () => {
  const leak = 'synthetic-secret-must-never-escape';
  for (const field of ['obtainAccessToken', 'fetchImpl']) {
    await assert.rejects(make({ [field]: async () => { throw new ProvisionDispatchError('timeout', leak, true); } }).provision(binding), e =>
      e instanceof ProvisionDispatchError && !e.message.includes(leak) && e.code !== 'timeout' && e.ambiguous === (field === 'fetchImpl'));
  }
});
test('rejects malformed bearer text without calling fetch', async () => {
  for (const value of ['token internal space', 'nonasciié', 'token\n', 'bad,token']) {
    let calls = 0;
    await assert.rejects(make({ obtainAccessToken: async () => value, fetchImpl: async () => { calls++; } }).provision(binding), e => !e.ambiguous);
    assert.equal(calls, 0);
  }
});
test('cancels a late response when an injected fetch ignores abort', async () => {
  let resolveFetch, cancelled = 0;
  const pending = make({ timeoutMs: 100, fetchImpl: () => new Promise(resolve => { resolveFetch = resolve; }) }).provision(binding);
  await assert.rejects(pending, e => e.code === 'timeout' && e.ambiguous);
  resolveFetch(new Response(new ReadableStream({ cancel() { cancelled++; } }), { headers: { 'content-type': 'application/json' } }));
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(cancelled, 1);
});
test('rejects text-only unbounded adapters and invalid UTF8', async () => {
  let textCalls = 0;
  await assert.rejects(make({ fetchImpl: async () => ({ status: 200, headers: new Headers({ 'content-type': 'application/json' }), text: async () => { textCalls++; return '{}'; } }) }).provision(binding), e => e.code === 'response_invalid' && e.ambiguous);
  assert.equal(textCalls, 0);
  await assert.rejects(make({ fetchImpl: async () => new Response(Uint8Array.from([0xc3, 0x28]), { headers: { 'content-type': 'application/json' } }) }).provision(binding), e => e.code === 'response_invalid' && e.ambiguous);
});
test('releases rejected-content streams without reading them', async () => {
  let cancelled = 0;
  await assert.rejects(make({ fetchImpl: async () => new Response(new ReadableStream({ cancel() { cancelled++; } }), { headers: { 'content-type': 'text/plain' } }) }).provision(binding), e => e.code === 'response_content_type');
  assert.equal(cancelled, 1);
});
