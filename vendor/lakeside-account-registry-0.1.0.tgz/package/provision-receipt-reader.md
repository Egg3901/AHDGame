# Durable provision receipt reader

`createProvisionReceiptReader(pool, { issuer, realmId, schema, queryTimeoutMs })`
returns the trusted `loadProvisionReceipt(binding, { signal })` adapter. It reads
only the permanent issuer owner joined to its attempt, scoped to the configured
realm and exact account, operation and attempt. It supplies the configured issuer
alongside the Java receipt fields. The coordinator must compare every field to
its immutable binding before recording evidence or linking an identity.

A committed snapshot is required. A provider method result or HTTP success before
transaction commit is insufficient. COMMITTED and ABORTED evidence are returned
as immutable objects; missing and MUTATING rows return null. Neither null nor a
read failure permits another attempt. A deleted user does not erase its permanent
receipt and this reader does not treat receipt existence as login authorization.

The pool must use a bounded connection timeout (1..5000 ms). Each query has a
bounded client timeout and the read-only transaction sets a server statement
timeout. Cancellation discards evidence. Failed checked-out connections are
destroyed without closing the shared pool. These are per-operation bounds, not
one aggregate wall-clock deadline. The coordinator supplies the total reader
budget. Queries that have already started may run until their bounded deadline;
no read result is accepted after cancellation.

Deployment must separately establish verified PostgreSQL TLS, the exact issuer
and realm binding, dedicated read-only credentials, and column grants. This
injected-pool module does not claim to authenticate its own database transport.
It is not a public endpoint. No passwords, bearer tokens or browser claims enter
its API or logs. It never reads USER_ENTITY, credentials, email or user attributes.

Root validation on 2026-09-10: 21 focused cases passed. Four additional read-only
cases passed against actual committed and aborted receipts from the isolated
Keycloak provisioning fixture, including repeated reads, mismatched account and
operation, unknown attempt, and different realm. That fixture used the synthetic
administrative pool, so it does not establish deployment TLS or reader-role
permissions. The separate database-role fixture must prove those grants.

Run focused checks with `node --test provision-receipt-reader.test.mjs` in this
package. The actual-issuer checks live in `compat/provision-receipt-reader.test.mjs`
and require `LAKESIDE_ISOLATED_PROVISION_RECEIPT_READ_TEST=true`, the isolated
Compose database, and prior account-provision fixture receipts. They perform no
database writes and do not restart issuers.
