import { randomUUID, createHash } from 'node:crypto';
import { readFile } from 'node:fs/promises';

export { createProvisionCoordinator, ProvisionConflictError, ProvisionUnavailableError } from './provision-bind.mjs';
export { createProvisionAccessTokenProvider, ProvisionAccessTokenError } from './provision-access-token.mjs';

export class MappingConflictError extends Error {
  constructor() { super('Identity is already mapped; explicit ownership resolution is required'); this.name = 'MappingConflictError'; }
}
export class AccountProofError extends Error {
  constructor() { super('Fresh account ownership proof is required'); this.name = 'AccountProofError'; }
}
export class AccountSuspendedError extends Error {
  constructor() { super('Account is suspended'); this.name = 'AccountSuspendedError'; }
}

function nonempty(value, max, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u001f\u007f]/u.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}
function accountId(value) {
  if (typeof value !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value)) throw new TypeError('Invalid account ID');
  return value.toLowerCase();
}
async function transaction(pool, operation) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL lock_timeout = '5s'");
    await client.query("SET LOCAL statement_timeout = '10s'");
    const result = await operation(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}
async function event(client, id, action, provenance) {
  const eventId = randomUUID();
  await client.query('INSERT INTO lakeside_accounts.audit_event(event_id, account_id, action, provenance) VALUES ($1,$2,$3,$4)', [eventId, id, action, provenance]);
  await client.query('INSERT INTO lakeside_accounts.outbox(event_id) VALUES ($1)', [eventId]);
}
async function activeAccount(client, id) {
  const { rows } = await client.query('SELECT * FROM lakeside_accounts.account WHERE account_id=$1 FOR UPDATE', [id]);
  if (!rows[0]) throw new Error('Unknown account');
  if (rows[0].status !== 'active' || rows[0].recovery_hold) throw new AccountSuspendedError();
  return rows[0];
}

// Run separately with migration credentials, never implicitly during login.
export async function migrate(pool) {
  const migrations = await Promise.all(['schema.sql', 'schema-002.sql', 'schema-003.sql', 'schema-004.sql'].map(async (file, index) => {
    const sql = await readFile(new URL('./'+file, import.meta.url), 'utf8');
    return {version:index+1,sql,checksum:createHash('sha256').update(sql).digest('hex')};
  }));
  return transaction(pool, async client => {
    await client.query('SELECT pg_advisory_xact_lock(1684288051)');
    await client.query('CREATE SCHEMA IF NOT EXISTS lakeside_accounts');
    await client.query('CREATE TABLE IF NOT EXISTS lakeside_accounts.migration (version integer PRIMARY KEY, checksum text NOT NULL, applied_at timestamptz NOT NULL DEFAULT now())');
    for (const {version,sql,checksum} of migrations) {
      const {rows} = await client.query('SELECT checksum FROM lakeside_accounts.migration WHERE version=$1',[version]);
      if (rows.length) {
        if (rows[0].checksum !== checksum) throw new Error('Applied account migration checksum differs');
        continue;
      }
      await client.query(sql);
      await client.query('INSERT INTO lakeside_accounts.migration(version,checksum) VALUES ($1,$2)',[version,checksum]);
    }
  });
}

/** Trusted backend boundary: callers must validate identity proof before calling.
 * issuer allowlists must be environment-specific. No method accepts email,
 * browser claims, bearer tokens, or an arbitrary target account for login.
 */
export function createAccountRegistry(pool, { allowedIssuers, allowedApplications }) {
  if (!Array.isArray(allowedIssuers) || !allowedIssuers.length || !Array.isArray(allowedApplications)) throw new TypeError('Explicit issuer and application allowlists are required');
  const issuers = new Set(allowedIssuers.map(value => nonempty(value, 512, 'issuer')));
  const applications = new Set(allowedApplications.map(value => nonempty(value, 128, 'application')));
  const identityKey = identity => {
    const issuer = nonempty(identity?.issuer, 512, 'issuer');
    const subject = nonempty(identity?.subject, 512, 'subject');
    if (!issuers.has(issuer)) throw new Error('Untrusted identity issuer');
    return [issuer, subject];
  };
  return {
    async resolveOrCreateVerifiedIdentity(identity, provenance) {
      const [issuer, subject] = identityKey(identity);
      nonempty(provenance, 256, 'provenance');
      return transaction(pool, async client => {
        // Serialize first-use races before creating an account. Hash collisions
        // only serialize unrelated identities; exact keys still decide ownership.
        await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [JSON.stringify([issuer, subject])]);
        const { rows } = await client.query('SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2', [issuer, subject]);
        if (rows[0]) return activeAccount(client, rows[0].account_id);
        const id = randomUUID();
        await client.query('INSERT INTO lakeside_accounts.account(account_id) VALUES ($1)', [id]);
        await client.query('INSERT INTO lakeside_accounts.external_identity(issuer,subject,account_id,provenance) VALUES ($1,$2,$3,$4)', [issuer, subject, id, provenance]);
        await event(client, id, 'account.created', provenance);
        return activeAccount(client, id);
      });
    },

    // Trusted verified-proof seam, never browser claims. The caller validates
    // signatures, audience, nonce, browser intent and live session status first.
    // Neither matching email nor an arbitrary target UUID establishes ownership.
    async linkVerifiedIdentity({ primary, secondary }, provenance) {
      const first = identityKey(primary);
      const second = identityKey(secondary);
      const id = accountId(primary.accountId);
      nonempty(provenance, 256, 'provenance');
      if (typeof primary.securityVersion !== 'string' || !/^[1-9][0-9]{0,18}$/.test(primary.securityVersion)) throw new AccountProofError();
      const fresh = now => [primary, secondary].every(proof => Number.isSafeInteger(proof.authenticatedAt) && proof.authenticatedAt > 0 && proof.authenticatedAt <= now + 30 && proof.authenticatedAt >= now - 300);
      if (!fresh(Math.floor(Date.now()/1000))) throw new AccountProofError();
      return transaction(pool, async client => {
        // Same identity-first lock order as first login, sorted for two proofs.
        for (const key of [...new Set([JSON.stringify(first), JSON.stringify(second)])].sort()) {
          await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [key]);
        }
        const account = await activeAccount(client, id);
        const {rows: clock} = await client.query('SELECT floor(extract(epoch from clock_timestamp()))::bigint::text AS now');
        if (!fresh(Number(clock[0].now)) || account.security_version !== primary.securityVersion || BigInt(primary.authenticatedAt) <= BigInt(account.authentication_not_before)) throw new AccountProofError();
        const {rows: owner} = await client.query('SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2', first);
        if (owner[0]?.account_id !== id) throw new AccountProofError();
        const {rows: existing} = await client.query('SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2', second);
        if (existing.length) {
          if (existing[0].account_id !== id) throw new MappingConflictError();
          return account;
        }
        await client.query('INSERT INTO lakeside_accounts.external_identity(issuer,subject,account_id,provenance) VALUES ($1,$2,$3,$4)', [...second, id, provenance]);
        await client.query('UPDATE lakeside_accounts.account SET security_version=security_version+1 WHERE account_id=$1', [id]);
        await event(client, id, 'identity.linked', provenance);
        return activeAccount(client, id);
      });
    },

    // Migration/admin seam, not a self-service link API. An application must
    // establish existing local ownership independently before calling this.
    async mapApplicationIdentity(id, application, localId, provenance) {
      id = accountId(id); nonempty(application, 128, 'application');
      nonempty(localId, 512, 'local user ID'); nonempty(provenance, 256, 'provenance');
      if (!applications.has(application)) throw new Error('Unregistered application');
      try {
        return await transaction(pool, async client => {
          await activeAccount(client, id);
          const { rows } = await client.query('SELECT account_id, local_user_id FROM lakeside_accounts.application_identity WHERE application_id=$1 AND (local_user_id=$2 OR account_id=$3)', [application, localId, id]);
          if (rows.length) {
            if (rows.length === 1 && rows[0].account_id === id && rows[0].local_user_id === localId) return;
            throw new MappingConflictError();
          }
          await client.query('INSERT INTO lakeside_accounts.application_identity(application_id,local_user_id,account_id,provenance) VALUES ($1,$2,$3,$4)', [application, localId, id, provenance]);
          await event(client, id, 'application.mapped', provenance);
        });
      } catch (error) {
        if (error.code === '23505') throw new MappingConflictError();
        throw error;
      }
    },

    // Read from the authoritative database on every authorization. Do not cache
    // this result or serve it from a lagging replica.
    async getAccountSecurity(id) {
      id = accountId(id);
      const { rows } = await pool.query("SELECT account_id,CASE WHEN recovery_hold THEN 'suspended' ELSE status END AS status,security_version::text,authentication_not_before::text FROM lakeside_accounts.account WHERE account_id=$1", [id]);
      return rows[0] ?? null;
    },

    async findApplicationIdentity(id, application) {
      id = accountId(id);
      if (!applications.has(application)) throw new Error('Unregistered application');
      const { rows } = await pool.query("SELECT i.local_user_id FROM lakeside_accounts.application_identity i JOIN lakeside_accounts.account a USING(account_id) WHERE i.account_id=$1 AND i.application_id=$2 AND a.status='active' AND NOT a.recovery_hold", [id, application]);
      return rows[0]?.local_user_id ?? null;
    },

    // Trusted administrative operation, also suitable after verified recovery.
    // It invalidates existing application sessions without changing ownership.
    async revokeAccountSessions(id, provenance) {
      id = accountId(id); nonempty(provenance, 256, 'provenance');
      return transaction(pool, async client => {
        await activeAccount(client, id);
        const { rows } = await client.query('UPDATE lakeside_accounts.account SET security_version=security_version+1, authentication_not_before=GREATEST(authentication_not_before,floor(extract(epoch from clock_timestamp()))::bigint) WHERE account_id=$1 RETURNING security_version::text', [id]);
        await event(client, id, 'account.sessions_revoked', provenance);
        return rows[0].security_version;
      });
    },

    // The caller must authorize this administrative operation. Delivery is
    // queued atomically. Adapter security checks also reject suspended accounts
    // without waiting for outbox delivery.
    async suspendAccount(id, provenance) {
      id = accountId(id); nonempty(provenance, 256, 'provenance');
      return transaction(pool, async client => {
        const { rows } = await client.query("UPDATE lakeside_accounts.account SET status='suspended', security_version=security_version+1, authentication_not_before=GREATEST(authentication_not_before,floor(extract(epoch from clock_timestamp()))::bigint) WHERE account_id=$1 AND status='active' RETURNING account_id", [id]);
        if (rows.length) await event(client, id, 'account.suspended', provenance);
      });
    },
  };
}
