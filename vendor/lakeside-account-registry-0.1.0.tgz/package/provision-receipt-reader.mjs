// Trusted backend adapter. The pool's TLS identity, credentials and read-only
// grants are deployment prerequisites, not established by this module.
export class ProvisionReceiptReadError extends Error {
  constructor() { super('Provision receipt is unavailable'); this.name = 'ProvisionReceiptReadError'; }
}
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
const HASH = /^[0-9a-f]{64}$/u;
const CONTROL = /[\u0000-\u0020\u007f]/u;
function text(value, max) {
  return typeof value === 'string' && value.length > 0 && value.length <= max && !CONTROL.test(value);
}
function uuid(value) {
  return typeof value === 'string' && value.length === 36 && UUID.test(value);
}
function positiveInteger(value) {
  if (!text(value, 16) || !/^[1-9][0-9]*$/u.test(value)) throw new ProvisionReceiptReadError();
  const result = Number(value);
  if (!Number.isSafeInteger(result)) throw new ProvisionReceiptReadError();
  return result;
}

/**
 * Read the permanent issuer owner and attempt in one committed SQL snapshot.
 * The configured issuer and realm are trusted deployment values, never read
 * from a request URL. No caller-selected subject is accepted. The coordinator
 * must compare every returned binding field to its immutable local attempt.
 * Missing and MUTATING rows return null; neither authorizes a new attempt.
 *
 * Every query has a client deadline and the SELECT has a server deadline.
 * Cancellation discards evidence; this adapter owns and releases only the
 * checked-out client. It never ends the shared pool. A failed connection is
 * destroyed so timed-out work cannot be reused by another request.
 */
export function createProvisionReceiptReader(pool, { issuer, realmId, schema = 'public', queryTimeoutMs = 3000 }) {
  let parsed;
  try { parsed = new URL(issuer); } catch { throw new TypeError('Explicit HTTPS issuer required'); }
  if (!text(issuer, 512) || parsed.protocol !== 'https:' || parsed.username || parsed.password
      || /[?#]/u.test(issuer)) throw new TypeError('Exact HTTPS issuer required');
  if (!text(realmId, 255)) throw new TypeError('Explicit realm required');
  if (!text(schema, 63) || !/^[a-z][a-z0-9_]{0,62}$/u.test(schema)
      || schema.startsWith('pg_') || schema === 'information_schema') throw new TypeError('Invalid issuer schema');
  if (!Number.isSafeInteger(queryTimeoutMs) || queryTimeoutMs < 100 || queryTimeoutMs > 5000) throw new TypeError('Bounded query timeout required');
  if (!pool || typeof pool.connect !== 'function'
      || !Number.isSafeInteger(pool.options?.connectionTimeoutMillis)
      || pool.options.connectionTimeoutMillis < 1 || pool.options.connectionTimeoutMillis > 5000) {
    throw new TypeError('Pool must have a bounded connection timeout');
  }
  const sql = `SELECT o.account_id, o.operation_id, o.realm_id, o.username, o.user_id,
       a.attempt_id, a.attempt_generation::text, a.lease_token_hash,
       a.lease_expires_ms::text, a.receipt_id, a.state
    FROM "${schema}".lakeside_account_provision_owner o
    JOIN "${schema}".lakeside_account_provision_attempt a
      ON a.account_id=o.account_id AND a.operation_id=o.operation_id
    WHERE a.attempt_id=$1 AND o.realm_id=$2 AND o.account_id=$3 AND o.operation_id=$4`;
  return async function loadProvisionReceipt(input, { signal } = {}) {
    // Copy primitives before any await; a caller cannot change the SQL identity
    // while the pool connection is pending. Validate without string coercion.
    const binding = input && { issuer: input.issuer, realmId: input.realmId,
      accountId: input.accountId, operationId: input.operationId, attemptId: input.attemptId };
    if (!binding || binding.issuer !== issuer || binding.realmId !== realmId
        || !uuid(binding.attemptId) || !uuid(binding.accountId) || !uuid(binding.operationId)
        || signal?.aborted) throw new ProvisionReceiptReadError();
    let client;
    let broken = false;
    const query = (text, values = []) => client.query({ text, values, query_timeout: queryTimeoutMs });
    try {
      client = await pool.connect();
      if (signal?.aborted) throw new ProvisionReceiptReadError();
      await query('BEGIN READ ONLY');
      await query("SELECT set_config('statement_timeout',$1,true)", [String(queryTimeoutMs)]);
      const result = await query(sql, [binding.attemptId, realmId, binding.accountId, binding.operationId]);
      await query('COMMIT');
      if (signal?.aborted || !Array.isArray(result.rows) || result.rows.length > 1) throw new ProvisionReceiptReadError();
      if (result.rows.length === 0) return null;
      const row = result.rows[0];
      if (row.state === 'MUTATING') return null;
      if (!['COMMITTED', 'ABORTED'].includes(row.state)
          || ![row.account_id, row.operation_id, row.user_id, row.attempt_id, row.receipt_id].every(uuid)
          || row.account_id !== binding.accountId || row.operation_id !== binding.operationId
          || row.attempt_id !== binding.attemptId || row.realm_id !== realmId
          || row.username !== `lakeside:${row.account_id}`
          || typeof row.lease_token_hash !== 'string' || row.lease_token_hash.length !== 64 || !HASH.test(row.lease_token_hash)) throw new ProvisionReceiptReadError();
      return Object.freeze({
        issuer, accountId: row.account_id, operationId: row.operation_id, realmId,
        username: row.username, userId: row.user_id, attemptId: row.attempt_id,
        attemptGeneration: positiveInteger(row.attempt_generation),
        leaseTokenHash: row.lease_token_hash, leaseExpiresAtMs: positiveInteger(row.lease_expires_ms),
        receiptId: row.receipt_id, state: row.state,
      });
    } catch {
      broken = true;
      // Discard the dedicated connection on all failures. A close rolls back
      // an unfinished read-only transaction without another unbounded query.
      throw new ProvisionReceiptReadError();
    } finally {
      if (client) client.release(broken);
    }
  };
}
