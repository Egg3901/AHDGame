# Trusted provision workflow

`createProvisionWorkflow` composes the existing account registry provision
coordinator with the one-shot issuer dispatcher. It is a trusted backend
workflow. It has no HTTP listener, user activation path, enrollment path, or
automatic traffic routing.

```js
import { createProvisionWorkflow } from './provision-workflow.mjs';

const workflow = createProvisionWorkflow({
  coordinator,
  dispatcher,
  issuer: 'https://issuer.example.invalid/realms/lakeside',
  realmId: 'lakeside-fixture',
  leaseMs: 60_000,
});

const result = await workflow.provisionDisabledAccount({
  accountId,
  provenance: 'trusted-backend:provision',
  signal,
});
```

The factory copies the primitive issuer, realm, and lease configuration and
captures the coordinator and dispatcher methods. The caller supplies only a
canonical account UUID and provenance. It cannot choose an operation ID,
attempt ID, issuer endpoint, realm, username, target user, lease, or token.

The workflow calls `startProvisionAttempt` once. An already-provisioned
result is validated against the configured account, issuer, realm, canonical
username, operation ID, attempt ID, receipt ID, and user ID, then returned as
`state: 'COMMITTED'` with `replay: true`. This is prior durable coordinator
evidence. It is not a fresh issuer check.

For a reused live binding, the workflow reconciles first. A durable
`COMMITTED` or `ABORTED` result is returned without dispatch. Only an
authenticated `ProvisionUnavailableError` permits one dispatch of that exact
binding. Conflicts fail closed. A fresh binding is dispatched once. Whether
the candidate succeeds, times out, contains malformed data, or throws, the
workflow reconciles exactly once afterward. A dispatcher candidate is never
treated as proof and is never returned as durable success.

Terminal results are copied from coordinator evidence:

```json
{
  "state": "COMMITTED",
  "accountId": "canonical account UUID",
  "operationId": "stable operation UUID",
  "attemptId": "attempt UUID",
  "attemptGeneration": 1,
  "receiptId": "provider receipt UUID",
  "userId": "provider user UUID",
  "issuer": "configured issuer",
  "replay": false
}
```

If the receipt is unavailable, the result is a frozen pending record with
the stable account, operation, attempt, generation, issuer, and
`reason: 'receipt_unavailable'`. It never starts a replacement attempt, calls
the abort endpoint, or claims that the provider did not mutate. Other
coordinator failures return pending with
`reason: 'coordinator_unavailable'` when the binding is known. A conflict or
invalid injected result throws a sanitized `ProvisionWorkflowError`.

An already committed provision receipt proves the initial provider operation
was durably recorded. It does not prove that the provider user still exists
or remains disabled. The workflow never recreates a target from an old
committed row and never enables or changes credentials. Provider receipt
authentication, current disabled-state enforcement, TLS credentials, and
deployment endpoint configuration remain external trust boundaries.

Cancellation before start prevents coordinator work. Cancellation after a
start prevents a new dispatch when possible, but durable reconciliation still
runs so a concurrent issuer operation is not hidden. The workflow does not
race or abandon database operations.

Run the focused tests without external services:

```sh
node --unhandled-rejections=strict --test provision-workflow.test.mjs
```

The real coordinator test is opt-in and requires the isolated Compose
database service. It creates and drops a generated synthetic database only:

```sh
LAKESIDE_ISOLATED_PROVISION_WORKFLOW_TEST=true \
PGHOST=database \
node --test provision-workflow.test.mjs
```

