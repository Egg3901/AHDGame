import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID, createHash } from 'node:crypto';
import pg from 'pg';
import { createAccountRegistry, migrate, createProvisionCoordinator, ProvisionConflictError, ProvisionUnavailableError } from './index.mjs';

if (process.env.LAKESIDE_ISOLATED_REGISTRY_TEST !== 'true' || process.env.PGHOST !== 'database') {
  throw new Error('Run through the isolated compat Compose registry-tests service');
}
const database = `registry_provision_test_${randomUUID().replaceAll('-', '')}`;
const admin = new pg.Pool({ max: 1, connectionTimeoutMillis: 2000, query_timeout: 10000, statement_timeout: 8000 });
let pool, registry;
let databaseCreated = false;
const LOGIN_ISSUER = 'https://login.example.invalid';
const ISSUER = 'https://provision.example.invalid';
const OTHER_ISSUER = 'https://provision-other.example.invalid';
const REALM = 'provision-realm';
const options = { allowedIssuers: [LOGIN_ISSUER], allowedApplications: ['ahd'] };
let userSeq = 0;
async function freshAccount() {
  userSeq += 1;
  return registry.resolveOrCreateVerifiedIdentity({ issuer: LOGIN_ISSUER, subject: `provision-user-${userSeq}` }, 'provision-test:setup');
}
function coordinator(loader, overrides = {}) {
  return createProvisionCoordinator(pool, {
    allowedProvisionIssuers: [ISSUER],
    loadProvisionReceipt: loader ?? (async () => { throw new Error('no receipt'); }),
    ...overrides,
  });
}
async function start(account, opts = {}) {
  return coordinator(opts.loader).startProvisionAttempt({
    accountId: account.account_id, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'provision-test:start', ...opts,
  });
}
// Build an exact-shape receipt for a started binding. userId/receiptId minted
// per call unless pinned, so callers freeze the reserved target explicitly.
function receiptFor(started, { userId = randomUUID(), receiptId = randomUUID(), state = 'COMMITTED' } = {}) {
  const b = started.binding;
  return {
    accountId: b.accountId, operationId: b.operationId, realmId: b.realmId, username: b.username, userId,
    attemptId: b.attemptId, attemptGeneration: b.attemptGeneration, leaseTokenHash: b.leaseTokenHash,
    leaseExpiresAtMs: b.leaseExpiresAtMs, receiptId, state, issuer: started.issuer,
  };
}
function loaderFor(receiptMap) {
  const calls = [];
  const loader = async (binding, { signal } = {}) => {
    calls.push({ binding, signal });
    const receipt = typeof receiptMap === 'function' ? await receiptMap(binding) : receiptMap[binding.attemptId];
    if (!receipt) throw new Error('missing attempt');
    return receipt;
  };
  return { loader, calls };
}
async function count(table, where = '', params = []) {
  return (await pool.query(`SELECT count(*) FROM ${table} ${where}`, params)).rows[0].count;
}

test.before(async () => {
  databaseCreated = true;
  await admin.query(`CREATE DATABASE ${database}`);
  pool = new pg.Pool({ database, max: 12, connectionTimeoutMillis: 2000, query_timeout: 10000, statement_timeout: 8000 });
  await Promise.all([migrate(pool), migrate(pool)]);
  registry = createAccountRegistry(pool, options);
});
test.after(async () => {
  try { await pool?.end(); } finally {
    try { if (databaseCreated) await admin.query(`DROP DATABASE IF EXISTS ${database}`); } finally { await admin.end(); }
  }
});

test('start mints a fully bound attempt with DB-clock expiry and audits', async () => {
  const account = await freshAccount();
  const before = Date.now();
  const started = await start(account);
  assert.equal(started.reused, false);
  assert.equal(started.issuer, ISSUER);
  assert.ok(Object.isFrozen(started.binding));
  const b = started.binding;
  assert.deepEqual(Object.keys(b).sort(), ['accountId', 'attemptGeneration', 'attemptId', 'issuer', 'leaseExpiresAtMs', 'leaseTokenHash', 'operationId', 'realmId', 'username', 'version'].sort());
  assert.equal(b.version, 1);
  assert.equal(b.accountId, account.account_id);
  assert.equal(b.realmId, REALM);
  assert.equal(b.username, `lakeside:${account.account_id}`);
  assert.ok(!('userId' in b) && !('receiptId' in b) && !('state' in b));
  assert.match(b.leaseTokenHash, /^[0-9a-f]{64}$/);
  assert.ok(Number.isSafeInteger(b.attemptGeneration) && b.attemptGeneration === 1);
  assert.ok(b.leaseExpiresAtMs >= before + 60000 - 5000 && b.leaseExpiresAtMs <= Date.now() + 60000 + 5000);
  const { rows } = await pool.query('SELECT * FROM lakeside_accounts.provision_attempt WHERE attempt_id=$1', [b.attemptId]);
  assert.equal(rows[0].account_security_version, '1');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1', [account.account_id])).rows[0].count, '1');
  assert.equal(await count('lakeside_accounts.audit_event', "WHERE account_id=$1 AND action='provision.attempt_started'", [account.account_id]), '1');
});

test('live attempt is reused immutably even when expired; never re-leased', async () => {
  const account = await freshAccount();
  const first = await start(account, { leaseMs: 100 });
  const second = await start(account, { leaseMs: 1000, provenance: 'provision-test:retry' });
  assert.equal(second.reused, true);
  assert.deepEqual(second.binding, first.binding);
  await new Promise(resolve => setTimeout(resolve, 150));
  const third = await start(account);
  assert.equal(third.reused, true);
  assert.deepEqual(third.binding.attemptId, first.binding.attemptId);
  assert.deepEqual(third.binding.leaseTokenHash, first.binding.leaseTokenHash);
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
});

test('start validates caller input and pins operation issuer/realm', async () => {
  const account = await freshAccount();
  await assert.rejects(start(account, { issuer: 'http://provision.example.invalid' }), TypeError);
  await assert.rejects(start(account, { issuer: 'https://user:pass@provision.example.invalid' }), TypeError);
  await assert.rejects(start(account, { issuer: 'https://provision.example.invalid/?' }), TypeError);
  await assert.rejects(start(account, { issuer: 'https://provision.example.invalid/#' }), TypeError);
  await assert.rejects(start(account, { issuer: 'https://provision.example.invalid/?a=b' }), TypeError);
  await assert.rejects(start(account, { issuer: 'https://evil.example.invalid' }), ProvisionConflictError);
  await assert.rejects(start(account, { realmId: '' }), TypeError);
  await assert.rejects(start(account, { leaseMs: 50 }), TypeError);
  await assert.rejects(start(account, { leaseMs: 86400001 }), TypeError);
  await assert.rejects(start(account, { accountId: 'not-a-uuid' }), TypeError);
  await start(account);
  const twoIssuer = coordinator(undefined, { allowedProvisionIssuers: [ISSUER, OTHER_ISSUER] });
  await assert.rejects(twoIssuer.startProvisionAttempt({ accountId: account.account_id, issuer: OTHER_ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'x' }), ProvisionConflictError);
  await assert.rejects(coordinator().startProvisionAttempt({ accountId: account.account_id, issuer: ISSUER, realmId: 'other-realm', leaseMs: 60000, provenance: 'x' }), ProvisionConflictError);
});

test('identity validators reject terminal line separators and coercion before any DB transaction', async () => {
  let connects = 0;
  const noConnectPool = { connect: async () => { connects += 1; throw new Error('unexpected transaction'); } };
  const noConnectCoordinator = createProvisionCoordinator(noConnectPool, {
    allowedProvisionIssuers: [ISSUER], loadProvisionReceipt: async () => { throw new Error('unused'); },
  });
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    await assert.rejects(noConnectCoordinator.startProvisionAttempt({
      accountId: `${randomUUID()}${suffix}`, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'validator-test',
    }), TypeError);
  }
  await assert.rejects(noConnectCoordinator.startProvisionAttempt({
    accountId: { toString: () => randomUUID() }, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'validator-test',
  }), TypeError);
  assert.equal(connects, 0);

  const account = await freshAccount();
  const started = await start(account);
  const storedReceipt = receiptFor(started);
  for (const field of ['accountId', 'operationId', 'userId', 'attemptId', 'receiptId', 'leaseTokenHash', 'realmId', 'username', 'issuer']) {
    for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
      const bad = { ...storedReceipt, [field]: `${storedReceipt[field]}${suffix}` };
      await assert.rejects(coordinator(loaderFor({ [started.binding.attemptId]: bad }).loader)
        .reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'validator-test' }), ProvisionUnavailableError,
      `${field} ${JSON.stringify(suffix)} must be unavailable evidence`);
    }
  }
  for (const field of ['accountId', 'operationId', 'userId', 'attemptId', 'receiptId', 'leaseTokenHash']) {
    const good = storedReceipt;
    const bad = { ...good, [field]: { toString: () => good[field] } };
    await assert.rejects(coordinator(loaderFor({ [started.binding.attemptId]: bad }).loader)
      .reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'validator-test' }), ProvisionUnavailableError);
  }

  let bindingTransactions = 0;
  const noBindingTransactionPool = {
    query: async () => ({ rows: [{ binding: started.binding, issuer: ISSUER }] }),
    connect: async () => { bindingTransactions += 1; throw new Error('binding transaction must not start'); },
  };
  const malformed = { ...storedReceipt, realmId: `${storedReceipt.realmId}\u2028` };
  await assert.rejects(createProvisionCoordinator(noBindingTransactionPool, {
    allowedProvisionIssuers: [ISSUER], loadProvisionReceipt: async () => malformed,
  }).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'validator-test' }), ProvisionUnavailableError);
  assert.equal(bindingTransactions, 0);
});

test('security version validator rejects leading zero and object coercion', async () => {
  const calls = [];
  const client = {
    async query(text) {
      calls.push(text);
      if (text === 'BEGIN' || text.startsWith('SET LOCAL') || text === 'ROLLBACK') return { rows: [] };
      if (text.includes('FROM lakeside_accounts.account WHERE account_id=$1')) {
        return { rows: [{ status: 'active', recovery_hold: false, security_version: '01' }] };
      }
      throw new Error('unexpected query');
    },
    release() {},
  };
  const fake = createProvisionCoordinator({ connect: async () => client }, {
    allowedProvisionIssuers: [ISSUER], loadProvisionReceipt: async () => { throw new Error('unused'); },
  });
  const args = { accountId: randomUUID(), issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'validator-test' };
  await assert.rejects(fake.startProvisionAttempt(args), TypeError);
  assert.ok(calls.every(query => !String(query).includes('INSERT')));
  calls.length = 0;
  client.query = async text => {
    calls.push(text);
    if (text === 'BEGIN' || text.startsWith('SET LOCAL') || text === 'ROLLBACK') return { rows: [] };
    if (text.includes('FROM lakeside_accounts.account WHERE account_id=$1')) {
      return { rows: [{ status: 'active', recovery_hold: false, security_version: { toString: () => '1' } }] };
    }
    throw new Error('unexpected query');
  };
  await assert.rejects(fake.startProvisionAttempt(args), TypeError);
  assert.ok(calls.every(query => !String(query).includes('INSERT')));
});

test('start fails closed for unknown, suspended, and held accounts', async () => {
  await assert.rejects(start({ account_id: randomUUID() }), ProvisionConflictError);
  const suspended = await freshAccount();
  await registry.suspendAccount(suspended.account_id, 'provision-test:suspend');
  await assert.rejects(start(suspended), ProvisionConflictError);
  const held = await freshAccount();
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [held.account_id]);
  await assert.rejects(start(held), ProvisionConflictError);
});

test('committed receipt maps atomically with subject, evidence, audit, outbox', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const userId = randomUUID();
  const receiptId = randomUUID();
  const { loader } = loaderFor({ [started.binding.attemptId]: receiptFor(started, { userId, receiptId }) });
  const out = await coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
  assert.deepEqual(out, { state: 'COMMITTED', accountId: account.account_id, operationId: started.binding.operationId, attemptId: started.binding.attemptId, attemptGeneration: 1, receiptId, userId, issuer: ISSUER, replay: false });
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND subject=$2 AND account_id=$3', [ISSUER, userId, account.account_id]), '1');
  assert.equal(await count('lakeside_accounts.provision_subject', 'WHERE account_id=$1 AND user_id=$2', [account.account_id, userId]), '1');
  assert.equal(await count('lakeside_accounts.provision_evidence', "WHERE attempt_id=$1 AND state='COMMITTED'", [started.binding.attemptId]), '1');
  assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [account.account_id]), '0');
  assert.equal(await count('lakeside_accounts.audit_event e JOIN lakeside_accounts.outbox o USING(event_id)', "WHERE e.account_id=$1 AND e.action='identity.provisioned'", [account.account_id]), '1');
  // No version bump, no enable instruction in the result.
  assert.equal((await registry.getAccountSecurity(account.account_id)).security_version, '1');
  assert.ok(!('enabled' in out) && !('enable' in out));
});

test('identical evidence replays idempotently with no second audit', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const userId = randomUUID();
  const receiptId = randomUUID();
  const receipts = { [started.binding.attemptId]: receiptFor(started, { userId, receiptId }) };
  const { loader } = loaderFor(receipts);
  const c = coordinator(loader);
  await c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
  const replay = await c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:replay' });
  assert.equal(replay.replay, true);
  assert.equal(replay.receiptId, receiptId);
  assert.equal(await count('lakeside_accounts.audit_event', "WHERE account_id=$1 AND action='identity.provisioned'", [account.account_id]), '1');
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND subject=$2', [ISSUER, userId]), '1');
});

test('contradictory evidence for the same attempt conflicts', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const userId = randomUUID();
  const receipts = { [started.binding.attemptId]: receiptFor(started, { userId, receiptId: randomUUID() }) };
  const { loader } = loaderFor(receipts);
  const c = coordinator(loader);
  await c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
  receipts[started.binding.attemptId] = receiptFor(started, { userId, receiptId: randomUUID() });
  await assert.rejects(c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:replay' }), ProvisionConflictError);
  receipts[started.binding.attemptId] = receiptFor(started, { userId: randomUUID(), receiptId: randomUUID() });
  await assert.rejects(c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:replay' }), ProvisionConflictError);
});

test('caller-chosen subject cannot overwrite the frozen target', async () => {
  const account = await freshAccount();
  const first = await start(account);
  const frozen = randomUUID();
  const r1 = { [first.binding.attemptId]: receiptFor(first, { userId: frozen, receiptId: randomUUID(), state: 'ABORTED' }) };
  const c1 = coordinator(loaderFor(r1).loader);
  await c1.reconcileProvisionAttempt({ attemptId: first.binding.attemptId, provenance: 'provision-test:abort' });
  const second = await coordinator().startProvisionAttempt({ accountId: account.account_id, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'provision-test:start2' });
  assert.equal(second.binding.attemptGeneration, 2);
  const impostor = randomUUID();
  const { loader } = loaderFor({ [second.binding.attemptId]: receiptFor(second, { userId: impostor, receiptId: randomUUID() }) });
  await assert.rejects(coordinator(loader).reconcileProvisionAttempt({ attemptId: second.binding.attemptId, provenance: 'provision-test:reconcile' }), ProvisionConflictError);
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND subject=$2', [ISSUER, impostor]), '0');
});

test('missing, MUTATING, transport-failure, and timeout evidence are unavailable and keep the live pointer', async () => {
  const account = await freshAccount();
  const started = await start(account);
  await assert.rejects(coordinator().reconcileProvisionAttempt({ attemptId: randomUUID(), provenance: 'x' }), ProvisionUnavailableError);
  for (const receipt of [
    receiptFor(started, { state: 'MUTATING' }),
    null,
    { ...receiptFor(started), state: 'BOGUS' },
  ]) {
    const { loader } = loaderFor({ [started.binding.attemptId]: receipt });
    await assert.rejects(coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionUnavailableError);
  }
  const failing = async () => { throw new Error('boom'); };
  await assert.rejects(coordinator(failing).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionUnavailableError);
  const hanging = () => new Promise(() => {});
  await assert.rejects(coordinator(hanging, { receiptTimeoutMs: 50 }).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionUnavailableError);
  assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
  assert.equal(await count('lakeside_accounts.provision_evidence', 'WHERE attempt_id=$1', [started.binding.attemptId]), '0');
});

test('loader is never called within a coordinator transaction', async () => {
  const account = await freshAccount();
  const started = await start(account);
  let checkedOut = 0;
  let loaderSaw = -1;
  const acquired = () => { checkedOut += 1; };
  const released = () => { checkedOut -= 1; };
  pool.on('acquire', acquired); pool.on('release', released);
  try {
    const loader = async () => { loaderSaw = checkedOut; return receiptFor(started); };
    await coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
    assert.equal(loaderSaw, 0);
  } finally { pool.off('acquire', acquired); pool.off('release', released); }

});

test('malformed receipts are unavailable: extra keys, arrays, bad shapes', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const good = receiptFor(started);
  const variants = [
    { ...good, extra: 'nope' },
    { ...good, tags: ['a'] },
    (({ receiptId, ...rest }) => rest)(good),
    { ...good, accountId: good.accountId.toUpperCase() },
    { ...good, userId: 'not-a-uuid' },
    { ...good, leaseTokenHash: 'ZZZ' },
    { ...good, attemptGeneration: 1.5 },
    { ...good, attemptGeneration: Number.MAX_SAFE_INTEGER + 1 },
    { ...good, leaseExpiresAtMs: -1 },
    { ...good, username: 'someone-else' },
    { ...good, issuer: 'https://evil.example.invalid' },
    { ...good, receiptId: 'not-a-uuid' },
    [],
    'receipt',
  ];
  for (const bad of variants) {
    const { loader } = loaderFor({ [started.binding.attemptId]: bad });
    await assert.rejects(coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionUnavailableError, JSON.stringify(bad)?.slice(0, 80));
  }
  assert.equal(await count('lakeside_accounts.provision_evidence', 'WHERE attempt_id=$1', [started.binding.attemptId]), '0');
});

test('receipt fields that drift from the durable binding conflict', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const base = receiptFor(started);
  for (const mutate of [
    r => { const id = randomUUID(); return { ...r, accountId: id, username: `lakeside:${id}` }; },
    r => ({ ...r, operationId: randomUUID() }),
    r => ({ ...r, realmId: 'other-realm' }),
    r => ({ ...r, attemptId: randomUUID() }),
    r => ({ ...r, attemptGeneration: 2 }),
    r => ({ ...r, leaseTokenHash: createHash('sha256').update('other').digest('hex') }),
    r => ({ ...r, leaseExpiresAtMs: r.leaseExpiresAtMs + 1 }),
    r => ({ ...r, issuer: ISSUER }),
  ]) {
    const mutated = mutate(base);
    if (JSON.stringify(mutated) === JSON.stringify(base)) continue;
    // attemptId drift cannot be routed: loader map keys off stored attempt,
    // so only in-binding mismatches reach the conflict check here.
    if (mutated.attemptId !== base.attemptId) continue;
    const { loader } = loaderFor({ [started.binding.attemptId]: mutated });
    await assert.rejects(coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionConflictError);
  }
});

test('abort records containment without mapping and unlocks exactly generation 2', async () => {
  const account = await freshAccount();
  const first = await start(account);
  const userId = randomUUID();
  const abortId = randomUUID();
  const { loader: abortLoader } = loaderFor({ [first.binding.attemptId]: receiptFor(first, { userId, receiptId: abortId, state: 'ABORTED' }) });
  const aborted = await coordinator(abortLoader).reconcileProvisionAttempt({ attemptId: first.binding.attemptId, provenance: 'provision-test:abort' });
  assert.equal(aborted.state, 'ABORTED');
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND subject=$2', [ISSUER, userId]), '0');
  assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [account.account_id]), '0');
  assert.equal(await count('lakeside_accounts.provision_evidence', "WHERE attempt_id=$1 AND state='ABORTED'", [first.binding.attemptId]), '1');
  const second = await start(account);
  assert.equal(second.binding.attemptGeneration, 2);
  assert.equal(second.binding.operationId, first.binding.operationId);
  assert.deepEqual(second.binding.leaseTokenHash === first.binding.leaseTokenHash, false);
  const commitId = randomUUID();
  const { loader: commitLoader } = loaderFor({ [second.binding.attemptId]: receiptFor(second, { userId, receiptId: commitId }) });
  const out = await coordinator(commitLoader).reconcileProvisionAttempt({ attemptId: second.binding.attemptId, provenance: 'provision-test:reconcile' });
  assert.equal(out.state, 'COMMITTED');
  assert.equal(out.userId, userId);
});

test('abort evidence is idempotent; committed attempt cannot be aborted', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const userId = randomUUID();
  const abortId = randomUUID();
  const receipts = { [started.binding.attemptId]: receiptFor(started, { userId, receiptId: abortId, state: 'ABORTED' }) };
  const c = coordinator(loaderFor(receipts).loader);
  await c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:abort' });
  const again = await coordinator(loaderFor(receipts).loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' });
  assert.equal(again.replay, true);
  assert.equal(await count('lakeside_accounts.audit_event', "WHERE account_id=$1 AND action='provision.aborted'", [account.account_id]), '1');
  receipts[started.binding.attemptId] = receiptFor(started, { userId, receiptId: randomUUID(), state: 'COMMITTED' });
  await assert.rejects(coordinator(loaderFor(receipts).loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'x' }), ProvisionConflictError);
});

test('generations advance strictly 1..3 across abort cycles', async () => {
  const account = await freshAccount();
  const reservedUserId = randomUUID();
  for (let gen = 1; gen <= 3; gen += 1) {
    const started = await start(account);
    assert.equal(started.binding.attemptGeneration, gen);
    if (gen < 3) {
      const { loader } = loaderFor({ [started.binding.attemptId]: receiptFor(started, { state: 'ABORTED', userId: reservedUserId }) });
      await coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: `provision-test:abort-${gen}` });
    }
  }
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE account_id=$1', [account.account_id]), '3');
});

test('abort records containment during hold and version drift; mapping stays empty', async () => {
  const held = await freshAccount();
  const h1 = await start(held);
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [held.account_id]);
  const { loader: hl } = loaderFor({ [h1.binding.attemptId]: receiptFor(h1, { state: 'ABORTED' }) });
  const out = await coordinator(hl).reconcileProvisionAttempt({ attemptId: h1.binding.attemptId, provenance: 'provision-test:abort' });
  assert.equal(out.state, 'ABORTED');
  const drifted = await freshAccount();
  const d1 = await start(drifted);
  await registry.revokeAccountSessions(drifted.account_id, 'provision-test:revoke');
  const { loader: dl } = loaderFor({ [d1.binding.attemptId]: receiptFor(d1, { state: 'ABORTED' }) });
  await coordinator(dl).reconcileProvisionAttempt({ attemptId: d1.binding.attemptId, provenance: 'provision-test:abort' });
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND account_id IN ($2,$3)', [ISSUER, held.account_id, drifted.account_id]), '0');
});

test('committed mapping fails closed on hold and drift without losing evidence ability', async () => {
  const held = await freshAccount();
  const h1 = await start(held);
  const hReceipt = receiptFor(h1);
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=true WHERE account_id=$1', [held.account_id]);
  const { loader: hl } = loaderFor({ [h1.binding.attemptId]: hReceipt });
  await assert.rejects(coordinator(hl).reconcileProvisionAttempt({ attemptId: h1.binding.attemptId, provenance: 'provision-test:reconcile' }), ProvisionConflictError);
  assert.equal(await count('lakeside_accounts.provision_evidence', 'WHERE attempt_id=$1', [h1.binding.attemptId]), '0');
  await pool.query('UPDATE lakeside_accounts.account SET recovery_hold=false WHERE account_id=$1', [held.account_id]);
  const retry = await coordinator(loaderFor({ [h1.binding.attemptId]: hReceipt }).loader).reconcileProvisionAttempt({ attemptId: h1.binding.attemptId, provenance: 'provision-test:reconcile' });
  assert.equal(retry.state, 'COMMITTED');
  const drifted = await freshAccount();
  const d1 = await start(drifted);
  const dReceipt = receiptFor(d1);
  await registry.revokeAccountSessions(drifted.account_id, 'provision-test:revoke');
  const { loader: dl } = loaderFor({ [d1.binding.attemptId]: dReceipt });
  await assert.rejects(coordinator(dl).reconcileProvisionAttempt({ attemptId: d1.binding.attemptId, provenance: 'provision-test:reconcile' }), ProvisionConflictError);
  assert.equal(await count('lakeside_accounts.provision_evidence', 'WHERE attempt_id=$1', [d1.binding.attemptId]), '0');
  assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [drifted.account_id]), '1');
});

test('committed replay after expiry is allowed with the authentic exact receipt', async () => {
  const account = await freshAccount();
  const started = await start(account, { leaseMs: 100 });
  const h = receiptFor(started);
  const { loader } = loaderFor({ [started.binding.attemptId]: h });
  await new Promise(resolve => setTimeout(resolve, 200));
  const out = await coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
  assert.equal(out.state, 'COMMITTED');
  assert.equal(await count('lakeside_accounts.external_identity', 'WHERE issuer=$1 AND subject=$2', [ISSUER, h.userId]), '1');
});

test('target already owned by another account conflicts without merge', async () => {
  const a = await freshAccount();
  const b = await freshAccount();
  const sa = await start(a);
  const userId = randomUUID();
  const { loader: la } = loaderFor({ [sa.binding.attemptId]: receiptFor(sa, { userId }) });
  await coordinator(la).reconcileProvisionAttempt({ attemptId: sa.binding.attemptId, provenance: 'provision-test:reconcile' });
  const sb = await start(b);
  const { loader: lb } = loaderFor({ [sb.binding.attemptId]: receiptFor(sb, { userId }) });
  await assert.rejects(coordinator(lb).reconcileProvisionAttempt({ attemptId: sb.binding.attemptId, provenance: 'provision-test:reconcile' }), ProvisionConflictError);
  assert.equal((await pool.query('SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2', [ISSUER, userId])).rows[0].account_id, a.account_id);
});

test('audit failure rolls back mapping and evidence together', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const { loader } = loaderFor({ [started.binding.attemptId]: receiptFor(started) });
  await pool.query("ALTER TABLE lakeside_accounts.audit_event ADD CONSTRAINT test_reject_provision CHECK (provenance <> 'reject:provision')");
  try {
    await assert.rejects(coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'reject:provision' }));
    assert.equal(await count('lakeside_accounts.external_identity', 'WHERE account_id=$1 AND issuer=$2', [account.account_id, ISSUER]), '0');
    assert.equal(await count('lakeside_accounts.provision_evidence', 'WHERE attempt_id=$1', [started.binding.attemptId]), '0');
    assert.equal(await count('lakeside_accounts.provision_subject', 'WHERE account_id=$1', [account.account_id]), '0');
    assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
  } finally { await pool.query('ALTER TABLE lakeside_accounts.audit_event DROP CONSTRAINT test_reject_provision'); }
});

test('immutable tables reject UPDATE and DELETE; triggers name the table', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const { loader: abortLoader } = loaderFor({ [started.binding.attemptId]: receiptFor(started, { state: 'ABORTED' }) });
  await coordinator(abortLoader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:abort' });
  await assert.rejects(pool.query('UPDATE lakeside_accounts.provision_operation SET provenance=$1 WHERE account_id=$2', ['mutated', account.account_id]), /append-only/);
  await assert.rejects(pool.query('DELETE FROM lakeside_accounts.provision_operation WHERE account_id=$1', [account.account_id]), /append-only/);
  await assert.rejects(pool.query('UPDATE lakeside_accounts.provision_attempt SET binding=$1 WHERE attempt_id=$2', [JSON.stringify({ tampered: true }), started.binding.attemptId]), /append-only/);
  await assert.rejects(pool.query('DELETE FROM lakeside_accounts.provision_attempt WHERE attempt_id=$1', [started.binding.attemptId]), /append-only/);
  await assert.rejects(pool.query('DELETE FROM lakeside_accounts.provision_evidence WHERE attempt_id=$1', [started.binding.attemptId]), /append-only/);
  await assert.rejects(pool.query('UPDATE lakeside_accounts.provision_subject SET realm_id=$1 WHERE account_id=$2', ['mutated', account.account_id]), /append-only/);
  await assert.rejects(pool.query('DELETE FROM lakeside_accounts.provision_subject WHERE account_id=$1', [account.account_id]), /append-only/);
});

test('concurrent identical starts converge on one attempt and live pointer', async () => {
  const account = await freshAccount();
  const c = coordinator();
  const args = { accountId: account.account_id, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'provision-test:race' };
  const results = await Promise.all(Array.from({ length: 12 }, () => c.startProvisionAttempt(args)));
  assert.equal(new Set(results.map(r => r.binding.attemptId)).size, 1);
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
  assert.equal(await count('lakeside_accounts.provision_live_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
  assert.equal(await count('lakeside_accounts.audit_event', "WHERE account_id=$1 AND action='provision.attempt_started'", [account.account_id]), '1');
});

test('concurrent reconciles converge: one write, one idempotent replay', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const h = receiptFor(started);
  const c = coordinator(async () => h);
  const results = await Promise.all([0, 1, 2].map(i => c.reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: `provision-test:race-${i}` })));
  assert.ok(results.every(r => r.state === 'COMMITTED' && r.receiptId === h.receiptId));
  assert.equal(await count('lakeside_accounts.audit_event', "WHERE account_id=$1 AND action='identity.provisioned'", [account.account_id]), '1');
});

test('start after COMMITTED returns already-provisioned metadata and mints nothing', async () => {
  const account = await freshAccount();
  const started = await start(account);
  const h = receiptFor(started);
  const { loader } = loaderFor({ [started.binding.attemptId]: h });
  await coordinator(loader).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'provision-test:reconcile' });
  const again = await start(account);
  assert.equal(again.alreadyProvisioned, true);
  assert.equal(again.operationId, started.binding.operationId);
  assert.equal(again.userId, h.userId);
  assert.equal(again.receiptId, h.receiptId);
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
});

test('account deletion is blocked while coordinator rows exist', async () => {
  const account = await freshAccount();
  await start(account);
  await assert.rejects(pool.query('DELETE FROM lakeside_accounts.account WHERE account_id=$1', [account.account_id]));
  assert.equal(await count('lakeside_accounts.provision_operation', 'WHERE account_id=$1', [account.account_id]), '1');
});

test('security version stays exact above the JavaScript safe integer range', async () => {
  const account = await freshAccount();
  await pool.query('UPDATE lakeside_accounts.account SET security_version=$1 WHERE account_id=$2', ['9007199254740993', account.account_id]);
  const started = await start(account);
  const { rows } = await pool.query('SELECT account_security_version FROM lakeside_accounts.provision_attempt WHERE attempt_id=$1', [started.binding.attemptId]);
  assert.equal(rows[0].account_security_version, '9007199254740993');
  const receipt = receiptFor(started);
  assert.equal((await coordinator(async () => receipt).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'test:exact-version' })).state, 'COMMITTED');
});

test('receipt mutation after validation cannot alter the transaction identity', async () => {
  const account = await freshAccount(); const started = await start(account);
  const receipt = receiptFor(started); const original = { ...receipt };
  let acquired = 0;
  const mutate = () => {
    acquired += 1;
    if (acquired === 2) { receipt.userId = randomUUID(); receipt.accountId = randomUUID(); receipt.receiptId = randomUUID(); }
  };
  pool.on('acquire', mutate);
  try {
    const result = await coordinator(async () => receipt).reconcileProvisionAttempt({ attemptId: started.binding.attemptId, provenance: 'test:frozen-receipt' });
    assert.ok(acquired >= 2); assert.equal(result.accountId, original.accountId); assert.equal(result.userId, original.userId); assert.equal(result.receiptId, original.receiptId);
  } finally { pool.off('acquire', mutate); }
});

test('database rejects inconsistent or extended immutable attempt bindings', async () => {
  const account = await freshAccount(); const started = await start(account); const b = started.binding;
  const variants = [
    x => ({ ...x, extra: true }), x => ({ ...x, accountId: randomUUID() }), x => ({ ...x, operationId: randomUUID() }),
    x => ({ ...x, realmId: 'other' }), x => ({ ...x, issuer: OTHER_ISSUER }), x => ({ ...x, username: 'wrong' }),
    x => ({ ...x, attemptId: randomUUID() }), x => ({ ...x, attemptGeneration: 3 }), x => ({ ...x, attemptGeneration: '2' }),
    x => ({ ...x, version: '1' }), x => ({ ...x, version: 2 }), x => ({ ...x, leaseTokenHash: 'bad' }),
    x => ({ ...x, leaseTokenHash: null }), x => ({ ...x, leaseExpiresAtMs: '123' }),
    x => ({ ...x, leaseExpiresAtMs: 0 }), x => ({ ...x, leaseExpiresAtMs: 9007199254740992 }),
  ];
  for (const mutate of variants) {
    const id = randomUUID(); const binding = mutate({ ...b, attemptId: id, attemptGeneration: 2 });
    await assert.rejects(pool.query(`INSERT INTO lakeside_accounts.provision_attempt
      (attempt_id,operation_id,account_id,attempt_generation,account_security_version,binding) VALUES($1,$2,$3,2,1,$4)`,
      [id, b.operationId, b.accountId, binding]));
  }
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE account_id=$1', [account.account_id]), '1');
});

test('database composite references reject cross-account attempt, pointer and subject ownership', async () => {
  const a = await freshAccount(); const b = await freshAccount(); const sa = await start(a); const sb = await start(b);
  const attemptId = randomUUID();
  await assert.rejects(pool.query(`INSERT INTO lakeside_accounts.provision_attempt
    (attempt_id,operation_id,account_id,attempt_generation,account_security_version,binding) VALUES($1,$2,$3,2,1,$4)`,
    [attemptId, sa.binding.operationId, b.account_id, { ...sa.binding, attemptId, accountId: b.account_id, attemptGeneration: 2 }]));
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query('DELETE FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1', [a.account_id]);
    await assert.rejects(client.query('UPDATE lakeside_accounts.provision_live_attempt SET operation_id=$1,attempt_id=$2 WHERE account_id=$3', [sa.binding.operationId, sa.binding.attemptId, b.account_id]));
  } finally { await client.query('ROLLBACK'); client.release(); }
  await assert.rejects(pool.query('INSERT INTO lakeside_accounts.provision_subject(account_id,user_id,issuer,realm_id,first_attempt_id) VALUES($1,$2,$3,$4,$5)', [b.account_id, randomUUID(), ISSUER, REALM, sa.binding.attemptId]));
  await assert.rejects(pool.query('INSERT INTO lakeside_accounts.provision_subject(account_id,user_id,issuer,realm_id,first_attempt_id) VALUES($1,$2,$3,$4,$5)', [b.account_id, randomUUID(), OTHER_ISSUER, REALM, sb.binding.attemptId]));
  await assert.rejects(pool.query('INSERT INTO lakeside_accounts.provision_subject(account_id,user_id,issuer,realm_id,first_attempt_id) VALUES($1,$2,$3,$4,$5)', [b.account_id, randomUUID(), ISSUER, 'wrong', sb.binding.attemptId]));
});

test('registry restart retains coordinator rows and migrations stay repeatable', async () => {
  const account = await freshAccount();
  const started = await start(account);
  await pool.end();
  pool = new pg.Pool({ database, max: 12, connectionTimeoutMillis: 2000, query_timeout: 10000, statement_timeout: 8000 });
  await migrate(pool);
  registry = createAccountRegistry(pool, options);
  assert.equal(await count('lakeside_accounts.provision_attempt', 'WHERE attempt_id=$1', [started.binding.attemptId]), '1');
  const resumed = await coordinator().startProvisionAttempt({ accountId: account.account_id, issuer: ISSUER, realmId: REALM, leaseMs: 60000, provenance: 'provision-test:resume' });
  assert.equal(resumed.reused, true);
  assert.deepEqual(resumed.binding.attemptId, started.binding.attemptId);
  await pool.query("UPDATE lakeside_accounts.migration SET checksum='unexpected' WHERE version=4");
  await assert.rejects(migrate(pool), /checksum differs/);
  const { readFile } = await import('node:fs/promises');
  const checksum = createHash('sha256').update(await readFile(new URL('./schema-004.sql', import.meta.url))).digest('hex');
  await pool.query('UPDATE lakeside_accounts.migration SET checksum=$1 WHERE version=4', [checksum]);
});
