# Account registry

Internal backend package for permanent Lakeside account IDs and existing game
login mappings. This package is not connected to production login yet.

`createAccountRegistry(pool, { allowedIssuers, allowedApplications })` exposes:

- `resolveOrCreateVerifiedIdentity({ issuer, subject }, provenance)` returns the
  existing account or creates one atomically. The caller must first validate the
  provider proof, including live revocation where required. The method name is a
  trust boundary, not a substitute for validation. Never expose it directly to
  browser-supplied identity fields.
- `mapApplicationIdentity(accountId, applicationId, localUserId, provenance)`
  preserves an existing application login ID. It requires independently proven
  ownership and an authorized migration/admin caller. It refuses to change
  either side of an existing mapping. Multiple characters should remain owned
  by the application's existing login record, not separate registry mappings.
- `findApplicationIdentity(accountId, applicationId)` resolves an active
  account's local login ID. Missing and suspended accounts return null. Database
  outages throw; callers must not authorize using a fallback identity.
- `getAccountSecurity(accountId)` reads current `account_id`, `status` and
  decimal-string `security_version` and `authentication_not_before`, or null for a missing account. Use the
  authoritative database on every authorization, without a cache or stale replica.
- `revokeAccountSessions(accountId, provenance)` requires an authorized security
  or recovery caller. It increments the version, advances the authentication cutoff
  and queues an audited event in
  one transaction. It does not change account ownership or terminate issuer SSO.
  Each successful invocation creates a new version; this is not an idempotent
  event-delivery endpoint.
- `suspendAccount(accountId, provenance)` requires an authorized administrative
  caller. The first suspension increments the security version and records a
  pending event atomically. Repeated suspension is idempotent. The Node adapter
  checks this state directly, so its next request rejects suspension without
  waiting for delivery. Existing production consumers are not migrated yet.

The registry is an ownership and security-state store, not a source-proof
verifier. A source cookie, profile field, or proof-shaped object does not
authorize an irreversible migration. The caller must establish fresh source
ownership, current source security, and the required admission order before
using a migration operation. See the
[source-proof admission order](../../integration/source-proof-admission-order.md)
and the current [source ownership proof reader](../auth-enrollment/source-proof-reader.md).

Issuer allowlists are exact and environment-specific. Subjects are opaque and
case-sensitive. Email is deliberately absent from the ownership schema. Two
provider identities do not become one account merely because a profile matches.
There is no public proof endpoint, account merge, unlink, or unsuspend interface
in this package. Verified linking is a trusted backend operation as described below.

`provenance` is a short non-secret audit reference such as a migration run ID or
verified-login correlation ID. Do not pass credentials, tokens or user profiles.
Audit records and pending delivery entries are transactional with each mutation.
The outbox has no dispatcher yet and must not be described as effective global
revocation. The new Node adapter enforces state/version directly, but issuer
sessions, standalone tokens and active stream termination still need integration.

## Storage and deployment boundary

Supply a `pg.Pool` for a dedicated Lakeside registry database. Do not install this
schema in Keycloak's database in production. The package uses a single checked
out connection per transaction and database locks for conflicting operations.

Run `migrate(pool)` explicitly with migration credentials before using the
registry. Migration version 1 is transactional, checksummed and safe to repeat;
changing an already applied schema file is an error. Future changes need new
versioned migrations. Runtime credentials should have only necessary table
access, not schema modification permissions. Production roles, database hosting,
backups, and event delivery remain rollout work.

No production routes, credentials, or account records are changed by the fixture.
Tests create a separate temporary database in the isolated compatibility
PostgreSQL container and drop it afterwards, including on test failure:

```sh
cd packages/account-registry
npm ci
cd ../../compat
# Run npm run init first if this is a fresh compatibility fixture.
docker compose run --rm registry-tests
docker compose stop
```

The real-database suite covers concurrent account creation, environment
separation, provider and case collisions, idempotent local-ID migration,
competing ownership claims, suspension, atomic audit failure rollback, connection
restart persistence, and migration checksum protection.


## Verified linking

`linkVerifiedIdentity({ primary, secondary }, provenance)` requires two separately
verified ownership proofs. The caller must validate signatures, audiences,
state/nonce/PKCE, browser intent and live session status before invoking it.
`primary` contains issuer, subject, accountId, securityVersion and authenticatedAt;
`secondary` contains issuer, subject and authenticatedAt. Both authentication times
must be within five minutes (at most 30 seconds future skew), checked again against
the database clock after locks are acquired. Email has no role.

Identity locks use the same first-login ordering; account status, current version
and primary identity ownership are checked under lock. An unclaimed secondary
identity is inserted with an audited security-version increment in one transaction.
Existing application mappings remain unchanged. An identity already owned by this
account is an idempotent no-op with fresh current proof; another owner produces
MappingConflictError. Missing/stale/mismatched primary proof produces
AccountProofError. Suspension produces AccountSuspendedError. Audit failure rolls
back both the link and version increment. This method cannot merge accounts or
transfer roles, entitlements or local ownership.

Two valid proof objects are not proof verification by themselves. Never expose
this method as a JSON endpoint accepting arbitrary browser claims. The Node OIDC
adapter supplies a browser-bound cross-authority ceremony; legacy non-OIDC
migration needs its own reviewed live-proof adapter.


Migration 2 adds an inclusive authentication cutoff in Unix seconds. Session
revocation and suspension advance it using the database wall clock in the same
transaction as the version increment, audit event and outbox row. `GREATEST`
prevents it moving backwards. Link proof for an existing account must be newer
than this cutoff even when the caller supplies the latest version. New accounts
start at zero; accounts changed before migration receive the migration-time cutoff.
Migration 1 remains unchanged and both migrations retain checksum verification.

A completed password reset must call the trusted revocation operation as part of
recovery orchestration; merely replacing an issuer password does not call it.
Issuing and delivering that recovery operation, issuer logout and notifications
remain separate integration work. The Node adapter checks this cutoff against
signed original authentication time, preventing old issuer SSO or a delayed login
callback from acquiring the current version after reset.


Migration 3 adds `recovery_hold`, separate from administrative suspension. The
registry reports effective status `suspended` while a hold is set, so the existing
mandatory adapter lookup denies access. Normal identity resolution, linking and
application mapping also reject held accounts. `findApplicationIdentity` returns
null while held. The recovery coordinator owns setting and releasing its hold;
releasing it never clears an administrative suspension. Apply this migration
before using account-recovery or cohort enrollment.

## Provision coordinator bind (migration 4)

Additive slice only. No production route is wired; the runtime is trusted
backend only. The registry does not verify source proof or perform source
admission. The source-proof reader documents exact durable-proof loading and
freshness checks, but proof transport, one-use consumption, current source
security, and admission remain caller and integration gates.

`createProvisionCoordinator(pool, { allowedProvisionIssuers,
loadProvisionReceipt, receiptTimeoutMs })` (re-exported from `index.mjs`)
exposes:

- `startProvisionAttempt({ accountId, issuer, realmId, leaseMs, provenance })`
  mints a fully bound attempt atomically in one transaction: stable operation
  UUID per account (reused), fresh attempt UUID, random 32-byte lease token
  (SHA-256 hash stored, raw token discarded), strictly-next generation, and
  DB-clock expiry (`leaseMs` 100..60000). No caller-selected IDs, hashes,
  or expiry. Returns `{ issuer, binding, reused }` for trusted provider
  dispatch, where `binding` is the exact Java `ProvisionBinding` shape
  (no `userId`, no issuer inside). An existing live attempt returns the same
  immutable binding (`reused: true`); even an expired one stays blocked and
  reusable for reconcile, never re-leased. A COMMITTED operation returns
  `{ alreadyProvisioned: true, ... }` and cannot start new. No browser
  endpoint.
- `reconcileProvisionAttempt({ attemptId, provenance })` reads the stored
  attempt, calls the injected loader OUTSIDE any transaction with a bounded
  timeout (default 5000 ms, allowed 10..10000, `AbortController`
  cancellation), then rechecks binding/live/evidence under lock and writes
  subject + evidence + mapping + audit + outbox atomically on one client.
  Missing, MUTATING, transport-failure, timeout, or malformed receipts are
  UNAVAILABLE and never abort or advance. ABORT evidence records containment
  only (no mapping) even during hold or version drift. COMMITTED mapping
  requires an active unheld account at the pinned `account_security_version`
  and fails closed with no writes otherwise, so a later retry can still land
  evidence. Identical evidence replays idempotently with no second audit row.

Receipt contract for `loadProvisionReceipt(binding, { signal })`: exactly the
Java `AccountProvisionContract.Receipt` keys (`accountId`, `operationId`,
`realmId`, `username`, `userId`, `attemptId`, `attemptGeneration`,
`leaseTokenHash`, `leaseExpiresAtMs`, `receiptId`, `state`) plus the exact
`issuer` the trusted reader authenticated. `username` must equal
`lakeside:<accountId>`; `attemptGeneration` and `leaseExpiresAtMs` must be
safe integers (generation capped at 2^53-1 to avoid Java long/JS ambiguity);
UUIDs lowercase canonical; lease hash 64-hex. No extra keys (arrays and
unknown fields are malformed). The injected loader is the trust boundary, not
the authenticated transport proof itself; the separate server-side SQL reader supplies durable evidence.
Issuer/realm correspondence is trusted deployment config; the realm is never
guessed from the URL. `allowedProvisionIssuers` entries are exact HTTPS with
no credentials, query, or fragment, including empty delimiters.

Locking follows the existing identity-first order: advisory lock on
`[issuer, receipt.userId]`, then account `FOR UPDATE`, then attempt
`FOR UPDATE`, so concurrent first-login/link work on the same identity
serializes instead of deadlocking. Account deletion is blocked while
coordinator rows exist (all FKs NO ACTION, no cascade), matching existing
registry tables.

Isolated tests live in `provision-bind.test.mjs` (same random-DB pattern as
`test.mjs`). Run both suites without restarting the issuer overlay:

```sh
cd compat
# Run npm run init first if this is a fresh compatibility fixture.
docker compose run --rm --no-deps registry-tests node --test test.mjs provision-bind.test.mjs
```

The bounded trusted wrapper in
[provision-workflow.md](./provision-workflow.md) composes this coordinator
with a one-shot dispatcher. Its `provisionDisabledAccount` method dispatches
only the coordinator's immutable binding and reconciles provider evidence,
including after an ambiguous provider response. A dispatcher candidate is never treated as a
durable receipt, and the wrapper never enables a user or changes source
authentication. Run its unit suite separately:

```sh
node --unhandled-rejections=strict --test provision-workflow.test.mjs
```
