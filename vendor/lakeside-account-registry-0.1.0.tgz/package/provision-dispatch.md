# Provision dispatch adapter

`createProvisionDispatcher` is a trusted backend transport adapter for the
existing `createProvisionCoordinator` binding. It does not start or reconcile
an operation, mutate the registry, or treat an issuer response as durable
receipt evidence. The caller must call the coordinator's authenticated receipt
reader and reconciliation path after this adapter returns or reports an
ambiguous outcome.

```js
import { createProvisionDispatcher } from './provision-dispatch.mjs';

const dispatcher = createProvisionDispatcher({
  endpoint: 'https://issuer.example.invalid/private/account-provision',
  issuer: 'https://issuer.example.invalid/realms/lakeside',
  realmId: 'lakeside-fixture',
  obtainAccessToken: ({ signal }) => tokenProvider({ signal }),
});
const candidate = await dispatcher.provision(started.binding, { signal });
// await dispatcher.abort(started.binding, { signal }) is the containment path.
```

`endpoint` is an explicit pinned HTTPS base. The adapter appends exactly
`/provision` or `/abort`. It rejects credentials, query strings, fragments,
HTTP, redirects, and discovery. There is no option to disable TLS verification. `obtainAccessToken` is an
injected trusted provider and receives only the cooperative signal. The adapter
never mints or logs a bearer token and never calls it when the binding fails
validation.

The JSON request has exactly these keys:

```json
{
  "accountId": "canonical UUID",
  "operationId": "stable UUID",
  "attemptId": "attempt UUID",
  "attemptGeneration": "decimal string",
  "attemptLeaseTokenHash": "lowercase SHA-256 hex",
  "attemptExpiresAtMs": 4102444800000
}
```

Issuer, realm, version, username, and user ID are trusted coordinator fields
and are deliberately excluded from the request. The configured issuer, realm,
and canonical `lakeside:<accountId>` username are checked against the binding
before dispatch. A 200 JSON response must have exactly `{ state, receiptId,
userId }`. The candidate states are `COMMITTED`, `ABORTED`, and
`REPLAY_NO_MUTATION`; `PROCEED` is rejected because it is an in-transaction
permit, not a completed service result. The returned object is frozen metadata,
not an authenticated receipt.

The total token, request, and bounded response-reading deadline defaults to
five seconds. Response bodies are limited to 16 KiB. There are no automatic
HTTP retries. `ProvisionDispatchError.requestMayHaveReachedIssuer` is false
for local binding and token-provider failures. It is true for every transport,
response, stream, timeout, redirect, or HTTP-status failure after fetch starts,
so callers must reconcile rather than assume abort or retry safety. The adapter
uses standard platform TLS verification through `fetch` and has no insecure
fixture mode.

The adjacent tests are injected-fetch unit tests. They cover exact wire fields,
validation ordering, hostile endpoint and response inputs, redirects, token
and fetch deadlines, parent cancellation, ambiguity classification, and bounded
response streams. Streams that arrive after cancellation are canceled; immutable JavaScript bearer strings have no erasure guarantee. Provider-side receipt authentication, deployment endpoint
configuration, and production transport remain integration gates.

Guarded integration coverage now includes a real OAuth token and provisioning
request in `compat/provision-transport.test.mjs`, plus actual default-fetch HTTPS
certificate validation in `compat/provision-client-tls.test.mjs`. These isolated
fixtures do not configure production endpoints or machine credentials.
