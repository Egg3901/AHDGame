import test from 'node:test';
import assert from 'node:assert/strict';
import { createProvisionAccessTokenProvider, ProvisionAccessTokenError } from './provision-access-token.mjs';

const endpoint = 'https://issuer.example.invalid/realms/lakeside/protocol/openid-connect/token';
const config = { tokenEndpoint: endpoint, clientId: 'provision-client', clientSecret: 'synthetic-client-secret' };

function tokenBody(overrides = {}) {
  return JSON.stringify({ access_token: 'opaque-token-123', token_type: 'Bearer', expires_in: 60, ...overrides });
}

function response(body = tokenBody(), { status = 200, contentType = 'application/json' } = {}) {
  return new Response(body, { status, headers: { 'content-type': contentType } });
}

function provider(overrides = {}) {
  return createProvisionAccessTokenProvider({
    ...config,
    timeoutMs: 200,
    fetchImpl: async () => response(),
    ...overrides,
  });
}

test('sends client_credentials with exact body and standard redirect policy', async () => {
  let seen;
  const p = provider({ fetchImpl: async (url, options) => { seen = { url, options }; return response(); } });
  assert.equal(await p.obtainAccessToken(), 'opaque-token-123');
  assert.equal(seen.url, endpoint);
  assert.equal(seen.options.method, 'POST');
  assert.equal(seen.options.redirect, 'error');
  assert.ok(seen.options.signal instanceof AbortSignal);
  assert.equal(seen.options.headers.accept, 'application/json');
  assert.equal(seen.options.headers['content-type'], 'application/x-www-form-urlencoded');
  assert.deepEqual(Object.fromEntries(new URLSearchParams(seen.options.body)), { grant_type: 'client_credentials' });
  assert.equal(seen.options.body.includes('client_id'), false);
  assert.equal(seen.options.body.includes('client_secret'), false);
});

test('form-encodes reserved client credentials before Basic encoding', async () => {
  const reservedId = 'client:reserved/+?& =%~!';
  const reservedSecret = 'secret:/+?& =%~!';
  let seen;
  const p = provider({
    clientId: reservedId,
    clientSecret: reservedSecret,
    fetchImpl: async (_url, options) => { seen = options; return response(); },
  });
  await p.obtainAccessToken();
  assert.equal(seen.headers.authorization, 'Basic Y2xpZW50JTNBcmVzZXJ2ZWQlMkYlMkIlM0YlMjYrJTNEJTI1JTdFJTIxOnNlY3JldCUzQSUyRiUyQiUzRiUyNislM0QlMjUlN0UlMjE=');
  assert.equal(seen.body.includes('client_secret'), false);
});

test('adds only an explicit space-delimited scope to the form body', async () => {
  let body;
  const p = provider({ scope: 'provision:write audit.read', fetchImpl: async (_url, options) => { body = options.body; return response(); } });
  await p.obtainAccessToken();
  assert.deepEqual(Object.fromEntries(new URLSearchParams(body)), { grant_type: 'client_credentials', scope: 'provision:write audit.read' });
  for (const scope of ['', ' read', 'read ', 'read  write', 'read\nwrite', 'read"write', { toString: () => 'read' }]) {
    assert.throws(() => provider({ scope }), TypeError);
  }
});

test('requires an explicit pinned HTTPS endpoint and bounded credentials', () => {
  for (const changed of [
    { tokenEndpoint: 'http://issuer.example.invalid/token' },
    { tokenEndpoint: endpoint + '?' },
    { tokenEndpoint: endpoint + '#fragment' },
    { tokenEndpoint: 'https://user:secret@issuer.example.invalid/token' },
    { tokenEndpoint: 'https://issuer.example.invalid/token', clientId: '' },
    { tokenEndpoint: 'https://issuer.example.invalid/token', clientSecret: '' },
    { tokenEndpoint: 'https://issuer.example.invalid/token', clientSecret: 'secret\nvalue' },
    { tokenEndpoint: 'https://issuer.example.invalid/token', timeoutMs: 99 },
    { tokenEndpoint: 'https://issuer.example.invalid/token', timeoutMs: 5001 },
  ]) assert.throws(() => provider(changed), TypeError);
});

test('mints independently on every call without caching', async () => {
  let calls = 0;
  const p = provider({ fetchImpl: async () => { calls += 1; return response(tokenBody({ access_token: `token-${calls}` })); } });
  assert.equal(await p.obtainAccessToken(), 'token-1');
  assert.equal(await p.obtainAccessToken(), 'token-2');
  assert.equal(calls, 2);
});

test('rejects redirects, HTTP failures, and wrong content type while canceling bodies', async () => {
  let canceled = 0;
  const body = () => new ReadableStream({ cancel() { canceled += 1; } });
  await assert.rejects(provider({ fetchImpl: async () => ({ redirected: true, status: 200, headers: new Headers({ 'content-type': 'application/json' }), body: body() }) }).obtainAccessToken(),
    error => error instanceof ProvisionAccessTokenError && error.code === 'redirect');
  await assert.rejects(provider({ fetchImpl: async () => new Response(body(), { status: 429, headers: { 'content-type': 'application/json' } }) }).obtainAccessToken(),
    error => error.code === 'http');
  await assert.rejects(provider({ fetchImpl: async () => new Response(body(), { status: 500, headers: { 'content-type': 'text/plain' } }) }).obtainAccessToken(),
    error => error.code === 'http');
  await assert.rejects(provider({ fetchImpl: async () => new Response(body(), { status: 200, headers: { 'content-type': 'text/plain' } }) }).obtainAccessToken(),
    error => error.code === 'content_type');
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(canceled, 4);
});

test('rejects text-only adapters and invalid UTF-8 without unbounded text fallback', async () => {
  let textCalls = 0;
  await assert.rejects(provider({ fetchImpl: async () => ({ status: 200, headers: new Headers({ 'content-type': 'application/json' }), text: async () => { textCalls += 1; return tokenBody(); } }) }).obtainAccessToken(),
    error => error.code === 'body');
  assert.equal(textCalls, 0);
  await assert.rejects(provider({ fetchImpl: async () => new Response(Uint8Array.from([0xc3, 0x28]), { headers: { 'content-type': 'application/json' } }) }).obtainAccessToken(),
    error => error.code === 'body');
});

test('validates bearer token syntax, token type, expiry, and duplicate keys', async () => {
  for (const overrides of [
    { access_token: '' },
    { access_token: 'token with spaces' },
    { access_token: 'token\n' },
    { access_token: 'é' },
    { access_token: 'x'.repeat(8193) },
    { token_type: 'Basic' },
    { token_type: 'Bearer ' },
    { expires_in: 0 },
    { expires_in: -1 },
    { expires_in: 3601 },
    { expires_in: 1.5 },
    { expires_in: '60' },
  ]) {
    await assert.rejects(provider({ fetchImpl: async () => response(tokenBody(overrides)) }).obtainAccessToken(), error => error.code === 'invalid');
  }
  const duplicate = '{"access_token":"first","access\\u005ftoken":"second","token_type":"Bearer","expires_in":60}';
  await assert.rejects(provider({ fetchImpl: async () => response(duplicate) }).obtainAccessToken(), error => error.code === 'body');
  assert.equal(await provider({ fetchImpl: async () => response(tokenBody({ token_type: 'bEaReR' })) }).obtainAccessToken(), 'opaque-token-123');
});

test('bounds the streamed body and rejects trailing line separators in tokens', async () => {
  const tooLarge = new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(16 * 1024 + 1)); controller.close(); } });
  await assert.rejects(provider({ fetchImpl: async () => new Response(tooLarge, { headers: { 'content-type': 'application/json' } }) }).obtainAccessToken(),
    error => error.code === 'body_too_large');
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    await assert.rejects(provider({ fetchImpl: async () => response(tokenBody({ access_token: `token${suffix}` })) }).obtainAccessToken(),
      error => error.code === 'invalid');
  }
});

test('timeout and parent abort bound ignored fetches without leaking late responses', async () => {
  let resolveFetch;
  const pending = provider({ timeoutMs: 100, fetchImpl: () => new Promise(resolve => { resolveFetch = resolve; }) }).obtainAccessToken();
  await assert.rejects(pending, error => error.code === 'timeout');
  let canceled = 0;
  resolveFetch(new Response(new ReadableStream({ cancel() { canceled += 1; } }), { headers: { 'content-type': 'application/json' } }));
  await new Promise(resolve => setTimeout(resolve, 10));
  assert.equal(canceled, 1);

  const controller = new AbortController();
  const p = provider({ fetchImpl: () => new Promise(() => {}) }).obtainAccessToken({ signal: controller.signal });
  setTimeout(() => controller.abort(), 10);
  await assert.rejects(p, error => error.code === 'aborted');
});

test('sanitizes injected transport failures and validates caller signals', async () => {
  const secret = 'synthetic-provider-secret-must-not-escape';
  await assert.rejects(provider({ fetchImpl: async () => { throw new Error(secret); } }).obtainAccessToken(), error =>
    error instanceof ProvisionAccessTokenError && error.code === 'transport' && !error.message.includes(secret));
  const controller = new AbortController();
  controller.abort();
  let calls = 0;
  await assert.rejects(provider({ fetchImpl: async () => { calls += 1; return response(); } }).obtainAccessToken({ signal: controller.signal }), error => error.code === 'aborted');
  assert.equal(calls, 0);
  await assert.rejects(provider().obtainAccessToken({ signal: {} }), TypeError);
});

test('stream failures cannot leak altered typed-error messages or hostile code getters', async () => {
  for (const hostile of [false, true]) {
    const injected = new ProvisionAccessTokenError('body');
    injected.message = 'synthetic-secret-in-stream';
    if (hostile) Object.defineProperty(injected, 'code', { get() { throw new Error('synthetic-secret-in-getter'); } });
    const p = provider({ fetchImpl: async () => ({ status: 200, redirected: false,
      headers: new Headers({ 'content-type': 'application/json' }),
      body: { getReader: () => ({ read: async () => { throw injected; }, cancel: async () => {}, releaseLock() {} }) },
    }) });
    await assert.rejects(p.obtainAccessToken(), e => e instanceof ProvisionAccessTokenError && e.code === 'body' && !e.message.includes('synthetic-secret'));
  }
});
test('rejects ill-formed credential strings before form encoding can replace them', () => {
  for (const key of ['clientId', 'clientSecret']) {
    assert.throws(() => provider({ [key]: 'bad\ud800value' }), TypeError);
  }
});
