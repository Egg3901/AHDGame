import { ProvisionConflictError, ProvisionUnavailableError } from './provision-bind.mjs';

const UUID_RE = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?![\s\S])/u;
const HASH_RE = /^(?:[0-9a-f]{64})(?![\s\S])/u;
const CONTROL_RE = /[\u0000-\u001f\u007f\u2028\u2029]/u;
const BINDING_KEYS = ['accountId', 'attemptGeneration', 'attemptId', 'issuer', 'leaseExpiresAtMs', 'leaseTokenHash', 'operationId', 'realmId', 'username', 'version'];
const CANDIDATE_KEYS = ['receiptId', 'state', 'userId'];
const TERMINAL_STATES = new Set(['COMMITTED', 'ABORTED']);
const CANDIDATE_STATES = new Set(['COMMITTED', 'ABORTED', 'REPLAY_NO_MUTATION']);
const WORKFLOW_MESSAGES = Object.freeze({
  aborted: 'Provision workflow was aborted',
  conflict: 'Provision workflow conflicts with durable state',
  coordinator_unavailable: 'Provision coordinator outcome is unavailable',
  invalid_input: 'Provision workflow input was invalid',
  invalid_result: 'Provision workflow received an invalid result',
});

/** Errors from this wrapper contain only local, fixed messages and codes. */
export class ProvisionWorkflowError extends Error {
  constructor(code = 'coordinator_unavailable') {
    const safeCode = typeof code === 'string' && Object.hasOwn(WORKFLOW_MESSAGES, code) ? code : 'coordinator_unavailable';
    super(WORKFLOW_MESSAGES[safeCode]);
    this.name = 'ProvisionWorkflowError';
    this.code = safeCode;
    Object.freeze(this);
  }
}

function workflowError(code) {
  return new ProvisionWorkflowError(code);
}

function exactKeys(value, expected) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
  const keys = Object.keys(value).sort();
  return keys.length === expected.length && expected.every(key => keys.includes(key));
}

// Read each trusted adapter result once before validation or another await.
// Accessors are not data and cannot change a checked binding during copying.
function captureRecord(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw workflowError('invalid_result');
  const result = {};
  for (const [key, descriptor] of Object.entries(Object.getOwnPropertyDescriptors(value))) {
    if (!Object.hasOwn(descriptor, 'value') || !descriptor.enumerable) throw workflowError('invalid_result');
    Object.defineProperty(result, key, { value: descriptor.value, enumerable: true });
  }
  return Object.freeze(result);
}

function uuid(value) {
  return typeof value === 'string' && value.length === 36 && UUID_RE.test(value) && value === value.toLowerCase();
}

function text(value, max) {
  return typeof value === 'string' && value.length > 0 && value.length <= max && value === value.trim() && value.isWellFormed() && !CONTROL_RE.test(value);
}

function issuer(value) {
  if (!text(value, 512)) return false;
  let parsed;
  try { parsed = new URL(value); } catch { return false; }
  return parsed.protocol === 'https:' && !parsed.username && !parsed.password && !parsed.search && !parsed.hash
    && !value.includes('?') && !value.includes('#') && !value.includes('@') && parsed.href === value;
}

function positiveSafeInteger(value) {
  return typeof value === 'number' && Number.isSafeInteger(value) && value > 0;
}

function canonicalUsername(accountId) {
  return `lakeside:${accountId}`;
}

function validateBinding(raw, accountId, configuredIssuer, configuredRealm) {
  raw = captureRecord(raw);
  if (!exactKeys(raw, BINDING_KEYS) || raw.version !== 1 || raw.accountId !== accountId
      || raw.issuer !== configuredIssuer || raw.realmId !== configuredRealm
      || raw.username !== canonicalUsername(accountId) || !uuid(raw.operationId) || !uuid(raw.attemptId)
      || !positiveSafeInteger(raw.attemptGeneration)
      || typeof raw.leaseTokenHash !== 'string' || raw.leaseTokenHash.length !== 64 || !HASH_RE.test(raw.leaseTokenHash)
      || !positiveSafeInteger(raw.leaseExpiresAtMs)) {
    throw workflowError('invalid_result');
  }
  return Object.freeze({
    version: 1,
    accountId: raw.accountId,
    operationId: raw.operationId,
    issuer: raw.issuer,
    realmId: raw.realmId,
    username: raw.username,
    attemptId: raw.attemptId,
    attemptGeneration: raw.attemptGeneration,
    leaseTokenHash: raw.leaseTokenHash,
    leaseExpiresAtMs: raw.leaseExpiresAtMs,
  });
}

function validateAlreadyProvisioned(raw, accountId, configuredIssuer, configuredRealm) {
  if (raw.alreadyProvisioned !== true || raw.accountId !== accountId || raw.issuer !== configuredIssuer
      || raw.realmId !== configuredRealm || raw.username !== canonicalUsername(accountId)
      || !uuid(raw.operationId) || !uuid(raw.attemptId) || !uuid(raw.userId) || !uuid(raw.receiptId)) {
    throw workflowError('invalid_result');
  }
  return Object.freeze({
    state: 'COMMITTED',
    accountId,
    operationId: raw.operationId,
    attemptId: raw.attemptId,
    receiptId: raw.receiptId,
    userId: raw.userId,
    issuer: configuredIssuer,
    replay: true,
  });
}

function validateStart(raw, accountId, configuredIssuer, configuredRealm) {
  raw = captureRecord(raw);
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw workflowError('invalid_result');
  if (raw.alreadyProvisioned === true) return { kind: 'terminal', result: validateAlreadyProvisioned(raw, accountId, configuredIssuer, configuredRealm) };
  if (raw.reused !== true && raw.reused !== false) throw workflowError('invalid_result');
  if (raw.issuer !== configuredIssuer) throw workflowError('invalid_result');
  return {
    kind: raw.reused ? 'reused' : 'fresh',
    binding: validateBinding(raw.binding, accountId, configuredIssuer, configuredRealm),
  };
}

function validateTerminal(raw, binding) {
  raw = captureRecord(raw);
  if (!raw || typeof raw !== 'object' || Array.isArray(raw) || !TERMINAL_STATES.has(raw.state)
      || raw.accountId !== binding.accountId || raw.operationId !== binding.operationId
      || raw.attemptId !== binding.attemptId || raw.attemptGeneration !== binding.attemptGeneration
      || raw.issuer !== binding.issuer || !uuid(raw.receiptId) || !uuid(raw.userId)
      || (raw.replay !== undefined && typeof raw.replay !== 'boolean')) {
    throw workflowError('invalid_result');
  }
  return Object.freeze({
    state: raw.state,
    accountId: raw.accountId,
    operationId: raw.operationId,
    attemptId: raw.attemptId,
    attemptGeneration: raw.attemptGeneration,
    receiptId: raw.receiptId,
    userId: raw.userId,
    issuer: raw.issuer,
    replay: raw.replay === true,
  });
}

function validateCandidate(raw) {
  raw = captureRecord(raw);
  if (!exactKeys(raw, CANDIDATE_KEYS) || !CANDIDATE_STATES.has(raw.state) || !uuid(raw.receiptId) || !uuid(raw.userId)) {
    throw workflowError('invalid_result');
  }
  return Object.freeze({ state: raw.state, receiptId: raw.receiptId, userId: raw.userId });
}

function pending(binding, reason) {
  return Object.freeze({
    state: 'PENDING',
    accountId: binding.accountId,
    operationId: binding.operationId,
    attemptId: binding.attemptId,
    attemptGeneration: binding.attemptGeneration,
    issuer: binding.issuer,
    reason,
  });
}

function classifyCoordinatorError(caught) {
  try {
    if (caught instanceof ProvisionConflictError) return 'conflict';
    if (caught instanceof ProvisionUnavailableError) return 'unavailable';
  } catch {}
  return 'unknown';
}

function validateInput(raw, configuredIssuer, configuredRealm, configuredLeaseMs) {
  try {
    raw = captureRecord(raw);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) throw workflowError('invalid_input');
    const keys = Object.keys(raw).sort();
    if (!(keys.length === 2 || keys.length === 3) || !keys.includes('accountId') || !keys.includes('provenance')
        || (keys.length === 3 && !keys.includes('signal'))) throw workflowError('invalid_input');
    if (!uuid(raw.accountId) || !text(raw.provenance, 256)) throw workflowError('invalid_input');
    if (raw.signal !== undefined && (!raw.signal || typeof raw.signal !== 'object'
        || typeof raw.signal.addEventListener !== 'function' || typeof raw.signal.removeEventListener !== 'function')) {
      throw workflowError('invalid_input');
    }
    if (!issuer(configuredIssuer) || !text(configuredRealm, 255) || !Number.isSafeInteger(configuredLeaseMs)
        || configuredLeaseMs < 100 || configuredLeaseMs > 60000) throw workflowError('invalid_input');
    return Object.freeze({ accountId: raw.accountId, provenance: raw.provenance, signal: raw.signal });
  } catch {
    throw workflowError('invalid_input');
  }
}

function signalAborted(signal) {
  try { return signal?.aborted === true; } catch { throw workflowError('invalid_input'); }
}

/**
 * Compose the durable coordinator and the one-shot issuer dispatcher. This
 * wrapper never enables a user, starts enrollment, fences a source, retries a
 * provider call, or treats a dispatcher candidate as proof.
 */
export function createProvisionWorkflow({ coordinator, dispatcher, issuer: configuredIssuer, realmId: configuredRealm, leaseMs } = {}) {
  if (!coordinator || typeof coordinator.startProvisionAttempt !== 'function'
      || typeof coordinator.reconcileProvisionAttempt !== 'function'
      || !dispatcher || typeof dispatcher.provision !== 'function') {
    throw new TypeError('Provision coordinator and dispatcher are required');
  }
  if (!issuer(configuredIssuer)) throw new TypeError('Invalid provision issuer');
  if (!text(configuredRealm, 255)) throw new TypeError('Invalid provision realm');
  if (!Number.isSafeInteger(leaseMs) || leaseMs < 100 || leaseMs > 60000) throw new TypeError('Invalid provision lease duration');
  const startProvisionAttempt = coordinator.startProvisionAttempt.bind(coordinator);
  const reconcileProvisionAttempt = coordinator.reconcileProvisionAttempt.bind(coordinator);
  const dispatchProvision = dispatcher.provision.bind(dispatcher);

  async function reconcile(binding, provenance) {
    let raw;
    try {
      raw = await reconcileProvisionAttempt({ attemptId: binding.attemptId, provenance });
    } catch (caught) {
      const kind = classifyCoordinatorError(caught);
      if (kind === 'conflict') return { kind: 'conflict' };
      if (kind === 'unavailable') return { kind: 'unavailable' };
      return { kind: 'unknown' };
    }
    try {
      return { kind: 'terminal', result: validateTerminal(raw, binding) };
    } catch {
      return { kind: 'invalid' };
    }
  }

  async function dispatchOnce(binding, signal) {
    try {
      const raw = await dispatchProvision(binding, { signal });
      // Copy and validate synchronously before the next await. The candidate
      // is intentionally discarded because only coordinator evidence proves a
      // durable outcome.
      validateCandidate(raw);
    } catch {
      // Every candidate or dispatch failure is followed by reconciliation.
      // The injected error is never inspected or returned.
    }
  }

  async function provisionDisabledAccount(rawInput) {
    const input = validateInput(rawInput, configuredIssuer, configuredRealm, leaseMs);
    if (signalAborted(input.signal)) throw workflowError('aborted');

    let startedRaw;
    try {
      startedRaw = await startProvisionAttempt({
        accountId: input.accountId,
        issuer: configuredIssuer,
        realmId: configuredRealm,
        leaseMs,
        provenance: input.provenance,
      });
    } catch (caught) {
      if (classifyCoordinatorError(caught) === 'conflict') throw workflowError('conflict');
      throw workflowError('coordinator_unavailable');
    }

    let started;
    try {
      started = validateStart(startedRaw, input.accountId, configuredIssuer, configuredRealm);
    } catch {
      throw workflowError('invalid_result');
    }
    if (started.kind === 'terminal') return started.result;

    if (started.kind === 'reused') {
      const initial = await reconcile(started.binding, input.provenance);
      if (initial.kind === 'terminal') return initial.result;
      if (initial.kind === 'conflict') throw workflowError('conflict');
      if (initial.kind === 'invalid') throw workflowError('invalid_result');
      // Only unavailable receipt evidence permits a dispatch of a reused
      // binding. Unknown coordinator failures remain pending and do not open
      // a second issuer side effect.
      if (initial.kind !== 'unavailable') return pending(started.binding, 'coordinator_unavailable');
    }

    // A caller cancellation after start must not launch a new provider call.
    // Reconciliation still runs so a concurrent authority's durable commit is
    // observed instead of being hidden by the caller's cancellation.
    if (!signalAborted(input.signal)) await dispatchOnce(started.binding, input.signal);
    const final = await reconcile(started.binding, input.provenance);
    if (final.kind === 'terminal') return final.result;
    if (final.kind === 'conflict') throw workflowError('conflict');
    if (final.kind === 'invalid') throw workflowError('invalid_result');
    return pending(started.binding, final.kind === 'unavailable' ? 'receipt_unavailable' : 'coordinator_unavailable');
  }

  return Object.freeze({ provisionDisabledAccount });
}
