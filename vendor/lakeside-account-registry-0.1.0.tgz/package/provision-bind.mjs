import { randomBytes, randomUUID, createHash } from 'node:crypto';

export class ProvisionConflictError extends Error {
  constructor(message = 'Provision binding conflicts with durable coordinator state') { super(message); this.name = 'ProvisionConflictError'; }
}
export class ProvisionUnavailableError extends Error {
  constructor(message = 'Authenticated provision receipt is unavailable') { super(message); this.name = 'ProvisionUnavailableError'; }
}

const MAX_SAFE_GENERATION = Number.MAX_SAFE_INTEGER;
const PG_BIGINT_MAX = 9223372036854775807n;
// The negative end assertion sees every code unit, including final line
// separators.  A plain `$` would also match immediately before one.
const UUID_RE = /^(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?![\s\S])/u;
const HEX64_RE = /^(?:[0-9a-f]{64})(?![\s\S])/u;
const BINDING_KEYS = ['version', 'accountId', 'operationId', 'issuer', 'realmId', 'username', 'attemptId', 'attemptGeneration', 'leaseTokenHash', 'leaseExpiresAtMs'];
// Exact authenticated receipt shape: Java AccountProvisionContract.Receipt
// keys plus the exact issuer attached by the trusted reader.
const RECEIPT_KEYS = ['accountId', 'operationId', 'realmId', 'username', 'userId', 'attemptId', 'attemptGeneration', 'leaseTokenHash', 'leaseExpiresAtMs', 'receiptId', 'state', 'issuer'];
// Trusted dispatch mapping (coordinator binding -> Java wire input):
// leaseTokenHash -> attemptLeaseTokenHash, leaseExpiresAtMs ->
// attemptExpiresAtMs; issuer and version are coordinator-only and are
// excluded from the Java ProvisionBinding; userId is never in the binding.
// The returned binding is the internal coordinator shape, not a literal
// Java wire input.

function uuid(value, label) {
  if (typeof value !== 'string' || value.length !== 36 || !UUID_RE.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}
function accountId(value) {
  return uuid(value, 'account ID');
}
function nonempty(value, max, label) {
  if (typeof value !== 'string' || !value.trim() || value.length > max || /[\u0000-\u001f\u007f\u2028\u2029]/u.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}
function realmId(value) {
  return nonempty(value, 255, 'realm ID');
}
// Exact HTTPS issuer, no canonicalization. Rejects credentials, query,
// fragment including empty delimiters ('https://h/?', 'https://h/#'),
// control characters and overlong values. Correspondence between a
// configured issuer and realmId is trusted deployment config; the realm is
// never guessed from the issuer URL.
function provisionIssuer(value, allowlist) {
  nonempty(value, 512, 'provision issuer');
  let parsed;
  try { parsed = new URL(value); } catch { throw new TypeError('Invalid provision issuer'); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new TypeError('Invalid provision issuer');
  if (value.includes('?') || value.includes('#') || value.includes('@')) throw new TypeError('Invalid provision issuer');
  if (parsed.host !== value.slice('https://'.length).split('/')[0]) throw new TypeError('Invalid provision issuer');
  if (!allowlist.has(value)) throw new ProvisionConflictError('Untrusted provision issuer');
  return value;
}
function safePositiveInt(value, label, max = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0 || value > max) throw new TypeError(`Invalid ${label}`);
  return value;
}
function hashHex(value, label) {
  if (typeof value !== 'string' || value.length !== 64 || !HEX64_RE.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}
// Validated positive PG bigint as a decimal string (1..9223372036854775807).
// Never converts through Number, so values above 2^53 stay exact.
function bigintText(value, label) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 19
      || value[0] < '1' || value[0] > '9'
      || [...value].slice(1).some(character => character < '0' || character > '9')) {
    throw new TypeError(`Invalid ${label}`);
  }
  if (BigInt(value) > PG_BIGINT_MAX) throw new TypeError(`Invalid ${label}`);
  return value;
}
function canonicalUsername(id) {
  return `lakeside:${accountId(id)}`;
}
function fingerprint(parts) {
  return createHash('sha256').update(JSON.stringify(parts)).digest('hex');
}
function freeze(value) {
  return Object.freeze({ ...value });
}

async function transaction(pool, operation) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query("SET LOCAL lock_timeout = '5s'");
    await client.query("SET LOCAL statement_timeout = '10s'");
    const result = await operation(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    await client.query('ROLLBACK');
    throw error;
  } finally { client.release(); }
}
async function event(client, id, action, provenance) {
  const eventId = randomUUID();
  await client.query('INSERT INTO lakeside_accounts.audit_event(event_id, account_id, action, provenance) VALUES ($1,$2,$3,$4)', [eventId, id, action, provenance]);
  await client.query('INSERT INTO lakeside_accounts.outbox(event_id) VALUES ($1)', [eventId]);
}

// Pure pre-transaction receipt validation. Anything malformed, MUTATING, or
// off-contract is unavailable evidence: it never aborts, never advances,
// and never reaches the coordinator transaction. Returns a frozen snapshot
// copy of the validated primitives, never the loader's mutable object, so a
// later loader mutation cannot alter fingerprint, locks, or writes.
function checkReceiptShape(receipt, allowlist) {
  if (!receipt || typeof receipt !== 'object' || Array.isArray(receipt)) throw new ProvisionUnavailableError();
  const keys = Object.keys(receipt).sort();
  if (keys.length !== RECEIPT_KEYS.length || !RECEIPT_KEYS.every(key => keys.includes(key))) throw new ProvisionUnavailableError();
  uuid(receipt.accountId, 'receipt account ID');
  uuid(receipt.operationId, 'receipt operation ID');
  realmId(receipt.realmId);
  nonempty(receipt.username, 255, 'receipt username');
  uuid(receipt.userId, 'receipt user ID');
  uuid(receipt.attemptId, 'receipt attempt ID');
  safePositiveInt(receipt.attemptGeneration, 'receipt generation', MAX_SAFE_GENERATION);
  hashHex(receipt.leaseTokenHash, 'receipt lease hash');
  safePositiveInt(receipt.leaseExpiresAtMs, 'receipt lease expiry');
  uuid(receipt.receiptId, 'receipt ID');
  if (receipt.state !== 'COMMITTED' && receipt.state !== 'ABORTED' && receipt.state !== 'MUTATING') throw new ProvisionUnavailableError();
  if (typeof receipt.issuer !== 'string' || !allowlist.has(receipt.issuer)) throw new ProvisionUnavailableError();
  if (receipt.username !== canonicalUsername(receipt.accountId)) throw new ProvisionUnavailableError();
  return Object.freeze({
    accountId: receipt.accountId,
    operationId: receipt.operationId,
    realmId: receipt.realmId,
    username: receipt.username,
    userId: receipt.userId,
    attemptId: receipt.attemptId,
    attemptGeneration: receipt.attemptGeneration,
    leaseTokenHash: receipt.leaseTokenHash,
    leaseExpiresAtMs: receipt.leaseExpiresAtMs,
    receiptId: receipt.receiptId,
    state: receipt.state,
    issuer: receipt.issuer,
  });
}

function checkBindingMatch(stored, receipt) {
  if (stored.version !== 1 || stored.accountId !== receipt.accountId || stored.operationId !== receipt.operationId
    || stored.issuer !== receipt.issuer || stored.realmId !== receipt.realmId || stored.username !== receipt.username
    || stored.attemptId !== receipt.attemptId || stored.attemptGeneration !== receipt.attemptGeneration
    || stored.leaseTokenHash !== receipt.leaseTokenHash || stored.leaseExpiresAtMs !== receipt.leaseExpiresAtMs) {
    throw new ProvisionConflictError('Receipt does not match the durable provision binding');
  }
}

/** Bounded coordinator slice: durable operation/attempt ownership plus an
 * atomic authentic-receipt registry bind. Trusted backend only; never expose
 * either method as a browser endpoint.
 *
 * - `loadProvisionReceipt(binding, { signal })` is injected by the deploying
 *   backend and is the trust boundary: it must authenticate the exact stored
 *   issuer (mTLS or equivalent, independent of the coordinator DB role) and
 *   read durable provider rows (owner + attempt), attaching the exact issuer
 *   it authenticated. It is not itself the authenticated transport proof;
 *   the separate server-side SQL reader supplies durable evidence; deployment must authenticate its pool.
 * - The loader is always called OUTSIDE any coordinator transaction with a
 *   bounded timeout. Timeouts, transport failures, missing attempts and
 *   MUTATING receipts are UNAVAILABLE, never abort evidence.
 */
export function createProvisionCoordinator(pool, { allowedProvisionIssuers, loadProvisionReceipt, receiptTimeoutMs = 5000 } = {}) {
  if (!pool || typeof pool.connect !== 'function') throw new TypeError('A pg pool is required');
  if (!Array.isArray(allowedProvisionIssuers) || !allowedProvisionIssuers.length) throw new TypeError('Explicit provision issuer allowlist is required');
  const allowlist = new Set(allowedProvisionIssuers.map(value => {
    nonempty(value, 512, 'provision issuer');
    let parsed;
    try { parsed = new URL(value); } catch { throw new TypeError('Invalid provision issuer'); }
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) throw new TypeError('Invalid provision issuer');
    if (value.includes('?') || value.includes('#') || value.includes('@')) throw new TypeError('Invalid provision issuer');
    return value;
  }));
  if (typeof loadProvisionReceipt !== 'function') throw new TypeError('An authenticated provision receipt loader is required');
  if (!Number.isInteger(receiptTimeoutMs) || receiptTimeoutMs < 10 || receiptTimeoutMs > 10000) throw new TypeError('Invalid provision receipt timeout');

  async function loadReceiptOutsideTx(binding) {
    const controller = new AbortController();
    let timer;
    try {
      return await Promise.race([
        Promise.resolve().then(() => loadProvisionReceipt(freeze(binding), { signal: controller.signal })),
        new Promise((_, reject) => { timer = setTimeout(() => { controller.abort(); reject(new ProvisionUnavailableError()); }, receiptTimeoutMs); }),
      ]);
    } catch (error) {
      if (error instanceof ProvisionUnavailableError) throw error;
      throw new ProvisionUnavailableError();
    } finally { clearTimeout(timer); controller.abort(); }
  }

  // Mints a fully bound attempt atomically: stable operation UUID per
  // account, fresh attempt UUID, random 32-byte lease token (hash stored,
  // raw token discarded), strictly-next generation, and DB-clock expiry in
  // one transaction. No caller-selected IDs, hashes, or expiry.
  // Returns { issuer, binding, reused } for trusted provider dispatch, or
  // { alreadyProvisioned: true, ... } once COMMITTED evidence exists. The
  // binding is the internal coordinator shape; map leaseTokenHash to the
  // Java attemptLeaseTokenHash and leaseExpiresAtMs to attemptExpiresAtMs
  // for dispatch, excluding issuer and version, never adding userId.
  async function startProvisionAttempt({ accountId: rawAccount, issuer: rawIssuer, realmId: rawRealm, leaseMs, provenance }) {
    const id = accountId(rawAccount);
    const issuer = provisionIssuer(rawIssuer, allowlist);
    const realm = realmId(rawRealm);
    if (!Number.isInteger(leaseMs) || leaseMs < 100 || leaseMs > 60000) throw new TypeError('Invalid provision lease duration');
    nonempty(provenance, 256, 'provenance');
    const username = canonicalUsername(id);
    return transaction(pool, async client => {
      const { rows: accounts } = await client.query('SELECT * FROM lakeside_accounts.account WHERE account_id=$1 FOR UPDATE', [id]);
      if (!accounts[0]) throw new ProvisionConflictError('Unknown account');
      if (accounts[0].status !== 'active' || accounts[0].recovery_hold) throw new ProvisionConflictError('Account is not active');
      const pinnedVersion = bigintText(accounts[0].security_version, 'account security version');

      let { rows: operations } = await client.query('SELECT * FROM lakeside_accounts.provision_operation WHERE account_id=$1', [id]);
      let operation = operations[0];
      if (!operation) {
        const operationId = randomUUID();
        let inserted;
        try {
          ({ rows: inserted } = await client.query(
            'INSERT INTO lakeside_accounts.provision_operation(account_id, operation_id, issuer, realm_id, username, provenance) VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT(account_id) DO NOTHING RETURNING *',
            [id, operationId, issuer, realm, username, provenance]));
        } catch (error) {
          if (error.code === '23505') throw new ProvisionConflictError('Provision operation is unavailable');
          throw error;
        }
        if (inserted[0]) {
          operation = inserted[0];
        } else {
          ({ rows: operations } = await client.query('SELECT * FROM lakeside_accounts.provision_operation WHERE account_id=$1', [id]));
          operation = operations[0];
        }
      }
      if (!operation) throw new ProvisionConflictError('Provision operation is unavailable');
      if (operation.issuer !== issuer || operation.realm_id !== realm || operation.username !== username) {
        throw new ProvisionConflictError('Provision operation is pinned to its first issuer, realm, and username');
      }

      const { rows: live } = await client.query('SELECT * FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1', [id]);
      if (live[0]) {
        const { rows: current } = await client.query('SELECT binding FROM lakeside_accounts.provision_attempt WHERE attempt_id=$1 FOR UPDATE', [live[0].attempt_id]);
        if (!current[0]) throw new ProvisionConflictError('Live provision attempt is unavailable');
        return { issuer, binding: freeze(current[0].binding), reused: true };
      }

      const { rows: history } = await client.query(
        `SELECT a.attempt_id, a.attempt_generation, e.receipt_id, e.state
           FROM lakeside_accounts.provision_attempt a LEFT JOIN lakeside_accounts.provision_evidence e USING (attempt_id)
          WHERE a.operation_id=$1 ORDER BY a.attempt_generation DESC LIMIT 1`, [operation.operation_id]);
      const last = history[0];
      if (last?.state === 'COMMITTED') {
        const { rows: evidence } = await client.query('SELECT receipt_id FROM lakeside_accounts.provision_evidence WHERE attempt_id=$1', [last.attempt_id]);
        const { rows: subject } = await client.query('SELECT user_id FROM lakeside_accounts.provision_subject WHERE account_id=$1', [id]);
        return {
          alreadyProvisioned: true, accountId: id, operationId: operation.operation_id, attemptId: last.attempt_id,
          issuer, realmId: realm, username, userId: subject[0]?.user_id ?? null, receiptId: evidence[0]?.receipt_id ?? null,
        };
      }
      let generation = 1;
      if (last) {
        if (!last.receipt_id || last.state !== 'ABORTED') throw new ProvisionConflictError('Prior provision attempt has no terminal abort evidence');
        const lastGenerationText = bigintText(last.attempt_generation, 'provision generation');
        const next = BigInt(lastGenerationText) + 1n;
        if (next > BigInt(MAX_SAFE_GENERATION)) throw new ProvisionConflictError('Provision generation overflow');
        generation = Number(next);
      }

      const attemptId = randomUUID();
      const leaseTokenHash = createHash('sha256').update(randomBytes(32)).digest('hex');
      const { rows: clock } = await client.query('SELECT (floor(extract(epoch from clock_timestamp()) * 1000))::bigint AS now_ms');
      const leaseExpiresAtMs = Number(clock[0].now_ms) + leaseMs;
      safePositiveInt(leaseExpiresAtMs, 'provision lease expiry');
      const binding = freeze({
        version: 1, accountId: id, operationId: operation.operation_id, issuer, realmId: realm, username,
        attemptId, attemptGeneration: generation, leaseTokenHash, leaseExpiresAtMs,
      });
      await client.query(
        'INSERT INTO lakeside_accounts.provision_attempt(attempt_id, operation_id, account_id, attempt_generation, account_security_version, binding) VALUES ($1,$2,$3,$4,$5,$6::jsonb)',
        [attemptId, operation.operation_id, id, String(generation), pinnedVersion, JSON.stringify(binding)]);
      await client.query('INSERT INTO lakeside_accounts.provision_live_attempt(account_id, operation_id, attempt_id) VALUES ($1,$2,$3)', [id, operation.operation_id, attemptId]);
      await event(client, id, 'provision.attempt_started', provenance);
      return { issuer, binding, reused: false };
    });
  }

  // Reads the stored attempt, calls the injected loader OUTSIDE any
  // transaction, then rechecks binding/live/evidence under lock and writes
  // subject + evidence + mapping + audit + outbox atomically on one client.
  async function reconcileProvisionAttempt({ attemptId: rawAttempt, provenance }) {
    const attemptId = uuid(rawAttempt, 'attempt ID');
    nonempty(provenance, 256, 'provenance');
    const { rows: peeked } = await pool.query(
      `SELECT a.binding, o.issuer FROM lakeside_accounts.provision_attempt a
         JOIN lakeside_accounts.provision_operation o USING (operation_id) WHERE a.attempt_id=$1`, [attemptId]);
    if (!peeked[0]) throw new ProvisionUnavailableError('Unknown provision attempt');
    const storedBinding = peeked[0].binding;
    const rawReceipt = await loadReceiptOutsideTx(freeze({ ...storedBinding }));
    let receipt;
    try {
      receipt = checkReceiptShape(rawReceipt, allowlist);
    } catch (error) {
      if (error instanceof ProvisionUnavailableError || error instanceof ProvisionConflictError) throw error;
      throw new ProvisionUnavailableError();
    }
    if (receipt.state === 'MUTATING') throw new ProvisionUnavailableError();
    // receipt is the frozen snapshot copy from checkReceiptShape; every use
    // below (binding match, fingerprint, advisory/account/attempt locks,
    // subject, evidence, mapping) reads only the snapshot, never rawReceipt.
    checkBindingMatch(storedBinding, receipt);
    const evidenceFingerprint = fingerprint({
      accountId: receipt.accountId, operationId: receipt.operationId, issuer: receipt.issuer, realmId: receipt.realmId,
      username: receipt.username, userId: receipt.userId, attemptId: receipt.attemptId, attemptGeneration: receipt.attemptGeneration,
      leaseTokenHash: receipt.leaseTokenHash, leaseExpiresAtMs: receipt.leaseExpiresAtMs, receiptId: receipt.receiptId, state: receipt.state,
    });

    return transaction(pool, async client => {
      // Identity-first advisory ordering matches the existing registry
      // (advisory identity lock, then account row, then attempt row), so a
      // concurrent first-login/link on the same (issuer, subject) serializes
      // instead of deadlocking.
      await client.query('SELECT pg_advisory_xact_lock(hashtextextended($1,0))', [JSON.stringify([receipt.issuer, receipt.userId])]);
      const { rows: accounts } = await client.query('SELECT * FROM lakeside_accounts.account WHERE account_id=$1 FOR UPDATE', [receipt.accountId]);
      if (!accounts[0]) throw new ProvisionConflictError('Unknown account');
      const { rows: attempts } = await client.query('SELECT * FROM lakeside_accounts.provision_attempt WHERE attempt_id=$1 FOR UPDATE', [attemptId]);
      const attempt = attempts[0];
      if (!attempt || attempt.operation_id !== receipt.operationId || attempt.account_id !== receipt.accountId
        || attempt.attempt_generation !== String(receipt.attemptGeneration)) throw new ProvisionConflictError('Provision attempt changed under lock');
      checkBindingMatch(attempt.binding, receipt);

      const { rows: evidenced } = await client.query('SELECT * FROM lakeside_accounts.provision_evidence WHERE attempt_id=$1', [attemptId]);
      if (evidenced[0]) {
        if (evidenced[0].receipt_id !== receipt.receiptId || evidenced[0].state !== receipt.state
          || evidenced[0].evidence_fingerprint !== evidenceFingerprint) throw new ProvisionConflictError('Contradictory provision evidence');
        return { state: receipt.state, accountId: receipt.accountId, operationId: receipt.operationId, attemptId, attemptGeneration: receipt.attemptGeneration, receiptId: receipt.receiptId, userId: receipt.userId, issuer: receipt.issuer, replay: true };
      }
      const { rows: live } = await client.query('SELECT * FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1', [receipt.accountId]);
      if (!live[0] || live[0].attempt_id !== attemptId) throw new ProvisionConflictError('Provision attempt is not live');

      // COMMITTED mapping preconditions are checked BEFORE any write, so a
      // hold or version drift fails closed with zero rows and a later retry
      // can still land evidence. ABORT skips these checks: containment only.
      if (receipt.state === 'COMMITTED') {
        if (accounts[0].status !== 'active' || accounts[0].recovery_hold) throw new ProvisionConflictError('Account is not active');
        if (accounts[0].security_version !== attempt.account_security_version) throw new ProvisionConflictError('Account security version drifted since bind');
      }

      const { rows: subjects } = await client.query('SELECT * FROM lakeside_accounts.provision_subject WHERE account_id=$1', [receipt.accountId]);
      if (subjects[0]) {
        if (subjects[0].user_id !== receipt.userId || subjects[0].issuer !== receipt.issuer || subjects[0].realm_id !== receipt.realmId) {
          throw new ProvisionConflictError('Receipt target does not match the frozen provision subject');
        }
      } else {
        try {
          await client.query('INSERT INTO lakeside_accounts.provision_subject(account_id, user_id, issuer, realm_id, first_attempt_id) VALUES ($1,$2,$3,$4,$5)',
            [receipt.accountId, receipt.userId, receipt.issuer, receipt.realmId, attemptId]);
        } catch (error) {
          if (error.code !== '23505') throw error;
          throw new ProvisionConflictError('Provision subject is already frozen to another target');
        }
      }

      if (receipt.state === 'ABORTED') {
        // Containment only: recordable during hold or version drift, never maps.
        await client.query('INSERT INTO lakeside_accounts.provision_evidence(attempt_id, receipt_id, state, evidence_fingerprint) VALUES ($1,$2,$3,$4)',
          [attemptId, receipt.receiptId, 'ABORTED', evidenceFingerprint]);
        await client.query('DELETE FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1 AND attempt_id=$2', [receipt.accountId, attemptId]);
        await event(client, receipt.accountId, 'provision.aborted', provenance);
        return { state: 'ABORTED', accountId: receipt.accountId, operationId: receipt.operationId, attemptId, attemptGeneration: receipt.attemptGeneration, receiptId: receipt.receiptId, userId: receipt.userId, issuer: receipt.issuer, replay: false };
      }

      const { rows: owned } = await client.query('SELECT account_id FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2', [receipt.issuer, receipt.userId]);
      if (owned[0] && owned[0].account_id !== receipt.accountId) throw new ProvisionConflictError('Provision target is already mapped');
      try {
        if (!owned[0]) {
          await client.query('INSERT INTO lakeside_accounts.external_identity(issuer,subject,account_id,provenance) VALUES ($1,$2,$3,$4)',
            [receipt.issuer, receipt.userId, receipt.accountId, provenance]);
        }
      } catch (error) {
        if (error.code !== '23505') throw error;
        throw new ProvisionConflictError('Provision target is already mapped');
      }
      await client.query('INSERT INTO lakeside_accounts.provision_evidence(attempt_id, receipt_id, state, evidence_fingerprint) VALUES ($1,$2,$3,$4)',
        [attemptId, receipt.receiptId, 'COMMITTED', evidenceFingerprint]);
      await client.query('DELETE FROM lakeside_accounts.provision_live_attempt WHERE account_id=$1 AND attempt_id=$2', [receipt.accountId, attemptId]);
      await event(client, receipt.accountId, 'identity.provisioned', provenance);
      return { state: 'COMMITTED', accountId: receipt.accountId, operationId: receipt.operationId, attemptId, attemptGeneration: receipt.attemptGeneration, receiptId: receipt.receiptId, userId: receipt.userId, issuer: receipt.issuer, replay: false };
    });
  }

  return Object.freeze({ startProvisionAttempt, reconcileProvisionAttempt });
}
