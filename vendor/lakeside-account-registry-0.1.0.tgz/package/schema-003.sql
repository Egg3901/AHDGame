-- A recovery hold never changes administrative suspension or ownership.
ALTER TABLE lakeside_accounts.account ADD COLUMN recovery_hold boolean NOT NULL DEFAULT false;
