# Provision access token provider

`createProvisionAccessTokenProvider` is the trusted backend OAuth transport
used as the `obtainAccessToken` callback for
`createProvisionDispatcher`. It performs one uncached OAuth 2.0
`client_credentials` request per callback invocation and returns only the
validated `access_token` string.

```js
import { createProvisionAccessTokenProvider } from './provision-access-token.mjs';
import { createProvisionDispatcher } from './provision-dispatch.mjs';

const accessTokens = createProvisionAccessTokenProvider({
  tokenEndpoint: 'https://issuer.example.invalid/realms/lakeside/protocol/openid-connect/token',
  clientId: configuredClientId,
  clientSecret: configuredClientSecret,
  scope: 'account-provision',
});

const dispatcher = createProvisionDispatcher({
  endpoint: configuredProvisionEndpoint,
  issuer: configuredIssuer,
  realmId: configuredRealm,
  obtainAccessToken: accessTokens.obtainAccessToken,
});
```

The token endpoint is an explicit pinned HTTPS URL. The provider rejects
credentials, query strings, fragments, HTTP, URL normalization aliases, and
missing configuration. It uses standard platform TLS verification and
`redirect: 'error'`. No endpoint discovery, realm registration, client
registration, config mutation, or production default exists.

The request uses HTTP Basic authentication. Both the client ID and secret are
encoded with the RFC 6749 application/x-www-form-urlencoded rules before the
encoded pair is joined with `:` and base64 encoded. The form body contains
only `grant_type=client_credentials` and, when explicitly configured, one
space-delimited `scope` field. The secret is never placed in the URL, query,
or form body.

Each call has one bounded 100 to 5000 millisecond deadline covering fetch and
stream reading. It accepts the dispatcher's cooperative `AbortSignal`, does
not retry, and cancels response bodies on rejected status, content type,
redirect, timeout, parent abort, and late fetch completion. Response bodies
must be streamed through a reader, use fatal UTF-8 decoding, and be at most
16 KiB. Text-only adapters are rejected because they cannot provide the same
bound.

The response must have status 200 and JSON content type. It must contain a
nonempty ASCII RFC 7235 token68 `access_token` of at most 8192 characters,
case-insensitive `token_type: Bearer`, and positive integer `expires_in` no
greater than 3600. Duplicate JSON object keys are rejected before parsing.
`expires_in` is validation evidence only. The provider does not cache or
refresh tokens and does not return token metadata.

`ProvisionAccessTokenError` exposes a small local error code such as
`timeout`, `aborted`, `transport`, `http`, `content_type`, `body`, or
`invalid`. Messages never include the endpoint, credentials, provider body,
or injected exception details. Provider-side OAuth registration, TLS trust
material, secret storage, and deployment configuration remain outside this
package.

Unit tests use an explicitly injected fetch implementation. They cover exact
Basic encoding, exact request fields, endpoint and scope validation, no
caching, redirects, 429 and 500 responses, body cancellation, strict UTF-8,
duplicate keys, token validation, byte limits, timeout and parent abort, late
responses, and sanitized injected failures.

The guarded `compat/provision-transport.test.mjs` also exercises this provider
against the pinned real OAuth issuer and then dispatches a provisioning request.
The separate `compat/provision-client-tls.test.mjs` uses default fetch with an
owned local CA and HTTPS fixture to verify certificate and hostname rejection,
redirect refusal, request encoding, response limits and cancellation. The OAuth
fixture does not prove production TLS; the TLS fixture is not a real issuer.
