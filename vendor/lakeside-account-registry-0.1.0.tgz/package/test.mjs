import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import pg from 'pg';
import { createAccountRegistry, migrate, MappingConflictError, AccountProofError, AccountSuspendedError } from './index.mjs';

if (process.env.LAKESIDE_ISOLATED_REGISTRY_TEST !== 'true' || process.env.PGHOST !== 'database') {
  throw new Error('Run through the isolated compat Compose registry-tests service');
}
const database = `registry_test_${randomUUID().replaceAll('-', '')}`;
const admin = new pg.Pool({ max: 1 });
let pool, registry;
const options = { allowedIssuers: ['https://production.example.invalid', 'urn:lakeside:legacy:ahd:production'], allowedApplications: ['ahd', 'electioneer'] };
const identity = subject => ({ issuer: options.allowedIssuers[0], subject });
test.before(async () => {
  await admin.query(`CREATE DATABASE ${database}`);
  pool = new pg.Pool({ database, max: 12 });
  await Promise.all([migrate(pool), migrate(pool)]);
  registry = createAccountRegistry(pool, options);
});
test.after(async () => {
  await pool?.end();
  await admin.query(`DROP DATABASE IF EXISTS ${database}`);
  await admin.end();
});

test('concurrent first logins create one account, audit event and pending delivery', async () => {
  const users = await Promise.all(Array.from({ length: 24 }, () => registry.resolveOrCreateVerifiedIdentity(identity('racing-user'), 'verified-login:test')));
  assert.equal(new Set(users.map(user => user.account_id)).size, 1);
  const { rows } = await pool.query('SELECT count(*) FROM lakeside_accounts.audit_event e JOIN lakeside_accounts.outbox o USING(event_id) WHERE account_id=$1', [users[0].account_id]);
  assert.equal(rows[0].count, '1');
  assert.equal((await pool.query('SELECT count(*) FROM lakeside_accounts.account')).rows[0].count, '1');
});

test('issuer and exact subject define identity; matching email never merges accounts', async () => {
  const first = await registry.resolveOrCreateVerifiedIdentity({ ...identity('same-subject'), email: 'same@example.invalid' }, 'verified-login:test');
  const second = await registry.resolveOrCreateVerifiedIdentity({ issuer: options.allowedIssuers[1], subject: 'same-subject', email: 'same@example.invalid' }, 'verified-login:test');
  const third = await registry.resolveOrCreateVerifiedIdentity(identity('Same-subject'), 'verified-login:test');
  assert.notEqual(first.account_id, second.account_id);
  assert.notEqual(first.account_id, third.account_id);
  await assert.rejects(registry.resolveOrCreateVerifiedIdentity({ issuer: 'https://staging.example.invalid', subject: 'same-subject' }, 'test'), /Untrusted/);
});

test('local game IDs survive repeated migration and another account cannot claim them', async () => {
  const a = await registry.resolveOrCreateVerifiedIdentity(identity('owner-a'), 'migration:test');
  const b = await registry.resolveOrCreateVerifiedIdentity(identity('owner-b'), 'migration:test');
  await Promise.all(Array.from({ length: 8 }, () => registry.mapApplicationIdentity(a.account_id, 'ahd', 'original-game-object-id', 'migration:test')));
  assert.equal(await registry.findApplicationIdentity(a.account_id, 'ahd'), 'original-game-object-id');
  await assert.rejects(registry.mapApplicationIdentity(b.account_id, 'ahd', 'original-game-object-id', 'migration:test'), MappingConflictError);
  await assert.rejects(registry.mapApplicationIdentity(a.account_id, 'ahd', 'different-game-id', 'migration:test'), MappingConflictError);
  assert.equal(await registry.findApplicationIdentity(b.account_id, 'ahd'), null);
  const { rows } = await pool.query("SELECT count(*) FROM lakeside_accounts.audit_event WHERE account_id=$1 AND action='application.mapped'", [a.account_id]);
  assert.equal(rows[0].count, '1');
});

test('competing claims produce one owner and roll back the losing write', async () => {
  const owners = await Promise.all(['race-a', 'race-b'].map(subject => registry.resolveOrCreateVerifiedIdentity(identity(subject), 'migration:test')));
  const results = await Promise.allSettled(owners.map(owner => registry.mapApplicationIdentity(owner.account_id, 'electioneer', 'contested-local-id', 'migration:test')));
  assert.equal(results.filter(result => result.status === 'fulfilled').length, 1);
  assert.ok(results.find(result => result.status === 'rejected').reason instanceof MappingConflictError);
  const links = await Promise.all(owners.map(owner => registry.findApplicationIdentity(owner.account_id, 'electioneer')));
  assert.equal(links.filter(Boolean).length, 1);
});

test('suspension prevents returning and mapping identity and atomically queues revocation', async () => {
  const user = await registry.resolveOrCreateVerifiedIdentity(identity('suspended-user'), 'verified-login:test');
  await registry.mapApplicationIdentity(user.account_id, 'ahd', 'suspended-local-id', 'migration:test');
  await Promise.all([registry.suspendAccount(user.account_id, 'security:test'), registry.suspendAccount(user.account_id, 'security:test')]);
  await assert.rejects(registry.resolveOrCreateVerifiedIdentity(identity('suspended-user'), 'verified-login:test'), AccountSuspendedError);
  await assert.rejects(registry.mapApplicationIdentity(user.account_id, 'electioneer', 'new-id', 'migration:test'), AccountSuspendedError);
  assert.equal(await registry.findApplicationIdentity(user.account_id, 'ahd'), null);
  const { rows } = await pool.query("SELECT a.security_version, count(e.event_id) FROM lakeside_accounts.account a JOIN lakeside_accounts.audit_event e USING(account_id) JOIN lakeside_accounts.outbox o USING(event_id) WHERE a.account_id=$1 AND e.action='account.suspended' GROUP BY a.security_version", [user.account_id]);
  assert.deepEqual(rows, [{ security_version: '2', count: '1' }]);
});

test('an audit failure rolls back the identity instead of acknowledging an unaudited account', async () => {
  await pool.query("ALTER TABLE lakeside_accounts.audit_event ADD CONSTRAINT test_reject_event CHECK (provenance <> 'reject:test')");
  try {
    await assert.rejects(registry.resolveOrCreateVerifiedIdentity(identity('must-rollback'), 'reject:test'));
    assert.equal((await pool.query("SELECT count(*) FROM lakeside_accounts.external_identity WHERE subject='must-rollback'")).rows[0].count, '0');
  } finally { await pool.query('ALTER TABLE lakeside_accounts.audit_event DROP CONSTRAINT test_reject_event'); }
});

test('current security state reflects suspension, revocation and missing accounts without changing ownership', async () => {
  const user = await registry.resolveOrCreateVerifiedIdentity(identity('security-user'), 'verified-login:test');
  assert.deepEqual(await registry.getAccountSecurity(user.account_id), {account_id:user.account_id,status:'active',security_version:'1',authentication_not_before:'0'});
  assert.equal(await registry.getAccountSecurity(randomUUID()), null);
  assert.equal(await registry.revokeAccountSessions(user.account_id, 'recovery:test'), '2');
  assert.equal((await registry.resolveOrCreateVerifiedIdentity(identity('security-user'), 'verified-login:test')).account_id, user.account_id);
  const afterReset=await registry.getAccountSecurity(user.account_id);
  assert.ok(Number(afterReset.authentication_not_before)>0);
  assert.equal(afterReset.security_version, '2');
  const events = await pool.query("SELECT count(*) FROM lakeside_accounts.audit_event JOIN lakeside_accounts.outbox USING(event_id) WHERE account_id=$1 AND action='account.sessions_revoked'", [user.account_id]);
  assert.equal(events.rows[0].count, '1');
  await pool.query("ALTER TABLE lakeside_accounts.audit_event ADD CONSTRAINT test_reject_revocation CHECK (provenance <> 'reject:revocation')");
  try {
    await assert.rejects(registry.revokeAccountSessions(user.account_id, 'reject:revocation'));
    assert.deepEqual(await registry.getAccountSecurity(user.account_id),afterReset);
  } finally {await pool.query('ALTER TABLE lakeside_accounts.audit_event DROP CONSTRAINT test_reject_revocation');}
  await registry.suspendAccount(user.account_id, 'security:test');
  const suspended=await registry.getAccountSecurity(user.account_id);
  assert.equal(suspended.status,'suspended');assert.equal(suspended.security_version,'3');
  assert.ok(BigInt(suspended.authentication_not_before)>=BigInt(afterReset.authentication_not_before));
  await assert.rejects(registry.revokeAccountSessions(user.account_id, 'recovery:test'), AccountSuspendedError);
  await assert.rejects(registry.getAccountSecurity('invalid'), /account ID/);
});

const proof = (user, subject, issuer=options.allowedIssuers[0]) => ({accountId:user.account_id,securityVersion:user.security_version,issuer,subject,authenticatedAt:Math.floor(Date.now()/1000)});

test('two fresh proofs link an unclaimed identity without changing account or local ownership', async () => {
  const user = await registry.resolveOrCreateVerifiedIdentity(identity('link-owner'), 'test:login');
  await registry.mapApplicationIdentity(user.account_id,'ahd','link-owner-game','test:migration');
  const primary=proof(user,'link-owner');
  const secondary=proof(user,'new-provider-subject',options.allowedIssuers[1]);
  const linked=await registry.linkVerifiedIdentity({primary,secondary},'test:link');
  assert.equal(linked.account_id,user.account_id);assert.equal(linked.security_version,'2');
  assert.equal((await registry.resolveOrCreateVerifiedIdentity(secondary,'test:login')).account_id,user.account_id);
  assert.equal(await registry.findApplicationIdentity(user.account_id,'ahd'),'link-owner-game');
  const retry=await registry.linkVerifiedIdentity({primary:{...primary,securityVersion:'2'},secondary},'test:link');
  assert.equal(retry.security_version,'2');
  assert.equal((await pool.query("SELECT count(*) FROM lakeside_accounts.audit_event JOIN lakeside_accounts.outbox USING(event_id) WHERE account_id=$1 AND action='identity.linked'",[user.account_id])).rows[0].count,'1');
});

test('linking cannot claim another account, accept stale proof, or trust an arbitrary target ID', async () => {
  const a=await registry.resolveOrCreateVerifiedIdentity(identity('link-a'),'test:login');
  const b=await registry.resolveOrCreateVerifiedIdentity(identity('link-b'),'test:login');
  const primary=proof(a,'link-a'), secondary=proof(b,'link-b');
  await assert.rejects(registry.linkVerifiedIdentity({primary,secondary},'test:link'),MappingConflictError);
  for(const changes of [{accountId:b.account_id},{subject:'link-b'},{securityVersion:'2'},{authenticatedAt:0},{authenticatedAt:Math.floor(Date.now()/1000)-301},{authenticatedAt:Math.floor(Date.now()/1000)+60}]){
    await assert.rejects(registry.linkVerifiedIdentity({primary:{...primary,...changes},secondary:{...secondary,subject:'unclaimed-link'}},'test:link'),AccountProofError);
  }
  await assert.rejects(registry.linkVerifiedIdentity({primary,secondary:{...secondary,authenticatedAt:0}},'test:link'),AccountProofError);
  await registry.suspendAccount(a.account_id,'test:suspend');
  await assert.rejects(registry.linkVerifiedIdentity({primary,secondary},'test:link'),AccountSuspendedError);
  assert.equal((await registry.resolveOrCreateVerifiedIdentity(secondary,'test:login')).account_id,b.account_id);
});

test('competing link and first-login claims preserve exactly one identity owner', async () => {
  for(let index=0;index<8;index++){
    const a=await registry.resolveOrCreateVerifiedIdentity(identity(`link-race-${index}`),'test:login');
    const secondary=proof(a,`unclaimed-race-${index}`);
    const results=await Promise.allSettled([
      registry.linkVerifiedIdentity({primary:proof(a,`link-race-${index}`),secondary},'test:link'),
      registry.resolveOrCreateVerifiedIdentity(secondary,'test:login'),
    ]);
    const final=await registry.resolveOrCreateVerifiedIdentity(secondary,'test:login');
    if(results[0].status==='fulfilled')assert.equal(final.account_id,a.account_id);
    else {assert.ok(results[0].reason instanceof MappingConflictError);assert.notEqual(final.account_id,a.account_id);}
    assert.equal((await pool.query('SELECT count(*) FROM lakeside_accounts.external_identity WHERE issuer=$1 AND subject=$2',[secondary.issuer,secondary.subject])).rows[0].count,'1');
  }
});

test('failed linking audit rolls back both the new identity and security version',async()=>{
  const a=await registry.resolveOrCreateVerifiedIdentity(identity('link-audit'),'test:login');
  await pool.query("ALTER TABLE lakeside_accounts.audit_event ADD CONSTRAINT test_link_audit CHECK (provenance <> 'reject:link')");
  try{
    await assert.rejects(registry.linkVerifiedIdentity({primary:proof(a,'link-audit'),secondary:proof(a,'link-rollback')},'reject:link'));
    assert.equal((await registry.getAccountSecurity(a.account_id)).security_version,'1');
    assert.equal((await pool.query("SELECT count(*) FROM lakeside_accounts.external_identity WHERE subject='link-rollback'")).rows[0].count,'0');
  }finally{await pool.query('ALTER TABLE lakeside_accounts.audit_event DROP CONSTRAINT test_link_audit');}
});

test('older linking proof cannot bypass a reset by supplying the current version',async()=>{
  const user=await registry.resolveOrCreateVerifiedIdentity(identity('link-after-reset'),'test:login');
  const primary=proof(user,'link-after-reset');
  const version=await registry.revokeAccountSessions(user.account_id,'test:reset');
  await assert.rejects(registry.linkVerifiedIdentity({primary:{...primary,securityVersion:version},secondary:proof(user,'new-after-reset')},'test:link'),AccountProofError);
});

test('upgrading version-one accounts preserves ownership and closes old reset authentication',async()=>{
  const user=await registry.resolveOrCreateVerifiedIdentity(identity('upgrade-reset'),'test:login');
  await registry.revokeAccountSessions(user.account_id,'test:reset');
  await pool.query('ALTER TABLE lakeside_accounts.account DROP COLUMN authentication_not_before, DROP COLUMN recovery_hold');
  await pool.query('DELETE FROM lakeside_accounts.migration WHERE version IN (2,3)');
  await migrate(pool);
  const after=await registry.getAccountSecurity(user.account_id);
  assert.equal(after.account_id,user.account_id);assert.equal(after.security_version,'2');
  assert.ok(Number(after.authentication_not_before)>0);
  await pool.query("UPDATE lakeside_accounts.migration SET checksum='unexpected' WHERE version=2");
  await assert.rejects(migrate(pool),/checksum differs/);
  // Restore the actual checksum using the same source file, then prove restart separately.
  const {readFile}=await import('node:fs/promises');const {createHash}=await import('node:crypto');
  const checksum=createHash('sha256').update(await readFile(new URL('./schema-002.sql',import.meta.url))).digest('hex');
  await pool.query('UPDATE lakeside_accounts.migration SET checksum=$1 WHERE version=2',[checksum]);
});

test('registry restart retains mappings and migrations are repeatable', async () => {
  const before = await registry.resolveOrCreateVerifiedIdentity(identity('durable-user'), 'verified-login:test');
  await pool.end();
  pool = new pg.Pool({ database, max: 12 });
  await migrate(pool);
  registry = createAccountRegistry(pool, options);
  const after = await registry.resolveOrCreateVerifiedIdentity(identity('durable-user'), 'verified-login:test');
  assert.equal(before.account_id, after.account_id);
  await pool.query("UPDATE lakeside_accounts.migration SET checksum='unexpected' WHERE version=1");
  await assert.rejects(migrate(pool), /checksum differs/);
});
