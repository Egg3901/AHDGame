import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createProvisionReceiptReader, ProvisionReceiptReadError } from './provision-receipt-reader.mjs';
const issuer = 'https://issuer.example.invalid/realms/accounts';
const realmId = 'test-realm';
const binding = { issuer, realmId, accountId: randomUUID(), operationId: randomUUID(), attemptId: randomUUID() };
const row = { account_id: binding.accountId, operation_id: binding.operationId, realm_id: realmId,
  username: `lakeside:${binding.accountId}`, user_id: randomUUID(), attempt_id: binding.attemptId,
  attempt_generation: '1', lease_token_hash: 'a'.repeat(64), lease_expires_ms: '1234567890', receipt_id: randomUUID(), state: 'COMMITTED' };
function fixture(rows = [row], failAt = 0, controller) {
  const queries = [], releases = [];
  const client = { async query(q) {
    queries.push(q);
    if (queries.length === failAt) throw new Error('synthetic secret that must not escape');
    if (q.text.startsWith('SELECT o.')) { controller?.abort(); return { rows }; }
    return { rows: [] };
  }, release(value) { releases.push(value); } };
  const pool = { options: { connectionTimeoutMillis: 100 }, async connect() { return client; } };
  return { load: createProvisionReceiptReader(pool, { issuer, realmId }), queries, releases, pool };
}
test('reads committed exact issuer owner/attempt snapshot in read-only transaction', async () => {
  const f = fixture(); const result = await f.load(binding);
  assert.deepEqual(result, { issuer, accountId: binding.accountId, operationId: binding.operationId, realmId,
    username: row.username, userId: row.user_id, attemptId: binding.attemptId, attemptGeneration: 1,
    leaseTokenHash: row.lease_token_hash, leaseExpiresAtMs: 1234567890, receiptId: row.receipt_id, state: 'COMMITTED' });
  assert.ok(Object.isFrozen(result));
  assert.equal(f.queries[0].text, 'BEGIN READ ONLY'); assert.equal(f.queries.at(-1).text, 'COMMIT');
  assert.deepEqual(f.queries[2].values, [binding.attemptId, realmId, binding.accountId, binding.operationId]);
  assert.ok(f.queries.every(q => q.query_timeout === 3000)); assert.deepEqual(f.releases, [false]);
});
test('returns exact ABORTED evidence and never converts absence or MUTATING into abort', async () => {
  assert.equal((await fixture([{ ...row, state: 'ABORTED' }]).load(binding)).state, 'ABORTED');
  for (const rows of [[], [{ ...row, state: 'MUTATING' }]]) assert.equal(await fixture(rows).load(binding), null);
});
for (const [key, value] of Object.entries({ account_id: randomUUID(), operation_id: randomUUID(), realm_id: 'other',
  user_id: 'not-a-uuid', attempt_id: randomUUID(), receipt_id: 'bad', username: 'unowned', state: 'UNKNOWN',
  lease_token_hash: 'bad', attempt_generation: '9007199254740992', lease_expires_ms: '0' })) {
  test(`rejects malformed or conflicting ${key}`, async () => {
    const f = fixture([{ ...row, [key]: value }]); await assert.rejects(f.load(binding), ProvisionReceiptReadError);
    assert.deepEqual(f.releases, [true]);
  });
}
test('ambiguous duplicate rows fail closed', async () => { await assert.rejects(fixture([row, row]).load(binding), ProvisionReceiptReadError); });
test('wrong trusted scope and cancellation do not acquire a connection', async () => {
  for (const change of [{ issuer: 'https://other.example.invalid' }, { realmId: 'other' }, { attemptId: 'bad' }]) {
    const f = fixture(); await assert.rejects(f.load({ ...binding, ...change }), ProvisionReceiptReadError); assert.equal(f.queries.length, 0);
  }
  const f = fixture(); const c = new AbortController(); c.abort(); await assert.rejects(f.load(binding, { signal: c.signal }), ProvisionReceiptReadError); assert.equal(f.queries.length, 0);
});
test('cancelled read discards evidence and releases only its own client', async () => {
  const c = new AbortController(); const f = fixture([row], 0, c);
  await assert.rejects(f.load(binding, { signal: c.signal }), ProvisionReceiptReadError); assert.deepEqual(f.releases, [true]);
});
for (const index of [1, 2, 3, 4]) test(`query failure ${index} destroys connection and sanitizes errors`, async () => {
  const f = fixture([row], index);
  await assert.rejects(f.load(binding), error => error instanceof ProvisionReceiptReadError && !error.message.includes('secret'));
  assert.deepEqual(f.releases, [true]);
});
test('requires bounded pool and query budgets, safe SQL schema and exact HTTPS authority', () => {
  const { pool } = fixture();
  for (const options of [{ issuer: 'http://issuer.example.invalid' }, { issuer: issuer+'?' }, { issuer: issuer+'#' },
    { issuer: 'https://user:pass@issuer.example.invalid' }, { schema: 'public;DROP' }, { schema: 'pg_catalog' }, { queryTimeoutMs: 0 }, { queryTimeoutMs: 5001 }]) {
    assert.throws(() => createProvisionReceiptReader(pool, { issuer, realmId, ...options }), TypeError);
  }
  assert.throws(() => createProvisionReceiptReader({ ...pool, options: {} }, { issuer, realmId }), TypeError);
});

test('rejects final line terminators and coercible identities before acquiring a connection', async () => {
  for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
    for (const key of ['accountId', 'operationId', 'attemptId']) {
      const f = fixture(); let connects = 0;
      const connect = f.pool.connect;
      f.pool.connect = async () => { connects++; return connect(); };
      await assert.rejects(f.load({ ...binding, [key]: binding[key] + suffix }), ProvisionReceiptReadError);
      assert.equal(connects, 0);
    }
  }
  const f = fixture();
  await assert.rejects(f.load({ ...binding, attemptId: { toString: () => binding.attemptId } }), ProvisionReceiptReadError);
  assert.equal(f.queries.length, 0);
});
test('rejects noncanonical receipt identifiers, hashes and numeric strings', async () => {
  for (const key of ['user_id', 'receipt_id', 'lease_token_hash', 'attempt_generation', 'lease_expires_ms']) {
    for (const suffix of ['\n', '\r', '\u2028', '\u2029']) {
      await assert.rejects(fixture([{ ...row, [key]: row[key] + suffix }]).load(binding), ProvisionReceiptReadError);
    }
  }
  await assert.rejects(fixture([{ ...row, lease_token_hash: { toString: () => row.lease_token_hash } }]).load(binding), ProvisionReceiptReadError);
});
test('captures the validated binding before waiting for a pool connection', async () => {
  const mutable = { ...binding };
  const f = fixture();
  const connect = f.pool.connect;
  f.pool.connect = async () => {
    mutable.accountId = randomUUID(); mutable.operationId = randomUUID(); mutable.attemptId = randomUUID();
    return connect();
  };
  const result = await f.load(mutable);
  assert.equal(result.accountId, binding.accountId);
  assert.deepEqual(f.queries[2].values, [binding.attemptId, realmId, binding.accountId, binding.operationId]);
});
test('rejects a line-terminated SQL schema', () => {
  assert.throws(() => createProvisionReceiptReader(fixture().pool, { issuer, realmId, schema: 'public\n' }), TypeError);
});
