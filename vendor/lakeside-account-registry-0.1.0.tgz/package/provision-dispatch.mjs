const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/u;
const HASH = /^[0-9a-f]{64}$/u;
const DECIMAL = /^[1-9][0-9]{0,15}$/u;
const CONTROL = /[\u0000-\u001f\u007f]/u;
const BINDING_KEYS = [
  'version', 'accountId', 'operationId', 'issuer', 'realmId', 'username',
  'attemptId', 'attemptGeneration', 'leaseTokenHash', 'leaseExpiresAtMs',
];
const RESPONSE_KEYS = ['state', 'receiptId', 'userId'];
const RESPONSE_STATES = new Set(['COMMITTED', 'ABORTED', 'REPLAY_NO_MUTATION']);
const PG_BIGINT_MAX = 9223372036854775807n;

/**
 * A dispatch failure never claims that the provider performed or did not
 * perform the operation unless that follows from local validation. When the
 * HTTP request could have reached the issuer, callers must reconcile through
 * the authenticated durable receipt reader before retrying or aborting.
 */
export class ProvisionDispatchError extends Error {
  constructor(code = 'dispatch_failed', message = 'Provision dispatch failed', requestMayHaveReachedIssuer = false) {
    super(message);
    this.name = 'ProvisionDispatchError';
    this.code = code;
    this.requestMayHaveReachedIssuer = requestMayHaveReachedIssuer;
    this.ambiguous = requestMayHaveReachedIssuer;
  }
}

function text(value, max, label) {
  if (typeof value !== 'string' || value.length === 0 || value.length > max || value.trim() !== value || CONTROL.test(value)) {
    throw new TypeError(`Invalid ${label}`);
  }
  return value;
}

function uuid(value, label) {
  if (typeof value !== 'string' || value.length !== 36 || !UUID.test(value)) throw new TypeError(`Invalid ${label}`);
  return value;
}

function positiveNumber(value, label) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0) throw new TypeError(`Invalid ${label}`);
  return value;
}

function generation(value) {
  if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0) throw new TypeError('Invalid attempt generation');
  const decimal = String(value);
  if (!DECIMAL.test(decimal) || BigInt(decimal) > PG_BIGINT_MAX) throw new TypeError('Invalid attempt generation');
  return decimal;
}

function exactHttps(value, label) {
  text(value, 512, label);
  let parsed;
  try { parsed = new URL(value); } catch { throw new TypeError(`Invalid ${label}`); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash
      || value.includes('?') || value.includes('#') || value.includes('@')
      || parsed.host !== value.slice('https://'.length).split('/')[0]) {
    throw new TypeError(`Invalid ${label}`);
  }
  return parsed;
}

function endpointUrl(base, action) {
  const url = new URL(base.href);
  const path = url.pathname.replace(/\/+$/u, '');
  if (path.endsWith('/provision') || path.endsWith('/abort')) throw new TypeError('Dispatch endpoint must be a base endpoint');
  url.pathname = `${path}/${action}`;
  return url.href;
}

function validateBinding(value, configuredIssuer, configuredRealm) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new TypeError('Invalid provision binding');
  const keys = Object.keys(value).sort();
  if (keys.length !== BINDING_KEYS.length || !BINDING_KEYS.every(key => keys.includes(key))) {
    throw new TypeError('Invalid provision binding');
  }
  if (value.version !== 1) throw new TypeError('Invalid provision binding version');
  const accountId = uuid(value.accountId, 'account ID');
  const operationId = uuid(value.operationId, 'operation ID');
  const attemptId = uuid(value.attemptId, 'attempt ID');
  if (value.issuer !== configuredIssuer) throw new ProvisionDispatchError('binding_scope', 'Provision binding scope conflict');
  if (value.realmId !== configuredRealm) throw new ProvisionDispatchError('binding_scope', 'Provision binding scope conflict');
  if (value.username !== `lakeside:${accountId}`) throw new ProvisionDispatchError('binding_scope', 'Provision binding username conflict');
  const attemptGeneration = generation(value.attemptGeneration);
  const leaseExpiresAtMs = positiveNumber(value.leaseExpiresAtMs, 'lease expiry');
  if (typeof value.leaseTokenHash !== 'string' || value.leaseTokenHash.length !== 64 || !HASH.test(value.leaseTokenHash)) throw new TypeError('Invalid lease token hash');
  return Object.freeze({ accountId, operationId, attemptId, attemptGeneration, attemptLeaseTokenHash: value.leaseTokenHash, attemptExpiresAtMs: leaseExpiresAtMs });
}

function wireBody(binding) {
  return JSON.stringify({
    accountId: binding.accountId,
    operationId: binding.operationId,
    attemptId: binding.attemptId,
    attemptGeneration: binding.attemptGeneration,
    attemptLeaseTokenHash: binding.attemptLeaseTokenHash,
    attemptExpiresAtMs: binding.attemptExpiresAtMs,
  });
}

function safeToken(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 8192 || value.trim() !== value || !/^[A-Za-z0-9._~+/-]+=*$/u.test(value)) {
    throw new ProvisionDispatchError('access_token_invalid', 'Provision access token was invalid');
  }
  return value;
}

function safeResponseCandidate(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true);
  const keys = Object.keys(value).sort();
  if (keys.length !== RESPONSE_KEYS.length || !RESPONSE_KEYS.every(key => keys.includes(key))) {
    throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true);
  }
  if (typeof value.state !== 'string' || !RESPONSE_STATES.has(value.state)
      || typeof value.receiptId !== 'string' || value.receiptId.length !== 36 || !UUID.test(value.receiptId)
      || typeof value.userId !== 'string' || value.userId.length !== 36 || !UUID.test(value.userId)) {
    throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true);
  }
  return Object.freeze({ state: value.state, receiptId: value.receiptId, userId: value.userId });
}

function contentType(response) {
  let value;
  try { value = response.headers?.get?.('content-type'); } catch { value = null; }
  if (typeof value !== 'string' || value.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw new ProvisionDispatchError('response_content_type', 'Provision response content type was invalid', true);
  }
}

function suppress(promise) {
  Promise.resolve(promise).catch(() => {});
  return promise;
}

function operationContext(timeoutMs, parentSignal) {
  const controller = new AbortController();
  const deadline = Date.now() + timeoutMs;
  let reason = null;
  let timer;
  const context = {
    signal: controller.signal,
    deadline,
    reason: () => reason,
    remaining() { return Math.max(0, deadline - Date.now()); },
    abort(kind) {
      if (reason) return;
      reason = kind;
      controller.abort();
    },
    close() {
      clearTimeout(timer);
      controller.abort();
      parentSignal?.removeEventListener?.('abort', onParentAbort);
    },
  };
  const onParentAbort = () => context.abort('parent');
  if (parentSignal?.aborted) context.abort('parent');
  else parentSignal?.addEventListener?.('abort', onParentAbort, { once: true });
  timer = setTimeout(() => context.abort('timeout'), timeoutMs);
  return context;
}

function abortedError(context, reachedIssuer) {
  if (context.reason() === 'timeout') return new ProvisionDispatchError('timeout', 'Provision dispatch timed out', reachedIssuer);
  if (context.reason() === 'parent') return new ProvisionDispatchError('aborted', 'Provision dispatch was aborted', reachedIssuer);
  return new ProvisionDispatchError('dispatch_failed', 'Provision dispatch failed', reachedIssuer);
}

async function bounded(context, operation, reachedIssuer) {
  if (context.signal.aborted || context.remaining() <= 0) {
    context.abort(context.reason() ?? 'timeout');
    throw abortedError(context, reachedIssuer);
  }
  let promise;
  promise = Promise.resolve().then(() => {
    if (context.signal.aborted) throw abortedError(context, reachedIssuer);
    return operation();
  });
  suppress(promise);
  return new Promise((resolve, reject) => {
    let complete = false;
    const finish = (fn, value) => {
      if (complete) return;
      complete = true;
      context.signal.removeEventListener('abort', onAbort);
      fn(value);
    };
    const onAbort = () => finish(reject, abortedError(context, reachedIssuer));
    context.signal.addEventListener('abort', onAbort, { once: true });
    if (context.signal.aborted) onAbort();
    promise.then(value => finish(resolve, value), error => finish(reject, error));
  });
}

async function readBody(context, response, maxBytes) {
  contentType(response);
  const stream = response.body;
  if (stream && typeof stream.getReader === 'function') {
    const reader = stream.getReader();
    const chunks = [];
    let size = 0;
    try {
      while (true) {
        const part = await bounded(context, () => reader.read(), true);
        if (part?.done) break;
        const value = part?.value instanceof Uint8Array ? part.value : null;
        if (!value) throw new ProvisionDispatchError('response_invalid', 'Provision response body was invalid', true);
        size += value.byteLength;
        if (size > maxBytes) throw new ProvisionDispatchError('response_too_large', 'Provision response was too large', true);
        chunks.push(value);
      }
      return new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks));
    } finally {
      try { suppress(reader.cancel?.()); } catch {}
      try { reader.releaseLock?.(); } catch {}
    }
  }
  // A text-only adapter could allocate an unbounded body before this layer
  // can inspect it. Real Fetch responses provide a bounded readable stream.
  throw new ProvisionDispatchError('response_invalid', 'Provision response body was invalid', true);
}

function parseResponse(body) {
  let value;
  try { value = JSON.parse(body); } catch { throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true); }
  return safeResponseCandidate(value);
}

/**
 * Create the trusted backend transport used after `startProvisionAttempt`.
 * `endpoint` is an explicit pinned HTTPS base; `/provision` and `/abort` are
 * appended exactly. It never discovers an issuer, creates credentials, or
 * writes coordinator state.
 */
export function createProvisionDispatcher({ endpoint, issuer, realmId, obtainAccessToken, fetchImpl = globalThis.fetch, timeoutMs = 5000, maxResponseBytes = 16_384 } = {}) {
  const base = exactHttps(endpoint, 'dispatch endpoint');
  exactHttps(issuer, 'provision issuer');
  const configuredIssuer = issuer;
  const configuredRealm = text(realmId, 255, 'realm ID');
  if (typeof obtainAccessToken !== 'function') throw new TypeError('Access token provider is required');
  if (typeof fetchImpl !== 'function') throw new TypeError('Fetch implementation is required');
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 30_000) throw new TypeError('Dispatch timeout must be bounded');
  if (!Number.isSafeInteger(maxResponseBytes) || maxResponseBytes < 256 || maxResponseBytes > 1_048_576) throw new TypeError('Response limit must be bounded');
  const endpoints = Object.freeze({ provision: endpointUrl(base, 'provision'), abort: endpointUrl(base, 'abort') });

  async function dispatch(action, rawBinding, { signal } = {}) {
    if (action !== 'provision' && action !== 'abort') throw new TypeError('Invalid provision dispatch action');
    if (signal !== undefined && (typeof signal !== 'object' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) {
      throw new TypeError('Invalid dispatch abort signal');
    }
    const bodyBinding = validateBinding(rawBinding, configuredIssuer, configuredRealm);
    const context = operationContext(timeoutMs, signal);
    let response;
    const cancelBody = value => { try { suppress(value?.body?.cancel?.()); } catch {} };
    try {
      if (context.signal.aborted) throw abortedError(context, false);
      let token;
      try { token = safeToken(await bounded(context, () => obtainAccessToken({ signal: context.signal }), false)); }
      catch (error) {
        if (context.signal.aborted) throw abortedError(context, false);
        throw new ProvisionDispatchError('access_token_failed', 'Provision access token was unavailable', false);
      }
      const request = new Request(endpoints[action], {
        method: 'POST',
        redirect: 'error',
        headers: { accept: 'application/json', 'content-type': 'application/json', authorization: `Bearer ${token}` },
        body: wireBody(bodyBinding),
        signal: context.signal,
      });
      try { response = await bounded(context, async () => {
        const result = await fetchImpl(request);
        if (context.signal.aborted) cancelBody(result);
        return result;
      }, true); }
      catch (error) {
        if (context.signal.aborted) throw abortedError(context, true);
        throw new ProvisionDispatchError('transport_failed', 'Provision dispatch transport failed', true);
      }
      if (!response || typeof response !== 'object') throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true);
      if (response.redirected === true) throw new ProvisionDispatchError('redirect_rejected', 'Provision response redirect was rejected', true);
      let body;
      try { body = await readBody(context, response, maxResponseBytes); }
      catch (error) {
        if (error instanceof ProvisionDispatchError) {
          throw new ProvisionDispatchError(error.code, error.message, true);
        }
        throw new ProvisionDispatchError('response_invalid', 'Provision response was invalid', true);
      }
      if (response.status !== 200) throw new ProvisionDispatchError('issuer_rejected', 'Provision issuer rejected the dispatch', true);
      return parseResponse(body);
    } finally {
      context.close();
      cancelBody(response);
      // Cooperatively cancel transport work. An injected implementation that
      // ignores abort may retain its own request until it settles; no erasure
      // guarantee is made for immutable JavaScript strings.
    }
  }

  return Object.freeze({
    dispatch,
    provision: (binding, options) => dispatch('provision', binding, options),
    abort: (binding, options) => dispatch('abort', binding, options),
    endpoints,
  });
}
