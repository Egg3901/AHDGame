import { Buffer } from 'node:buffer';
import { TextDecoder } from 'node:util';

const MAX_BODY_BYTES = 16 * 1024;
const MAX_ACCESS_TOKEN_LENGTH = 8192;
const MAX_EXPIRES_IN = 3600;
const CONTROL = /[\u0000-\u001f\u007f\u2028\u2029]/u;
const TOKEN68 = /^(?:[A-Za-z0-9._~+\/-]+={0,})(?![\s\S])/u;
const SCOPE = /^(?:[\x21\x23-\x5b\x5d-\x7e]+(?: [\x21\x23-\x5b\x5d-\x7e]+)*)(?![\s\S])/u;
const ERROR_MESSAGES = Object.freeze({
  aborted: 'Provision access token request was aborted',
  timeout: 'Provision access token request timed out',
  transport: 'Provision access token transport failed',
  redirect: 'Provision access token redirect was rejected',
  http: 'Provision issuer rejected the access token request',
  content_type: 'Provision access token response content type was invalid',
  body: 'Provision access token response body was invalid',
  body_too_large: 'Provision access token response body was too large',
  invalid: 'Provision access token response was invalid',
});

/**
 * A token failure is deliberately sanitized. The endpoint, client
 * credentials, provider error body, and injected exception are never copied
 * into this error.
 */
export class ProvisionAccessTokenError extends Error {
  constructor(code = 'transport') {
    const safeCode = typeof code === 'string' && Object.hasOwn(ERROR_MESSAGES, code) ? code : 'transport';
    super(ERROR_MESSAGES[safeCode]);
    this.name = 'ProvisionAccessTokenError';
    this.code = safeCode;
  }
}

function error(code) {
  return new ProvisionAccessTokenError(code);
}

function sanitizeBodyFailure(caught) {
  try {
    if (caught instanceof ProvisionAccessTokenError) return error(caught.code);
  } catch { /* Even a hostile getter must not expose an injected exception. */ }
  return error('body');
}

function configString(value, max, label) {
  if (typeof value !== 'string' || value.length === 0 || value.length > max || !value.isWellFormed() || CONTROL.test(value)) {
    throw new TypeError(`Invalid ${label}`);
  }
  return value;
}

function pinnedTokenEndpoint(value) {
  configString(value, 2048, 'token endpoint');
  let parsed;
  try { parsed = new URL(value); } catch { throw new TypeError('Invalid token endpoint'); }
  if (parsed.protocol !== 'https:' || parsed.username || parsed.password || parsed.search || parsed.hash
      || value.includes('?') || value.includes('#') || value.includes('@') || parsed.href !== value) {
    throw new TypeError('Invalid token endpoint');
  }
  return value;
}

function scopeValue(value) {
  if (value === undefined) return undefined;
  if (typeof value !== 'string' || value.length === 0 || value.length > 2048 || !SCOPE.test(value)) {
    throw new TypeError('Invalid token scope');
  }
  return value;
}

// URLSearchParams implements the application/x-www-form-urlencoded percent
// encode set, including `+` for spaces. OAuth Basic authentication requires
// this encoding before the encoded client_id and client_secret are joined.
function formEncode(value) {
  return new URLSearchParams([['v', value]]).toString().slice(2);
}

function basicCredentials(clientId, clientSecret) {
  return Buffer.from(`${formEncode(clientId)}:${formEncode(clientSecret)}`, 'ascii').toString('base64');
}

function requestBody(scope) {
  const form = new URLSearchParams([['grant_type', 'client_credentials']]);
  if (scope !== undefined) form.set('scope', scope);
  return form.toString();
}

function validateSignal(signal) {
  if (signal !== undefined && (!signal || typeof signal !== 'object'
      || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) {
    throw new TypeError('Invalid abort signal');
  }
}

function operationContext(timeoutMs, parentSignal) {
  const controller = new AbortController();
  let reason = parentSignal?.aborted ? 'aborted' : null;
  let timer;
  const onParentAbort = () => {
    if (!reason) reason = 'aborted';
    controller.abort();
  };
  if (parentSignal && !parentSignal.aborted) parentSignal.addEventListener('abort', onParentAbort, { once: true });
  timer = setTimeout(() => {
    if (!reason) reason = 'timeout';
    controller.abort();
  }, timeoutMs);
  if (reason) controller.abort();
  return Object.freeze({
    signal: controller.signal,
    reason: () => reason,
    abortError() { return error(reason === 'aborted' ? 'aborted' : 'timeout'); },
    close() {
      clearTimeout(timer);
      controller.abort();
      parentSignal?.removeEventListener?.('abort', onParentAbort);
    },
  });
}

function ignore(promise) {
  if (promise && typeof promise.then === 'function') Promise.resolve(promise).catch(() => {});
}

function cancelBody(response) {
  let body;
  try { body = response?.body; } catch { return; }
  try { ignore(body?.cancel?.()); } catch {}
}

// Race an operation against the shared deadline without leaving a rejected
// provider/fetch promise unobserved. A late response is handed to onLate so
// its body can be canceled after this function has returned.
function bounded(context, operation, onLate) {
  if (context.signal.aborted) return Promise.reject(context.abortError());
  let operationPromise;
  try {
    operationPromise = Promise.resolve().then(() => {
      if (context.signal.aborted) throw context.abortError();
      return operation();
    });
  } catch (caught) {
    operationPromise = Promise.reject(caught);
  }
  let settled = false;
  let abandoned = false;
  ignore(operationPromise.then(value => {
    if (abandoned && onLate) {
      try { onLate(value); } catch {}
    }
  }, () => {}));
  return new Promise((resolve, reject) => {
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      context.signal.removeEventListener('abort', onAbort);
      fn(value);
    };
    const onAbort = () => {
      abandoned = true;
      finish(reject, context.abortError());
    };
    context.signal.addEventListener('abort', onAbort, { once: true });
    if (context.signal.aborted) onAbort();
    operationPromise.then(value => finish(resolve, value), caught => finish(reject, caught));
  });
}

function contentType(response) {
  let value;
  try { value = response?.headers?.get?.('content-type'); } catch { value = null; }
  if (typeof value !== 'string' || value.split(';', 1)[0].trim().toLowerCase() !== 'application/json') {
    throw error('content_type');
  }
}

async function readBody(response, context) {
  let body;
  try { body = response?.body; } catch { throw error('body'); }
  if (!body || typeof body.getReader !== 'function') throw error('body');
  let reader;
  try { reader = body.getReader(); } catch { throw error('body'); }
  if (!reader || typeof reader.read !== 'function') throw error('body');
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let bytes = 0;
  let text = '';
  const cancel = () => {
    try { ignore(reader.cancel()); } catch {}
  };
  context.signal.addEventListener('abort', cancel, { once: true });
  try {
    for (;;) {
      const chunk = await reader.read();
      if (!chunk || typeof chunk !== 'object' || chunk.done === undefined) throw error('body');
      if (chunk.done) break;
      if (!(chunk.value instanceof Uint8Array)) throw error('body');
      bytes += chunk.value.byteLength;
      if (bytes > MAX_BODY_BYTES) throw error('body_too_large');
      text += decoder.decode(chunk.value, { stream: true });
    }
    text += decoder.decode();
    return text;
  } catch (caught) {
    if (context.signal.aborted) throw context.abortError();
    throw sanitizeBodyFailure(caught);
  } finally {
    context.signal.removeEventListener('abort', cancel);
    cancel();
    try { reader.releaseLock?.(); } catch {}
  }
}

// Scan JSON structure before JSON.parse so duplicate object keys, including
// escaped aliases such as "access\\u005ftoken", cannot silently overwrite a
// security field. JSON.parse remains the final syntax and value validator.
function rejectDuplicateKeys(json) {
  let index = 0;
  const length = json.length;
  const whitespace = character => character === ' ' || character === '\t' || character === '\n' || character === '\r';
  const skipWhitespace = () => { while (index < length && whitespace(json[index])) index += 1; };
  const parseString = () => {
    const start = index;
    if (json[index] !== '"') throw new Error('invalid string');
    index += 1;
    while (index < length) {
      const code = json.charCodeAt(index);
      if (code === 0x22) {
        index += 1;
        return JSON.parse(json.slice(start, index));
      }
      if (code === 0x5c) {
        index += 1;
        if (index >= length) throw new Error('invalid escape');
        if (json[index] === 'u') index += 4;
        index += 1;
        continue;
      }
      if (code < 0x20) throw new Error('invalid string');
      index += 1;
    }
    throw new Error('unterminated string');
  };
  const parseValue = () => {
    skipWhitespace();
    const character = json[index];
    if (character === '{') return parseObject();
    if (character === '[') return parseArray();
    if (character === '"') { parseString(); return; }
    const start = index;
    while (index < length && !whitespace(json[index]) && !',]}'.includes(json[index])) index += 1;
    if (start === index) throw new Error('invalid value');
  };
  const parseObject = () => {
    index += 1;
    skipWhitespace();
    const seen = new Set();
    if (json[index] === '}') { index += 1; return; }
    for (;;) {
      skipWhitespace();
      const key = parseString();
      if (seen.has(key)) throw new Error('duplicate key');
      seen.add(key);
      skipWhitespace();
      if (json[index] !== ':') throw new Error('missing colon');
      index += 1;
      parseValue();
      skipWhitespace();
      if (json[index] === '}') { index += 1; return; }
      if (json[index] !== ',') throw new Error('missing comma');
      index += 1;
    }
  };
  const parseArray = () => {
    index += 1;
    skipWhitespace();
    if (json[index] === ']') { index += 1; return; }
    for (;;) {
      parseValue();
      skipWhitespace();
      if (json[index] === ']') { index += 1; return; }
      if (json[index] !== ',') throw new Error('missing comma');
      index += 1;
    }
  };
  skipWhitespace();
  parseValue();
  skipWhitespace();
  if (index !== length) throw new Error('trailing JSON');
}

function parseTokenResponse(body) {
  let payload;
  try {
    rejectDuplicateKeys(body);
    payload = JSON.parse(body);
  } catch {
    throw error('body');
  }
  if (!payload || typeof payload !== 'object' || Array.isArray(payload)
      || typeof payload.access_token !== 'string'
      || payload.access_token.length === 0 || payload.access_token.length > MAX_ACCESS_TOKEN_LENGTH
      || !TOKEN68.test(payload.access_token)
      || typeof payload.token_type !== 'string' || payload.token_type.toLowerCase() !== 'bearer'
      || !Number.isSafeInteger(payload.expires_in) || payload.expires_in <= 0 || payload.expires_in > MAX_EXPIRES_IN) {
    throw error('invalid');
  }
  return payload.access_token;
}

/**
 * Create the uncached OAuth client_credentials provider used by the trusted
 * provision dispatcher. The endpoint, client credentials, and optional scope
 * are explicit deployment configuration. Each call mints one token and
 * returns only its access_token string.
 */
export function createProvisionAccessTokenProvider({
  tokenEndpoint,
  clientId,
  clientSecret,
  scope,
  fetchImpl = globalThis.fetch,
  timeoutMs = 5000,
} = {}) {
  const endpoint = pinnedTokenEndpoint(tokenEndpoint);
  const id = configString(clientId, 512, 'client ID');
  const secret = configString(clientSecret, 4096, 'client secret');
  const configuredScope = scopeValue(scope);
  if (typeof fetchImpl !== 'function') throw new TypeError('Fetch implementation is required');
  if (!Number.isSafeInteger(timeoutMs) || timeoutMs < 100 || timeoutMs > 5000) throw new TypeError('Token timeout must be bounded');
  const authorization = `Basic ${basicCredentials(id, secret)}`;
  const body = requestBody(configuredScope);

  async function obtainAccessToken({ signal } = {}) {
    validateSignal(signal);
    const context = operationContext(timeoutMs, signal);
    let response;
    try {
      if (context.signal.aborted) throw context.abortError();
      try {
        response = await bounded(context, () => fetchImpl(endpoint, {
          method: 'POST',
          redirect: 'error',
          signal: context.signal,
          headers: {
            accept: 'application/json',
            'content-type': 'application/x-www-form-urlencoded',
            authorization,
          },
          body,
        }), cancelBody);
      } catch (caught) {
        if (context.signal.aborted) throw context.abortError();
        throw error('transport');
      }
      if (context.signal.aborted) throw context.abortError();
      let redirected;
      let status;
      try {
        redirected = response?.redirected;
        status = response?.status;
      } catch { throw error('transport'); }
      if (redirected === true) throw error('redirect');
      if (status !== 200) throw error('http');
      contentType(response);
      let text;
      try {
        text = await bounded(context, () => readBody(response, context), cancelBody);
      } catch (caught) {
        if (context.signal.aborted) throw context.abortError();
        throw sanitizeBodyFailure(caught);
      }
      if (context.signal.aborted) throw context.abortError();
      return parseTokenResponse(text);
    } finally {
      context.close();
      cancelBody(response);
    }
  }

  return Object.freeze({ obtainAccessToken });
}
