CREATE SCHEMA IF NOT EXISTS lakeside_accounts;

CREATE TABLE lakeside_accounts.account (
  account_id uuid PRIMARY KEY,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended')),
  security_version bigint NOT NULL DEFAULT 1 CHECK (security_version > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE lakeside_accounts.external_identity (
  issuer text NOT NULL CHECK (length(issuer) BETWEEN 1 AND 512),
  subject text NOT NULL CHECK (length(subject) BETWEEN 1 AND 512),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  provenance text NOT NULL CHECK (length(provenance) BETWEEN 1 AND 256),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (issuer, subject)
);
CREATE INDEX ON lakeside_accounts.external_identity(account_id);

CREATE TABLE lakeside_accounts.application_identity (
  application_id text NOT NULL CHECK (length(application_id) BETWEEN 1 AND 128),
  local_user_id text NOT NULL CHECK (length(local_user_id) BETWEEN 1 AND 512),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  provenance text NOT NULL CHECK (length(provenance) BETWEEN 1 AND 256),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (application_id, local_user_id),
  UNIQUE (application_id, account_id)
);

-- Event IDs are also idempotency keys for future delivery consumers.
-- The event and its pending delivery are inserted in the same transaction.
CREATE TABLE lakeside_accounts.audit_event (
  event_id uuid PRIMARY KEY,
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  action text NOT NULL,
  provenance text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE lakeside_accounts.outbox (
  event_id uuid PRIMARY KEY REFERENCES lakeside_accounts.audit_event(event_id),
  available_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz
);
