import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import pg from 'pg';
import { createAccountRegistry, createProvisionCoordinator, migrate as migrateRegistry } from './index.mjs';
import { ProvisionConflictError, ProvisionUnavailableError } from './provision-bind.mjs';
import { createProvisionWorkflow, ProvisionWorkflowError } from './provision-workflow.mjs';

const issuer = 'https://issuer.example.invalid/realms/lakeside';
const realmId = 'lakeside-fixture';
const accountId = '00000000-0000-4000-8000-000000000001';
const userId = '00000000-0000-4000-8000-000000000101';
const operationId = '00000000-0000-4000-8000-000000000002';
const attemptId = '00000000-0000-4000-8000-000000000003';

function bindingFor(overrides = {}) {
  const account = overrides.accountId ?? accountId;
  return Object.freeze({
    version: 1,
    accountId: account,
    operationId: overrides.operationId ?? operationId,
    issuer,
    realmId,
    username: `lakeside:${account}`,
    attemptId: overrides.attemptId ?? attemptId,
    attemptGeneration: overrides.attemptGeneration ?? 1,
    leaseTokenHash: overrides.leaseTokenHash ?? 'a'.repeat(64),
    leaseExpiresAtMs: overrides.leaseExpiresAtMs ?? 4102444800000,
  });
}

function terminal(binding, state = 'COMMITTED', overrides = {}) {
  return {
    state,
    accountId: binding.accountId,
    operationId: binding.operationId,
    attemptId: binding.attemptId,
    attemptGeneration: binding.attemptGeneration,
    receiptId: overrides.receiptId ?? '00000000-0000-4000-8000-000000000004',
    userId: overrides.userId ?? userId,
    issuer,
    replay: overrides.replay ?? false,
  };
}

function candidate(state = 'COMMITTED') {
  return { state, receiptId: randomUUID(), userId: randomUUID() };
}

function harness({ startResult, reconciles = [], dispatch = async () => candidate() } = {}) {
  const starts = [];
  const reconciliationCalls = [];
  const dispatchCalls = [];
  let reconcileIndex = 0;
  const coordinator = {
    startProvisionAttempt: async input => {
      starts.push(input);
      return typeof startResult === 'function' ? startResult(starts.length) : startResult;
    },
    reconcileProvisionAttempt: async input => {
      reconciliationCalls.push(input);
      const next = typeof reconciles === 'function' ? reconciles(reconciliationCalls.length, input) : reconciles[reconcileIndex++];
      if (next instanceof Error) throw next;
      return next;
    },
  };
  const dispatcher = {
    provision: async (binding, options) => {
      dispatchCalls.push({ binding, options });
      return dispatch(binding, options, dispatchCalls.length);
    },
  };
  return {
    starts,
    reconciliationCalls,
    dispatchCalls,
    workflow: createProvisionWorkflow({ coordinator, dispatcher, issuer, realmId, leaseMs: 60000 }),
  };
}

test('rejects adapter accessors without evaluating or dispatching them', async () => {
  let reads = 0;
  const binding = { ...bindingFor() };
  Object.defineProperty(binding, 'attemptId', { enumerable: true, get() { reads += 1; throw new Error('synthetic-private-material'); } });
  const h = harness({ startResult: { issuer, reused: false, binding } });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' }), error => error instanceof ProvisionWorkflowError && error.code === 'invalid_result' && !error.message.includes('synthetic-private-material'));
  assert.equal(reads, 0);
  assert.equal(h.dispatchCalls.length, 0);
});

test('rejects malformed Unicode input and ignores hostile error-code coercion', async () => {
  const h = harness({ startResult: { issuer, reused: false, binding: bindingFor() } });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:\ud800' }), error => error.code === 'invalid_input');
  assert.equal(h.starts.length, 0);
  const failure = new ProvisionWorkflowError({ toString() { throw new Error('synthetic-secret'); } });
  assert.equal(failure.code, 'coordinator_unavailable');
});

test('hostile thrown objects remain unavailable without leaking or dispatching', async () => {
  const failure = new Proxy({}, { getPrototypeOf() { throw new Error('synthetic-private-material'); } });
  let dispatched = false;
  const workflow = createProvisionWorkflow({
    coordinator: { async startProvisionAttempt() { throw failure; }, async reconcileProvisionAttempt() { throw failure; } },
    dispatcher: { async provision() { dispatched = true; } }, issuer, realmId, leaseMs: 60000,
  });
  await assert.rejects(workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' }), error => error instanceof ProvisionWorkflowError && error.code === 'coordinator_unavailable');
  assert.equal(dispatched, false);
});

test('fresh candidate with missing durable receipt returns stable pending identifiers', async () => {
  const binding = bindingFor();
  const h = harness({
    startResult: { issuer, reused: false, binding },
    reconciles: [new ProvisionUnavailableError()],
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'PENDING');
  assert.equal(result.reason, 'receipt_unavailable');
  assert.equal(result.accountId, accountId);
  assert.equal(result.operationId, operationId);
  assert.equal(result.attemptId, attemptId);
  assert.equal(h.dispatchCalls.length, 1);
  assert.equal(h.reconciliationCalls.length, 1);
  assert.equal(h.dispatchCalls[0].binding.attemptId, attemptId);
});

test('HTTP timeout followed by durable COMMITTED evidence returns success', async () => {
  const binding = bindingFor();
  const h = harness({
    startResult: { issuer, reused: false, binding },
    reconciles: [terminal(binding)],
    dispatch: async () => { throw new Error('provider secret timeout'); },
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'COMMITTED');
  assert.equal(result.receiptId, '00000000-0000-4000-8000-000000000004');
  assert.equal(h.reconciliationCalls.length, 1);
});

test('already provisioned metadata is validated and never dispatched or re-read', async () => {
  const h = harness({ startResult: {
    alreadyProvisioned: true,
    accountId,
    operationId,
    attemptId,
    issuer,
    realmId,
    username: `lakeside:${accountId}`,
    userId,
    receiptId: '00000000-0000-4000-8000-000000000004',
  } });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'COMMITTED');
  assert.equal(result.replay, true);
  assert.equal(h.dispatchCalls.length, 0);
  assert.equal(h.reconciliationCalls.length, 0);
});

test('reused binding returns durable ABORTED without automatic generation advance', async () => {
  const binding = bindingFor();
  const h = harness({ startResult: { issuer, reused: true, binding }, reconciles: [terminal(binding, 'ABORTED')] });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'ABORTED');
  assert.equal(h.dispatchCalls.length, 0);
  assert.equal(h.reconciliationCalls.length, 1);
});

test('reused unavailable evidence dispatches exactly the same binding once', async () => {
  const binding = bindingFor();
  let dispatched;
  const h = harness({
    startResult: { issuer, reused: true, binding },
    reconciles: [new ProvisionUnavailableError(), new ProvisionUnavailableError()],
    dispatch: async value => { dispatched = { ...value }; return candidate('REPLAY_NO_MUTATION'); },
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'PENDING');
  assert.deepEqual(dispatched, binding);
  assert.equal(h.dispatchCalls[0].binding.attemptId, binding.attemptId);
  assert.equal(h.reconciliationCalls.length, 2);
});

test('reused coordinator conflict fails closed without issuer dispatch', async () => {
  const binding = bindingFor();
  const h = harness({ startResult: { issuer, reused: true, binding }, reconciles: [new ProvisionConflictError('secret detail')] });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' }), error =>
    error instanceof ProvisionWorkflowError && error.code === 'conflict' && !error.message.includes('secret detail'));
  assert.equal(h.dispatchCalls.length, 0);
});

test('token failure with missing receipt remains pending and never aborts', async () => {
  const binding = bindingFor();
  const h = harness({
    startResult: { issuer, reused: false, binding },
    reconciles: [new ProvisionUnavailableError()],
    dispatch: async () => { throw new Error('token secret'); },
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'PENDING');
});

test('parent cancellation before start is rejected without coordinator or dispatch', async () => {
  const controller = new AbortController();
  controller.abort();
  let starts = 0;
  const h = harness({ startResult: () => { starts += 1; return { issuer, reused: false, binding: bindingFor() }; } });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test', signal: controller.signal }), error =>
    error.code === 'aborted');
  assert.equal(starts, 0);
  assert.equal(h.dispatchCalls.length, 0);
});

test('parent cancellation after dispatch still reconciles durable outcome', async () => {
  const controller = new AbortController();
  const binding = bindingFor();
  const h = harness({
    startResult: { issuer, reused: false, binding },
    reconciles: [terminal(binding)],
    dispatch: async (_binding, options) => {
      controller.abort();
      assert.equal(options.signal, controller.signal);
      throw new Error('request canceled after reaching issuer');
    },
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test', signal: controller.signal });
  assert.equal(result.state, 'COMMITTED');
  assert.equal(h.reconciliationCalls.length, 1);
});

test('malformed binding is rejected before dispatch or reconciliation', async () => {
  const malformed = { ...bindingFor(), accountId: 'not-a-uuid' };
  const h = harness({ startResult: { issuer, reused: false, binding: malformed } });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' }), error =>
    error instanceof ProvisionWorkflowError && error.code === 'invalid_result');
  assert.equal(h.dispatchCalls.length, 0);
  assert.equal(h.reconciliationCalls.length, 0);
});

test('invalid input and hostile coordinator errors are sanitized before side effects', async () => {
  let starts = 0;
  const h = harness({ startResult: async () => { starts += 1; throw new Error('database password secret'); } });
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId: { toString: () => accountId }, provenance: 'workflow:test' }), error => error.code === 'invalid_input');
  await assert.rejects(h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' }), error =>
    error.code === 'coordinator_unavailable' && !error.message.includes('database password secret'));
  assert.equal(starts, 1);
});

test('configuration and dispatcher candidates are validated without treating candidates as proof', async () => {
  assert.throws(() => createProvisionWorkflow({ coordinator: {}, dispatcher: {}, issuer, realmId, leaseMs: 60000 }), TypeError);
  const binding = bindingFor();
  const h = harness({
    startResult: { issuer, reused: false, binding },
    reconciles: [terminal(binding)],
    dispatch: async () => ({ state: 'COMMITTED', receiptId: 'bad', userId: 'bad' }),
  });
  const result = await h.workflow.provisionDisabledAccount({ accountId, provenance: 'workflow:test' });
  assert.equal(result.state, 'COMMITTED');
  assert.equal(result.userId, userId);
});

const isolatedPg = process.env.LAKESIDE_ISOLATED_PROVISION_WORKFLOW_TEST === 'true' && process.env.PGHOST === 'database';

test('guarded actual PostgreSQL coordinator workflow preserves attempts and requires ABORT before generation advance', { skip: !isolatedPg }, async () => {
  const admin = new pg.Pool({ max: 1, connectionTimeoutMillis: 5000, query_timeout: 10000, statement_timeout: 8000 });
  const database = `workflow_test_${randomUUID().replaceAll('-', '')}`;
  let pool;
  let created = false;
  try {
    await admin.query(`CREATE DATABASE ${database}`);
    created = true;
    pool = new pg.Pool({ database, max: 8, connectionTimeoutMillis: 5000, query_timeout: 10000, statement_timeout: 8000 });
    await migrateRegistry(pool);
    const registry = createAccountRegistry(pool, { allowedIssuers: ['https://login.example.invalid'], allowedApplications: [] });
    const first = await registry.resolveOrCreateVerifiedIdentity({ issuer: 'https://login.example.invalid', subject: `workflow-first-${randomUUID()}` }, 'workflow:fixture');
    const second = await registry.resolveOrCreateVerifiedIdentity({ issuer: 'https://login.example.invalid', subject: `workflow-second-${randomUUID()}` }, 'workflow:fixture');
    const receipts = new Map();
    const dispatches = [];
    function receipt(binding, state) {
      const current = receipts.get(binding.attemptId);
      if (!current) throw new ProvisionUnavailableError();
      return {
        accountId: binding.accountId,
        operationId: binding.operationId,
        realmId: binding.realmId,
        username: binding.username,
        userId: current.userId,
        attemptId: binding.attemptId,
        attemptGeneration: binding.attemptGeneration,
        leaseTokenHash: binding.leaseTokenHash,
        leaseExpiresAtMs: binding.leaseExpiresAtMs,
        receiptId: current.receiptId,
        state,
        issuer: binding.issuer,
      };
    }
    const coordinator = createProvisionCoordinator(pool, {
      allowedProvisionIssuers: [issuer],
      loadProvisionReceipt: async binding => {
        const current = receipts.get(binding.attemptId);
        if (!current) throw new ProvisionUnavailableError();
        return receipt(binding, current.state);
      },
    });
    const dispatcher = {
      provision: async binding => {
        dispatches.push({ ...binding });
        if (binding.accountId === second.account_id) {
          receipts.set(binding.attemptId, { state: 'COMMITTED', userId: randomUUID(), receiptId: randomUUID() });
        }
        return { state: 'COMMITTED', userId: randomUUID(), receiptId: randomUUID() };
      },
    };
    const workflow = createProvisionWorkflow({ coordinator, dispatcher, issuer, realmId, leaseMs: 60000 });

    const firstPending = await workflow.provisionDisabledAccount({ accountId: first.account_id, provenance: 'workflow:fixture' });
    assert.equal(firstPending.state, 'PENDING');
    const firstAttempt = dispatches[0];
    const retryPending = await workflow.provisionDisabledAccount({ accountId: first.account_id, provenance: 'workflow:fixture' });
    assert.equal(retryPending.state, 'PENDING');
    assert.equal(retryPending.attemptId, firstAttempt.attemptId);
    assert.equal(dispatches[1].attemptId, firstAttempt.attemptId);

    receipts.set(firstAttempt.attemptId, { state: 'ABORTED', userId: randomUUID(), receiptId: randomUUID() });
    const aborted = await workflow.provisionDisabledAccount({ accountId: first.account_id, provenance: 'workflow:fixture' });
    assert.equal(aborted.state, 'ABORTED');
    assert.equal(dispatches.length, 2);

    const secondGenerationPending = await workflow.provisionDisabledAccount({ accountId: first.account_id, provenance: 'workflow:fixture' });
    assert.equal(secondGenerationPending.state, 'PENDING');
    assert.equal(secondGenerationPending.attemptGeneration, 2);
    assert.notEqual(secondGenerationPending.attemptId, firstAttempt.attemptId);

    const committed = await workflow.provisionDisabledAccount({ accountId: second.account_id, provenance: 'workflow:fixture' });
    assert.equal(committed.state, 'COMMITTED');
    assert.equal(committed.accountId, second.account_id);
  } finally {
    try { await pool?.end(); } finally {
      try { if (created) await admin.query(`DROP DATABASE IF EXISTS ${database}`); } finally { await admin.end(); }
    }
  }
});
