-- Inclusive cutoff: authentication in the reset's same second is rejected too.
ALTER TABLE lakeside_accounts.account ADD COLUMN authentication_not_before bigint
  NOT NULL DEFAULT 0 CHECK (authentication_not_before >= 0);
-- Earlier versions did not retain revocation time. Reauthenticate changed accounts
-- when upgrading rather than accepting an old issuer session with the new version.
UPDATE lakeside_accounts.account
SET authentication_not_before=floor(extract(epoch from clock_timestamp()))::bigint
WHERE security_version > 1;
