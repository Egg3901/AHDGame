-- Provision coordinator slice (registry database, lakeside_accounts schema).
-- Additive only. Existing migrations 1..3 are untouched.
--
-- Design notes (root decisions):
-- * No userId in the coordinator binding. The provider mints the reserved
--   target; the first authenticated COMMITTED or ABORTED receipt freezes it
--   in provision_subject. Attempt rows are never rewritten to fill userId.
-- * All REFERENCES default to NO ACTION (no CASCADE): deleting an account
--   row is blocked while coordinator evidence exists, matching the existing
--   registry tables. Evidence always outlives the account row.
-- * provision_operation / provision_attempt / provision_evidence /
--   provision_subject are append-only via triggers below. Only
--   provision_live_attempt (the live pointer) is mutable.
-- * Deployment roles/grants ship later with root; REVOKE FROM PUBLIC below
--   keeps the trigger function closed by default.
CREATE TABLE lakeside_accounts.provision_operation (
  account_id uuid PRIMARY KEY REFERENCES lakeside_accounts.account(account_id),
  operation_id uuid NOT NULL UNIQUE,
  issuer text NOT NULL CHECK (
    issuer LIKE 'https://%' AND length(issuer) BETWEEN 9 AND 512
    AND issuer NOT LIKE '%?%' AND issuer NOT LIKE '%#%' AND issuer NOT LIKE '%@%'
    AND issuer !~ '[[:cntrl:]]'),
  realm_id text NOT NULL CHECK (length(realm_id) BETWEEN 1 AND 255 AND realm_id !~ '[[:cntrl:]]'),
  username text NOT NULL CHECK (username = 'lakeside:' || account_id::text),
  provenance text NOT NULL CHECK (length(provenance) BETWEEN 1 AND 256 AND provenance !~ '[[:cntrl:]]'),
  created_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

CREATE TABLE lakeside_accounts.provision_attempt (
  attempt_id uuid PRIMARY KEY,
  operation_id uuid NOT NULL REFERENCES lakeside_accounts.provision_operation(operation_id),
  account_id uuid NOT NULL REFERENCES lakeside_accounts.account(account_id),
  attempt_generation bigint NOT NULL CHECK (attempt_generation > 0 AND attempt_generation <= 9007199254740991),
  account_security_version bigint NOT NULL CHECK (account_security_version > 0),
  binding jsonb NOT NULL CHECK (jsonb_typeof(binding) = 'object'
    AND (binding ?& array['version','accountId','operationId','issuer','realmId','username','attemptId','attemptGeneration','leaseTokenHash','leaseExpiresAtMs'])
    AND NOT (binding ? 'userId') AND NOT (binding ? 'receiptId') AND NOT (binding ? 'state')),
  bound_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (operation_id, attempt_generation)
);
CREATE INDEX ON lakeside_accounts.provision_attempt (operation_id);

-- Mutable pointer only. All history stays in provision_attempt.
CREATE TABLE lakeside_accounts.provision_live_attempt (
  account_id uuid PRIMARY KEY REFERENCES lakeside_accounts.account(account_id),
  operation_id uuid NOT NULL UNIQUE REFERENCES lakeside_accounts.provision_operation(operation_id),
  attempt_id uuid NOT NULL UNIQUE REFERENCES lakeside_accounts.provision_attempt(attempt_id)
);

-- Single terminal receipt per attempt. receipt_id is globally unique so a
-- receipt can never be recorded for two attempts.
CREATE TABLE lakeside_accounts.provision_evidence (
  attempt_id uuid PRIMARY KEY REFERENCES lakeside_accounts.provision_attempt(attempt_id),
  receipt_id uuid NOT NULL UNIQUE,
  state text NOT NULL CHECK (state IN ('COMMITTED', 'ABORTED')),
  evidence_fingerprint text NOT NULL CHECK (evidence_fingerprint ~ '^[0-9a-f]{64}$'),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp()
);

-- Reserved provider target, frozen on first authenticated evidence
-- (COMMITTED or ABORTED) and pinned afterwards. (issuer, user_id) is unique
-- so two accounts can never freeze the same provider subject.
CREATE TABLE lakeside_accounts.provision_subject (
  account_id uuid PRIMARY KEY REFERENCES lakeside_accounts.account(account_id),
  user_id uuid NOT NULL,
  issuer text NOT NULL CHECK (
    issuer LIKE 'https://%' AND length(issuer) BETWEEN 9 AND 512
    AND issuer NOT LIKE '%?%' AND issuer NOT LIKE '%#%' AND issuer NOT LIKE '%@%'
    AND issuer !~ '[[:cntrl:]]'),
  realm_id text NOT NULL CHECK (length(realm_id) BETWEEN 1 AND 255 AND realm_id !~ '[[:cntrl:]]'),
  first_attempt_id uuid NOT NULL REFERENCES lakeside_accounts.provision_attempt(attempt_id),
  recorded_at timestamptz NOT NULL DEFAULT clock_timestamp(),
  UNIQUE (issuer, user_id)
);

-- Composite references keep every pointer and target on its original account.
ALTER TABLE lakeside_accounts.provision_operation
  ADD UNIQUE (account_id, operation_id), ADD UNIQUE (account_id, issuer, realm_id);
ALTER TABLE lakeside_accounts.provision_attempt
  ADD UNIQUE (account_id, operation_id, attempt_id), ADD UNIQUE (account_id, attempt_id),
  ADD FOREIGN KEY (account_id, operation_id)
    REFERENCES lakeside_accounts.provision_operation(account_id, operation_id);
ALTER TABLE lakeside_accounts.provision_live_attempt
  ADD FOREIGN KEY (account_id, operation_id, attempt_id)
    REFERENCES lakeside_accounts.provision_attempt(account_id, operation_id, attempt_id);
ALTER TABLE lakeside_accounts.provision_subject
  ADD FOREIGN KEY (account_id, first_attempt_id)
    REFERENCES lakeside_accounts.provision_attempt(account_id, attempt_id),
  ADD FOREIGN KEY (account_id, issuer, realm_id)
    REFERENCES lakeside_accounts.provision_operation(account_id, issuer, realm_id);

CREATE FUNCTION lakeside_accounts.check_provision_binding()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE owner lakeside_accounts.provision_operation%ROWTYPE;
        expiry bigint;
BEGIN
  SELECT * INTO owner FROM lakeside_accounts.provision_operation
    WHERE account_id=NEW.account_id AND operation_id=NEW.operation_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'provision binding owner conflicts'; END IF;
  IF jsonb_typeof(NEW.binding->'leaseTokenHash') IS DISTINCT FROM 'string'
     OR (NEW.binding->>'leaseTokenHash') !~ '^[0-9a-f]{64}$'
     OR jsonb_typeof(NEW.binding->'leaseExpiresAtMs') IS DISTINCT FROM 'number'
     OR (NEW.binding->>'leaseExpiresAtMs') !~ '^[1-9][0-9]{0,15}$' THEN
    RAISE EXCEPTION 'provision lease binding is malformed';
  END IF;
  expiry := (NEW.binding->>'leaseExpiresAtMs')::bigint;
  IF expiry > 9007199254740991 THEN RAISE EXCEPTION 'provision lease expiry is unsafe'; END IF;
  IF NEW.binding IS DISTINCT FROM jsonb_build_object(
    'version',1,'accountId',NEW.account_id::text,'operationId',NEW.operation_id::text,
    'issuer',owner.issuer,'realmId',owner.realm_id,'username',owner.username,
    'attemptId',NEW.attempt_id::text,'attemptGeneration',NEW.attempt_generation,
    'leaseTokenHash',NEW.binding->>'leaseTokenHash','leaseExpiresAtMs',expiry) THEN
    RAISE EXCEPTION 'provision binding does not match immutable ownership';
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER provision_attempt_binding BEFORE INSERT ON lakeside_accounts.provision_attempt
FOR EACH ROW EXECUTE FUNCTION lakeside_accounts.check_provision_binding();
REVOKE ALL ON FUNCTION lakeside_accounts.check_provision_binding() FROM PUBLIC;

CREATE OR REPLACE FUNCTION lakeside_accounts.reject_provision_mutation()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  RAISE EXCEPTION 'lakeside_accounts.% is append-only', TG_TABLE_NAME;
END;
$$;

CREATE TRIGGER provision_operation_immutable
BEFORE UPDATE OR DELETE ON lakeside_accounts.provision_operation
FOR EACH ROW EXECUTE FUNCTION lakeside_accounts.reject_provision_mutation();
CREATE TRIGGER provision_attempt_immutable
BEFORE UPDATE OR DELETE ON lakeside_accounts.provision_attempt
FOR EACH ROW EXECUTE FUNCTION lakeside_accounts.reject_provision_mutation();
CREATE TRIGGER provision_evidence_immutable
BEFORE UPDATE OR DELETE ON lakeside_accounts.provision_evidence
FOR EACH ROW EXECUTE FUNCTION lakeside_accounts.reject_provision_mutation();
CREATE TRIGGER provision_subject_immutable
BEFORE UPDATE OR DELETE ON lakeside_accounts.provision_subject
FOR EACH ROW EXECUTE FUNCTION lakeside_accounts.reject_provision_mutation();

REVOKE ALL ON FUNCTION lakeside_accounts.reject_provision_mutation() FROM PUBLIC;
